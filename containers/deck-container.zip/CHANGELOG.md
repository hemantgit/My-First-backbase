### `v1.1.3 - 18/08/2016`
* EEFIVE-2463 Update-Deck-container-to-use-CXP-Url2S
* EEFIVE-2463 Update-Deck-container-to-use-CXP-Url2S - Show the parent container if it's a lightbox container
* EEFIVE-2463 Update-Deck-container-to-use-CXP-Url2S - Do the code less prone to fail.
* EEFIVE-2463 Update-Deck-container-to-use-CXP-Url2S - Added a new panel url2state check to be able to show a panel by it's title that's also more clear to the user that not using uuid.
* EEFIVE-2463 Update-Deck-container-to-use-CXP-Url2S - Added a new panel url2state check to be able to show a panel by it's title that's also more clear to the user that not using uuid.
* Updated bower.json main script entry and added dist to ignore

### `v1.1.2 - 31/03/2016`

### v1.1.1 - `12/01/2016, 11:46am`
* LF-740: Added nextTick check for async appending elements

### v1.1.0 - `11/01/2016, 12:15pm`
* move _loadChildren method from launcher deck

### v1.0.2 - `26/08/2015, 12:16pm`
#### add tag to info.json for styleguide filtering
* add tag to info.json for styleguide menu filtering
* bugfix/LPMAINT-29-apply-changes-to-the-deck-container: - Child nodes check is added to fix js error (empty panel case)


### v1.0.1 - `20/08/2015, 3:48pm`
* Updating dependencies from master to ^1.0.0 in bower.json


### v1.0.0 - `20/08/2015, 2:38pm`
#### Initial release for CXP 5.6


### v0.2.3 - `10/08/2015, 6:09pm`
#### Remove repository from bower.json


### v0.2.2 - `10/08/2015, 5:44pm`
#### remove window.lp global object


### v0.2.1 - `04/08/2015, 10:10am`
#### rename css and references
* rename css
* add container-panel as a dependency
* fix deck
* add template dependency


### v0.2.0 - `30/07/2015, 2:45pm`
* Moving templates to their own repos.
* small order script update
* update tags
* update files
