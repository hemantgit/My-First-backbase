   (function (root) {
    'use strict';

    var launchpad = root.launchpad || {};
    var staticPath = launchpad && launchpad.staticRoot ? launchpad.staticRoot : 'bower_components';
    var isSameStaticAndStaticRoot =   staticPath === launchpad.staticRoot;
    var modulesPath = isSameStaticAndStaticRoot ? '/features/[BBHOST]/' : '/';
    var widgetsPath = isSameStaticAndStaticRoot ? '/widgets/[BBHOST]/' : '/';

    require.config({
        paths: {
            'module-custom-bpi': staticPath + modulesPath + 'module-custom-bpi/dist/scripts',
        },
        // Register packages
        packages: [
            'module-custom-bpi'
        ]
    });
}(window));