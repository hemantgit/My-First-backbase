
define(function (require, exports, module) {

    'use strict';
	//institution code
	var INSTITUTION_CODE_OBJECT = {"01": "BPI Family", "02": "BPI", "03": "BPI Direct", "23": "BPI EUROPE" };
	//currency code
	var CURRENCY_CODE_OBJECT = {"01": "PHP ", "02": "USD ", "03": "CHF ", "04": "DEM ", "05": "GBP ", "06": "HKD ", "07": "AUD ", "08": "NLG ",
                "09": "SGD ", "10": "FRF ", "11": "CAD ", "12": "BEC ", "13": "NZD ", "14": "ESP ", "15": "SEK ", "16": "MYR ", "17": "NOK ",
                "18": "IDR ", "19": "THB ", "20": "DKK ", "21": "ZAR ", "22": "BND ", "23": "CNY ", "24": "JPY ", "25": "KRW ", "26": "ITL ",
                "28": "INR ", "29": "ATS ", "70": "EUR " };
	//organization code
	var ORGNOONECODEJSON = {"001": "BPI Express Credit Classic", "002": "BPI Gold MasterCard", "003": "BPI Blue MasterCard",
            "004": "BPI Corporate MasterCard", "005": "BPI Corporate Classic", "006": "BPI eCredit MasterCard",
            "030": "BPI Express Credit Classic", "040": "BPI Corporate Classic", "060": "BPI Edge MasterCard",
            "070": "BPI Mini Edge Mastercard", "100": "BPI Corporate MasterCard", "101": "BPI Corporate MasterCard",
            "102": "BPI Corporate MasterCard", "103": "BPI Corporate MasterCard", "108": "BPI Corporate MasterCard",
			"109": "BPI Corporate MasterCard", "280": "BPI Gold MasterCard", "290": "BPI Gold MasterCard",
			"292": "BPI SkyMiles Platinum MasterCard", "380": "BPI Blue MasterCard", "390": "BPI Blue MasterCard",
            "391": "Petron-BPI MasterCard", "392": "BPI SkyMiles MasterCard", "397": "BPI Edge MasterCard",
            "398": "BPI Mini Edge Mastercard", "399": "Petron-BPI MasterCard", "490": "BPI Amore Visa",
            "590": "BPI Amore Visa Platinum", "780": "BPI Signature Visa", "781": "BPI Signature Visa", 
			"782": "BPI Signature Visa", "783": "BPI Signature Visa", "784": "BPI Signature Visa"
        };
	//8 digit organization code
	var ORGNOEIGHTCODEJSON = {"880": "BPI Family Credit Card", "881": "BPI Family Credit Card" };
	var callBackErrorStatus=function(response){
	if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) 
	return true
	return false;
	}
	//Error code
	var spinDormErrCodeObj = [
			"SI8370","SI8385","ST0132","ST0155","ST0156","ST0157","ST0158","ST0213","ST0255","ST0280","ST0293","ST0294","ST0295","ST0296",
			"ST0305","ST0306","ST0307","ST0308","ST0310","ST0311","ST0315","ST0316","ST0321","ST0326","ST0331","ST0332","ST0333","IM1478",
			"ST0334","ST0335","ST0336","ST0337","ST0339","ST0340","ST0341","ST0343","ST0345","ST0347","ST0348","ST0349","ST0351","ST0352",
			"ST0353","ST0354","ST0356","ST0357","ST0358","ST0359","ST0360","ST0361","ST0362","ST0363","ST0365","ST0366","ST0367","ST0368",
			"ST0369","ST0409","ST0410","ST0411","ST0412","ST0414","ST0415","ST0441","ST0442","ST0443","ST0453","ST0454","ST0455","ST0456",
			"ST0504","ST0505","ST0508","ST0511","ST0604","ST0605","ST0606","ST0607","ST0608","ST0615","ST0616","ST0617","ST0648","ST0700",
			"ST0703","ST0704","ST0705","ST0706","ST0707","ST0709","ST0715","ST2372","ST3149","ST3431","ST3432","ST4041","ST4042","ST6001",
			"ST6021","ST6022","ST6028","ST6029","ST6030","ST6044","ST6045","ST6052","TS0117","TS0196","TS0203","TS0205","TS0208","TS0209",
			"TS0210","TS0261","TS0293","TS0294","TS0298","TS0343","TS0396","TS0517","TS0518","TS0519","TS0520","TS0521","TS0522","TS0523",
			"TS1372","TS3023","IM0704","IM0705","IM1448","IM1452","IM1473","SI8425","TS0202","TS0292","TS0496","TS0511","TS9286","TS9292",
			"IM0601","IM0048","IM0049","IM0118","IM0126","IM0132","IM0134","IM0135","IM0136","IM0137","IM0138","IM0139","IM0140","IM0141",
			"IM0142","IM0172","IM0173","IM0174","IM0175","IM0199","IM0200","IM0203","IM0265","IM0266","IM0267","IM0268","IM0269","IM0270",
			"IM0271","IM0272","IM0273","IM0282","IM0285","IM0286","IM0287","IM0288","IM0289","IM0291","IM0605","IM0650","IM0700","IM0702"
		];
		
   /**
    * Export
    */
    exports.institutionCode = INSTITUTION_CODE_OBJECT;
    exports.currencyCode = CURRENCY_CODE_OBJECT;
    exports.codeJson = ORGNOONECODEJSON;
    exports.errorStatus = callBackErrorStatus;
    exports.orgEightCode = ORGNOEIGHTCODEJSON;
    exports.errorCode = spinDormErrCodeObj;
	
});
