define( function (require, exports, module) {
    'use strict';

    var utils = require('base').utils;

    /**
     * Services API
     * @param  {object} config and DI to the API
     */
    var API = function(options) {
        this.config = options;
    };


    utils.assign(API.prototype, {

        /*
         * Sample functions to test if configuration is passed to the service.
         *
         * @param core.configuration config
         * @return void
        */
        api: function(name) {
            if (typeof this.config[name] === 'undefined') {
                throw new Error('Unknown service ' + name + ' !!!');
            }
            return this.config[name];
        }

    });

    module.exports = API;
});