'use strict';

/**
 *  ----------------------------------------------------------------
 *  Copyright © Backbase B.V.
 *  ----------------------------------------------------------------
 *  Author : Backbase R&D - Amsterdam - New York
 *  Filename : api.spec.js
 *  Description:
 *  ----------------------------------------------------------------
 */

var API = require('./api');
var mock = require('../test/mock');
var utils = require('base').utils;

/*----------------------------------------------------------------*/
/* Provider service
/*----------------------------------------------------------------*/

describe('Services API', function() {

    var lpModule;

    beforeEach(function() {
        lpModule = new API({
            'my-service': mock.dummies.myService
        });
    });


    describe('lpModule', function() {

        it('should be an object', function() {
            expect(lpModule).toBeObject();
        });

        it('should not throw an error if service injected', function() {
            expect(lpModule.api('my-service')).toBeDefined();
        });

        it('should throw an error if service is not injected', function() {
            expect(lpModule.api.bind(lpModule.api, '$http')).toThrowError();
        });

    });

});