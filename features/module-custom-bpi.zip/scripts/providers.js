define(function(require, exports, module) {
    'use strict';

    var API = require('./api');

    /**
     * Services
     * @param  {DI services list}
     * @return {object}
     * @ngInject
     */
    function Services(MyService) {

        /**
         * To configure the provider before initialisation.
         */
        var config = {
            'my-service': MyService
        };

        return new API(config);
    }

    /**
     * lpModule provider
     * @return {object} angular provider
     * @ngInject
     */
    exports.lpModule = function() {
        this.$get = Services;
    };
});
