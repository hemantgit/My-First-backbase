var mock = require('mock');


var MyService = mock.utils.noop;

// Test Stubs

var stubs = {
};

// Test Dummies

var dummies = {
  myService: function() { return new MyService(); }
}

// Exports

module.exports = {
  dummies: dummies,
  stubs: stubs
};
