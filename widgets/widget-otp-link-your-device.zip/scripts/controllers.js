
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.OtpMainCtrl = function(lpCoreUtils, lpWidget, $window, modalCalService) {
        var self = this;
		var otpRegistrationViaAppNavUrl = lpWidget.getResolvedPreference('otpregistrationviaapp');
		var confirmModal = lpWidget.getResolvedPreference('ConfirmModal');
		var otpStatusModal = lpWidget.getResolvedPreference('OtpStatusModal');
		var rmNumber = $window.sessionStorage.getItem("rmNumber");
		var mobNumber = $window.sessionStorage.getItem('mobileNum');
		if(mobNumber){
			self.maskedMobileNum = mobNumber.substr(0, 3)+' '+mobNumber.substr(3, 3)+' xxx x'+mobNumber.substr(-3);
		}
		self.deviceName = "None";
		//rmNumber =  "00000000633442";
		if(rmNumber && rmNumber !==""){
			self.hideRmDownDiv = true;
		} else{
			self.hideRmDownDiv = false;
		}
		if( $window.sessionStorage.getItem("otpStatus") === "1" ){
			self.showResendActCode = true;
		}
		self.changMobileNumber = function(){
			modalCalService.openModal(confirmModal);
		};
		self.getOTPViaBPMobileApp = function(){
			$window.location.href = otpRegistrationViaAppNavUrl;
		};
		self.resendActivationCode = function(){
			modalCalService.openModal(otpStatusModal);
		};
    };
	exports.modalInstanceCtrl = function($modalInstance,lpWidget, $window, modalCalService ) {
		var miCtrl= this;
		miCtrl.returnMessage = modalCalService.returnMessage;
		miCtrl.cancelModal = function () {
            $modalInstance.dismiss('cancel');
        };
		miCtrl.gotoChangMobileNumber = function() {
			miCtrl.cancelModal();
			var otpChangeMobileNumberNavUrl = lpWidget.getResolvedPreference('otpchangemobilenumber');
			$window.location.href = otpChangeMobileNumberNavUrl;
		}
		miCtrl.resendActivationCode = function(){
			$modalInstance.dismiss('cancel');
			modalCalService.resendActivationCode().then(function(response) {
				// Success Case
			},
			function(response) {
				// Server Error
			});
		};
	};
});