define(function(require, exports, module) {
    'use strict';

    // @ngInject
    exports.modalCalService = function($http, $window, $modal, lpWidget) {
		this.templateDiv = true;
		var protocol_Host = $window.location.protocol+'//'+$window.location.host;
		var RESEND_ACTIVATION_CODE = protocol_Host+lpWidget.getResolvedPreference('resendactivationcode');
        this.openModal = function(CurrentModal) {
            var modalInstance=$modal.open({
            templateUrl:CurrentModal,
            controller: 'modalInstanceCtrl as mic',
            windowClass: 'ModalContainer',
            backdrop: 'static'
            });	
        };
		this.resendActivationCode = function() {
			var reqPayload = {
				"rmNumber": $window.sessionStorage.getItem("rmNumber"),
				"username": $window.sessionStorage.getItem("userName"),
				"mobileNumber": $window.sessionStorage.getItem('mobileNum')
			};
			return $http({
				url: RESEND_ACTIVATION_CODE, 
				method: "POST",
				data: reqPayload
			})
        };

    };

});