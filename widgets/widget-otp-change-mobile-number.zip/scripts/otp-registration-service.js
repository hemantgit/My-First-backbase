define(function(require, exports) {
    'use strict';

    // @ngInject
    exports.modalCalService = function($http, $window, $modal, lpWidget) {
        var self = this;
		var protocol_Host = $window.location.protocol+'//'+$window.location.host;
		var CHANGE_MOBILE_NUMBER = protocol_Host+lpWidget.getResolvedPreference('changemobordevice');
		var FINANCIAL_EMAIL_NOTIFICATION = protocol_Host+lpWidget.getResolvedPreference('financialemailnotif');
        self.openModal = function(CurrentModal) {
            var modalInstance = $modal.open({
                templateUrl: CurrentModal,
                controller: 'modalInstanceCtrl as mic',
                windowClass: 'ModalContainer',
                backdrop: 'static'
            });
        };
		self.communicateCtrl = function(){
			// This will communicate both controllers for calling functions
		}
        self.sendEmailNotification = function(req) {
            return $http({
                url: FINANCIAL_EMAIL_NOTIFICATION,
                method: "POST",
                data: req
            })
        };
        self.changeMobDevice = function(reqPayload) {
            return $http({
                url: CHANGE_MOBILE_NUMBER,
                method: "POST",
                data:reqPayload
            })
        };
        self.getDateConfNum = function(rmNum) {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            var yy = yyyy.toString().slice(-2);
            var hh = today.getHours();
            var minits = today.getMinutes();
            var ss = today.getSeconds();
            var ran = Math.floor((Math.random() * 10));
            if (dd < 10) {
                dd = '0' + dd;
            }
            if (mm < 10) {
                mm = '0' + mm;
            }
            if (hh < 10) {
                hh = '0' + hh;
            }
            if (ss < 10) {
                ss = '0' + ss;
            }
            if (minits < 10) {
                minits = '0' + minits;
            }
            return {
                'transDate': today,
                'confirmationNumber': rmNum.slice(-10) + '' + dd + '' + mm + '' + yy + '' + hh + '' + minits + '' + ss + '' + ran
            };
        };
    };
});