# OTP Registration 

A fine launchpad 12 widget.

## Information

| name                  | version           | bundle           |
| ----------------------|:-----------------:| ----------------:|
| otp-registration      |0.1.0| bpi-eolng-web       |


## Dependencies

* [base][base-url]
* [core][core-url]
* [ui][ui-url]

## Dev Dependencies

* [angular-mocks ~1.2.28][angular-mocks-url]
* [config][config-url]

## Preferences
- List of widget preferences

## Events
- List of event the widget publishes/subscribes

## Custom Components
- list of widget custom components (if any)

## Requirements

### User Requirements

### Business Requirements

## References

[base-url]:http://stash.backbase.com:7990/projects/lpm/repos/foundation-base/browse/
[core-url]: http://stash.backbase.com:7990/projects/lpm/repos/foundation-core/browse/
[ui-url]: http://stash.backbase.com:7990/projects/lpm/repos/ui/browse/
[config-url]: https://stash.backbase.com/projects/LP/repos/config/browse
[api-url]:http://stash.backbase.com:7990/projects/LPM/repos/api/browse/
[angular-mocks-url]:https://github.com/angular/bower-angular-mocks
