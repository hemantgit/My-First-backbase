
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.OtpMainCtrl = function(lpCoreUtils, lpWidget, $window, modalCalService) {
        var self = this;
		var rmNumber = $window.sessionStorage.getItem("rmNumber");
		var mobNumber = $window.sessionStorage.getItem('mobileNum');
		self.deviceName = $window.sessionStorage.getItem("deviceName");
		//rmNumber =  "00000000633442";
		if(mobNumber){
			self.maskedMobileNum = mobNumber.substr(0, 3)+' '+mobNumber.substr(3, 3)+' xxx x'+mobNumber.substr(-3);
		}
		if(rmNumber){
			self.hideRmDownDiv = true;
		} else{
			self.hideRmDownDiv = false;
		}
		self.changMobileNumber = function(){
			var confirmModal = lpWidget.getResolvedPreference('ConfirmModal');
			modalCalService.openModal(confirmModal);
		};
		self.changMobileDevice = function(){
			var okModal = lpWidget.getResolvedPreference('OkModal');
			modalCalService.openModal(okModal);
		};
    };
	exports.modalInstanceCtrl = function($modalInstance, $window, modalCalService ) {
		var miCtrl= this;
		miCtrl.returnMessage = modalCalService.returnMessage;
		miCtrl.cancelModal = function () {
            $modalInstance.dismiss('cancel');
        };
		miCtrl.gotoChangMobileNumber = function() {
			miCtrl.cancelModal();
			var otpChangeMobileNumberNavUrl = lpWidget.getResolvedPreference('otpchangemobilenumber');
			$window.location.href = otpChangeMobileNumberNavUrl;
		}
		miCtrl.changMobileDevice = function(){
			miCtrl.cancelModal();
			modalCalService.changeMobDevice().then(function(response) {
				if (response.data.returnCode == '200') {
					$window.sessionStorage.setItem("deviceId", "");
					$window.sessionStorage.setItem("deviceName", "");
					$window.sessionStorage.setItem("otpStatus", "1");
					var otpLinkYourDeviceNavUrl = lpWidget.getResolvedPreference('otplinkyourdevice');
					$window.location.href = otpLinkYourDeviceNavUrl;
				} else {
					modalCalService.returnMessage = response.data.returnMessage;
					var responseErrorModal = lpWidget.getResolvedPreference('ResponseErrorModal');
					modalCalService.openModal(responseErrorModal);
				}
			},
			function(response) {
				if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
					var serverErrorModal = lpWidget.getResolvedPreference('ServerErrorModal');
					modalCalService.openModal(serverErrorModal);
				}
			});
		};
	};
});