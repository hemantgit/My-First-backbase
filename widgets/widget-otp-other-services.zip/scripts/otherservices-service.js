define(function(require, exports, module) {
    'use strict';

    // @ngInject
    exports.modalCalService = function($http, $window, $modal, lpWidget) {
		var self = this;
		self.templateDiv = true;
		self.returnMessage = "";
		var protocol_Host = $window.location.protocol+'//'+$window.location.host;
		var CHANGE_MOBILE_NUMBER_OR_DEVICE = protocol_Host+lpWidget.getResolvedPreference('changemobordevice');
        self.openModal = function(CurrentModal) {
            var modalInstance=$modal.open({
            templateUrl:CurrentModal,
            controller: 'modalInstanceCtrl as mic',
            windowClass: 'ModalContainer',
            backdrop: 'static'
            });	
        };
		self.changeMobDevice = function() {
			var rmNumber = $window.sessionStorage.getItem("rmNumber");
			var dateConfNum = self.getDateConfNum(rmNumber);
			var reqPayload = {
				"rmNumber": rmNumber,
				"username": $window.sessionStorage.getItem("userName"),
				"mobileNumber": $window.sessionStorage.getItem('mobileNum'),
				"confirmationNumber":dateConfNum.confirmationNumber
			};
			return $http({
				url: CHANGE_MOBILE_NUMBER_OR_DEVICE, 
				method: "POST",
				data: reqPayload
			})
        };
		self.getDateConfNum = function(rmNum) {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            var yy = yyyy.toString().slice(-2);
            var hh = today.getHours();
            var minits = today.getMinutes();
            var ss = today.getSeconds();
            var ran = Math.floor((Math.random() * 10));
            if (dd < 10) {
                dd = '0' + dd;
            }
            if (mm < 10) {
                mm = '0' + mm;
            }
            if (hh < 10) {
                hh = '0' + hh;
            }
            if (ss < 10) {
                ss = '0' + ss;
            }
            if (minits < 10) {
                minits = '0' + minits;
            }
            return {
                'transDate': today,
                'confirmationNumber': rmNum.slice(-10) + '' + dd + '' + mm + '' + yy + '' + hh + '' + minits + '' + ss + '' + ran
            };
        };
		
    };

});