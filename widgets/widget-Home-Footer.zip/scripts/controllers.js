/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : homeFooterCtrl.js
 *  Description: BPI Home Footer controller
 *  ----------------------------------------------------------------
 */ 
define(function(require, exports) {

    'use strict';

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget) {
		console.log("Start Time FOOTER"+new Date().toLocaleString()+' '+new Date().getMilliseconds());
        var bpiCtrl = this;
        var utils = lpCoreUtils;
        var widget = lpWidget;
        bpiCtrl.logo = utils.resolvePortalPlaceholders(widget.model.getPreference('logo')) || ''
        bpiCtrl.bancnet = utils.resolvePortalPlaceholders(widget.model.getPreference('bancnet')) || ''
        bpiCtrl.verisign = utils.resolvePortalPlaceholders(widget.model.getPreference('verisign')) || ''
		bpiCtrl.facebook = utils.resolvePortalPlaceholders(widget.model.getPreference('facebook')) || '';
		bpiCtrl.twitter = utils.resolvePortalPlaceholders(widget.model.getPreference('twitter')) || '';
		bpiCtrl.youtube = utils.resolvePortalPlaceholders(widget.model.getPreference('youtube')) || '';
		
		var footerHeight=angular.element(".page-container [data-pid*='Footer']").height();
		angular.element('.page-container [data-pid*="container-simple-page-layout"]').css('padding-bottom',footerHeight);
		
                var modal = document.getElementById("myModal");
                var cont = document.getElementsByClassName("sessionCont")[0];
                var cancelX = document.getElementsByClassName("sessionClose")[0];
				var cancel = document.getElementsByClassName("sessionClose")[1];
				//  var timeOut1 = null;
				//  var alertTime = null;
				//  var timeout = 300000; // session time out time is 5 min
				//  var gracetime = 240000; //grace time to show popup is 4 min
                /*function refresh() {

                        if (new Date().getTime() - time >= timeout) {
                                self.doLogoutForSessionTimeOut();
                        } else if (new Date().getTime() - time >= gracetime && new Date().getTime() - time < timeout) {
                                openModal();
                                timeOut1 = setTimeout(self.doLogoutForSessionTimeOut, timeout - gracetime);
                        } else {
                                setTimeout(refresh, 10000);
                        }
                }*/
                var linkTo;
				/* Open links in the footer */
                bpiCtrl.openModal=function (social) {
                        modal.style.display = "block";
						if(social==="facebook")
						{
						linkTo="http://www.facebook.com/bpi";
						}
						else if(social==="twitter")
						{
						linkTo="https://twitter.com/TalktoBPI";
						}
						else if(social==="youtube")
						{
						linkTo="http://youtube.com/user/BPIvideochannel";
						}
                }
                bpiCtrl.closeModal=function() {
                        modal.style.display = "none";
                }
        /* on Click of continue on popup */

                cont.onclick = function() {
                        bpiCtrl.closeModal();
                      window.open(linkTo, '_blank');
                };

        /* on Click of cancel on popup */

                cancel.onclick = function() {
					bpiCtrl.closeModal();
                };
				cancelX.onclick = function() {
					bpiCtrl.closeModal();
                };

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
	}

});