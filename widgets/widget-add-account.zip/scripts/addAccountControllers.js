/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : addAccountControllers.js
 *  Description: Add Account - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject


    exports.MainCtrl = function($http, lpCoreUtils, lpWidget, lpPortal, $window, addAccountService, $filter, $scope) {
        var self = this;
        var widget = lpWidget;

        self.CreditCard = addAccountService.getImage('CreditCard');
        self.Prepaid = addAccountService.getImage('Prepaid')
        self.Investments = addAccountService.getImage('Investments');
        self.Loans = addAccountService.getImage('Loans');
        self.DebitWithCard = addAccountService.getImage('DebitWithCard');
        //Navigation urls
        var protocolHost = $window.location.protocol + '//' + $window.location.host;
        var accountDetailsUrl = protocolHost + widget.getResolvedPreference('goToHome');
        self.Accountradio = 'Deposit Account';

        //self.accountNumbers=[];
        self.accountNumbers = [{}];

        //self.accountNumbers.length=1;
        self.addAccountNumber = function() {
            var addAccountFlag = "Y";
            angular.forEach(self.accountNumbers, function(acc) {
                if (acc.accountNumber === undefined || acc.accountNumber.trim() === "")
                    addAccountFlag = "N";
            });
            if (addAccountFlag === "Y") {
                self.errorMessage = "";
                self.errorSection = "false";
                self.accountNumbers.push({});
            } else {
                self.errorMessage = "Please enter Account Number"
                self.errorSection = "true";
            }
        }
        self.removeAccountNumber = function(index) {
            if (self.accountNumbers.length > 1) {
                self.errorMessage = "";
                self.errorSection = "false";
                //var lastItem = self.accountNumbers.length-1;
                self.accountNumbers.splice(index, 1);
            }
        };
        addAccountService.clearFields = function() {
            self.clearFields();
        }

        self.clearFields = function() {
            console.log("clear");
            self.accountNumbers = [{}];
            self.errorMessage = "";
        }
        /*RMTrailer response */
        var rmNumber = $window.sessionStorage.getItem("rmNumber");
        var userName = $window.sessionStorage.getItem("userName");
        // Static RMNumber for Offshore testing
        //rmNumber = "00000009117158";
        var rmTrailerResponse = JSON.parse($window.sessionStorage.getItem("accounts"));
        var rmTrailerRequest = {};
        rmTrailerRequest.rmNumber = rmNumber;
        rmTrailerRequest.rmFlag = "A";

        //footer page panel expand and collapse
        self.expanded = false;
        self.closed = true;
        self.expand = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        };

        var rmAccounts = {};
        self.getRm = function() {
            addAccountService.GetRMTrailer(rmTrailerRequest).then(function(response) {
                    rmAccounts = response.data.RMTrailers;
                }),
                function(response) {
                    rmAccounts = {};
                }
        }
        self.getRm();

        //open Account confirmation model
        self.openConfirmModal = function(accNumbers) {
            var accType = self.Accountradio;
            var addAccountPayload = {};
            var depositAccoutns = [];
            var investmentAccoutns = [];
            var addAccountsRequest = {}
            var validAccountFlag;
            var emptyAccountFlag;
            var confirmationNoGen = new Date();
            var confirmationNumber = "00001" + $filter('date')(confirmationNoGen, "yyyyMMddHHmmss") + Math.floor(1000 + Math.random() * 9000);
            addAccountService.confirmationNumber = confirmationNumber;
            var payloadFlag = null;
            var rmIbAcctFlag = "";
            var accInelegibleFlag = ""
            var rmt = "";

            /* Account Number Validation */
            self.accountNumberValidation = function(accNumbers, length) {
                angular.forEach(accNumbers, function(accNumber) {
                    if (accNumber.accountNumber == undefined || accNumber.accountNumber.toString().trim().length < length) {
                        validAccountFlag = "false"
                    }
                    if (accNumber.accountNumber == undefined || accNumber.accountNumber.toString().trim() == "") {
                        emptyAccountFlag = "true";
                    }

                })
            }


            var accountAvailableFlag = "";

            function returnDepositAccountValidation(rmt, accNumber) {
                if (rmt.rmAcctNumber.trim().replace(/\b0+/g, '') == accNumber.accountNumber.replace(/\b0+/g, '') && (rmt.rmAcctApplicationId == "TD" || rmt.rmAcctApplicationId == "ST" || rmt.rmAcctApplicationId == "IM")) {
                    return true;
                } else {
                    return false;
                }
            }

            function returnInvestmentAccountValidation(rmt, accNumber) {
                if (rmt.rmAcctNumber.trim().replace(/\b0+/g, '') == accNumber.accountNumber.replace(/\b0+/g, '') && (rmt.rmAcctApplicationId == "UI" || rmt.rmAcctApplicationId == "MF")) {
                    return true;
                } else {
                    return false;
                }
            }

            function checkAccountInRmDeposit(rmt, accNumber) {
                if (returnDepositAccountValidation(rmt, accNumber)) {
                    accountAvailableFlag = "Y";
                    self.rmt = rmt;
                } else {

                    self.rmt = rmt;
                    accountAvailableFlag = "N";

                    if (rmAccounts != undefined && rmAccounts.length != -1) {

                        angular.forEach(rmAccounts, function(account) {
                            if (returnDepositAccountValidation(account, accNumber)) {

                                self.rmt = account;
                                accountAvailableFlag = "Y";
                            }

                        })
                    } else {
                        self.rmt = rmt;
                        accountAvailableFlag = "N";
                    }
                }
            }

            function checkAccountInRmInvestment(rmt, accNumber) {
                if (returnInvestmentAccountValidation(rmt, accNumber)) {
                    accountAvailableFlag = "Y";
                    self.rmt = rmt;
                } else {

                    self.rmt = rmt;
                    accountAvailableFlag = "N";

                    if (rmAccounts != undefined && rmAccounts.length != -1) {

                        angular.forEach(rmAccounts, function(account) {
                            if (returnInvestmentAccountValidation(account, accNumber)) {
                                self.rmt = account;
                                accountAvailableFlag = "Y";
                            }
                        })
                    } else {
                        self.rmt = rmt;
                        accountAvailableFlag = "N";
                    }
                }
            }
            self.checkAccountInRm = function(accNumber, type) {


                angular.forEach(rmTrailerResponse, function(rmt) {

                    if (type == "Deposit Account") {
                        checkAccountInRmDeposit(rmt, accNumber);
                    } else if (type == "Investment Account") {
                        checkAccountInRmInvestment(rmt, accNumber);

                    } else {
                        self.rmt = rmt;
                        accountAvailableFlag = "N";
                        if (rmt.rmAcctNumber.trim().replace(/\b0+/g, '') == accNumber.accountNumber.replace(/\b0+/g, '')) {
                            accountAvailableFlag = "Y";
                            self.rmt = rmt;
                        }
                    }
                });


            }
			
			/*Adding Depsit payload */
			function addDepositLinkedAccountPayload(rmt){
				if (rmt.rmRelCode.slice(-3) !== "JAN") {
					if (rmt.rmAcctApplicationId == "TD") {
						addAccountPayload.accountType = "ST";
					} else {
						addAccountPayload.accountType = rmt.rmAcctApplicationId;
					}
					addAccountPayload.institutionCode = rmt.rmAcctControl1;
					addAccountPayload.currencyCode = rmt.rmAcctControl2;
					addAccountPayload.branchCode = rmt.rmAcctControl3;
					addAccountPayload.control4 = rmt.rmAcctControl4;
					addAccountPayload.rmLinkFlag = "Y";
					addAccountPayload.accountNumber = rmt.rmAcctNumber.trim();
					addAccountPayload.relaCode = rmt.rmRelCode;
					depositAccoutns.push(addAccountPayload);
					payloadFlag = "Y";
					rmIbAcctFlag = "N";
				} else {
					accInelegibleFlag = "Y";
				}
			}
			/*Adding Investment Payload */
			function addInvestmentLinkedAccountPayload(rmt){
				if (rmt.rmIbAcctFlag == "N") {
					addAccountPayload.accountNumber = rmt.rmAcctNumber.trim();
					addAccountPayload.accountType = "INV";
					addAccountPayload.rmLinkFlag = "Y";
					addAccountPayload.accountControl1 = rmt.rmAcctControl1;
					addAccountPayload.accountControl2 = rmt.rmAcctControl2;
					addAccountPayload.accountControl3 = rmt.rmAcctControl3;
					addAccountPayload.accountControl4 = rmt.rmAcctControl4;
					investmentAccoutns.push(addAccountPayload);
					payloadFlag = "Y";
					rmIbAcctFlag = "N";
				} else if (rmt.rmIbAcctFlag == "Y") {
					payloadFlag = "N";
					rmIbAcctFlag = "Y"
				}
			}

            /* Fetch palyload for Deposit and investment accounts */
	
            self.fetchPayload = function(rmTrailerResponse, accNumbers) {

                angular.forEach(accNumbers, function(accNumber) {
                    self.checkAccountInRm(accNumber, accType);
                    rmt = self.rmt;
                    if (accType == "Deposit Account") {
                        if (accountAvailableFlag == "Y") {
                            console.log("Deposit Account available in RM");

                            if (rmt.rmIbAcctFlag == "N") {
								addDepositLinkedAccountPayload(rmt);
                                
                            } else if (rmt.rmIbAcctFlag == "Y") {
                                payloadFlag = "N";
                                rmIbAcctFlag = "Y"
                            }

                        } else if (accountAvailableFlag == "N") {

                            console.log("Deposit Account not available in RM");
                            addAccountPayload.accountType = "";
                            addAccountPayload.institutionCode = "";
                            addAccountPayload.currencyCode = "";
                            addAccountPayload.branchCode = "";
                            addAccountPayload.control4 = "";
                            addAccountPayload.rmLinkFlag = "N";
                            addAccountPayload.accountNumber = accNumber.accountNumber;
                            addAccountPayload.relaCode = "";
                            depositAccoutns.push(addAccountPayload);
                            payloadFlag = "Y";
                            rmIbAcctFlag = "N";
                        }
                    } else if (accType == "Investment Account") {
                        if (accountAvailableFlag == "Y") {
                            console.log("Investment Account available in RM");
							addInvestmentLinkedAccountPayload(rmt);
                            
                        } else if (accountAvailableFlag == "N") {
                            console.log("Investment Account not available in RM");
                            addAccountPayload.accountNumber = accNumber.accountNumber;
                            addAccountPayload.accountType = "INV";
                            addAccountPayload.rmLinkFlag = "N";
                            addAccountPayload.accountControl1 = "";
                            addAccountPayload.accountControl2 = "";
                            addAccountPayload.accountControl3 = "";
                            addAccountPayload.accountControl4 = "";
                            investmentAccoutns.push(addAccountPayload);
                            payloadFlag = "Y";
                            rmIbAcctFlag = "N";
                        }
                    }
                })
            }
            console.log(accType);
            //var removeParams = {};
			
			/* Deposit Account Payload */
			function depositPayloadRequest(){
				self.accountNumberValidation(accNumbers, 10);

                if (validAccountFlag != "false") {

                    self.errorMessage = ""
                    self.errorSection = "false";

                    self.fetchPayload(rmTrailerResponse, accNumbers);
                    console.log("payloadFlag " + payloadFlag + "rmIbAcctFlag" + rmIbAcctFlag);
                    if (payloadFlag == "Y" && rmIbAcctFlag == "N") {
                        addAccountsRequest.rmNumber = rmNumber;
                        addAccountsRequest.confirmationNumber = confirmationNumber;
                        addAccountsRequest.platform = "web";
                        addAccountsRequest.userName = userName;
                        addAccountsRequest.EnrollDepositAccount = depositAccoutns;

                        addAccountService.addAccountsRequest = addAccountsRequest;
                        addAccountService.openModal("confirmAccountModal.html");


                        addAccountService.accountNumbers = accNumbers;
                        addAccountService.accountType = accType;
                        addAccountService.setAccountDetails(accType, accNumbers);

                    } else if (payloadFlag == "N" && rmIbAcctFlag == "Y") {
                        self.errorMessage = "Account number already added";
                        self.errorSection = "true";
                    } else if (accInelegibleFlag == "Y") {
                        self.errorMessage = "The account you entered is ineligible for enrollment"
                        self.errorSection = "true";
                    }
                } else if (emptyAccountFlag == "true") {
                    self.errorMessage = "Please fill out the following field"
                    self.errorSection = "true";
                } else {
                    self.errorMessage = "Account number is minimum of 10 digits"
                    self.errorSection = "true";
                }
			}
			/* Investment Account Payload */
			function investmentPayloadRequest(){
			self.accountNumberValidation(accNumbers, 15);
                if (validAccountFlag != "false") {
                    self.errorMessage = ""
                    self.errorSection = "false";
                    var acctApplicationId = "FD";
                    self.fetchPayload(rmTrailerResponse, accNumbers, acctApplicationId);
                    console.log("payloadFlag " + payloadFlag);
                    if (payloadFlag == "Y" && rmIbAcctFlag == "N") {
                        addAccountsRequest.rmNumber = rmNumber;
                        addAccountsRequest.confirmationNumber = confirmationNumber;
                        addAccountsRequest.platform = "web";
                        addAccountsRequest.userName = userName;
                        addAccountsRequest.EnrollInvestmentAccount = investmentAccoutns;

                        addAccountService.addAccountsRequest = addAccountsRequest;
                        addAccountService.openModal("confirmAccountModal.html");
                        addAccountService.accountNumbers = accNumbers;
                        addAccountService.accountType = accType;
                        addAccountService.setAccountDetails(accType, accNumbers);

                    } else if (payloadFlag == "N" && rmIbAcctFlag == "Y") {
                        self.errorMessage = "Account number already added";
                        self.errorSection = "true";
                    } else {
                        self.errorMessage = "The Account number you entered is Invalid"
                        self.errorSection = "true";
                    }
                } else if (emptyAccountFlag == "true") {
                    self.errorMessage = "Please fill out the following field"
                    self.errorSection = "true";
                } else {
                    self.errorMessage = "Account number is minimum of 15 digits"
                    self.errorSection = "true";
                }
			}
			/* Credit card Account Payload */
			function creditcardPayloadRequest(){
				self.accountNumberValidation(accNumbers, 16);
                if (validAccountFlag != "false") {
                    var creditCardAccuonts = [];
                    creditCardAccuonts = accNumbers;
                    angular.forEach(creditCardAccuonts, function(acc) {
                        acc.accountType = "CC";

                    })
                    addAccountsRequest.rmNumber = rmNumber;
                    addAccountsRequest.confirmationNumber = confirmationNumber;
                    addAccountsRequest.accounts = creditCardAccuonts;
                    addAccountsRequest.platform = "web";

                    addAccountService.addAccountsRequest = addAccountsRequest;
                    addAccountService.openModal("confirmAccountModal.html");
                    addAccountService.accountNumbers = accNumbers;
                    addAccountService.accountType = accType;
                } else if (emptyAccountFlag == "true") {
                    self.errorMessage = "Please fill out the following field"
                    self.errorSection = "true";
                } else {
                    self.errorMessage = "Account number is minimum of 16 digits"
                    self.errorSection = "true";
                }
			}
			/* Loan Account Payload */
			function loanPayloadRequest(){
				self.accountNumberValidation(accNumbers, 14);
                if (validAccountFlag != "false") {
                    var loanAccuonts = [];
                    loanAccuonts = accNumbers;
                    angular.forEach(loanAccuonts, function(acc) {
                        acc.accountType = "LON";
                    })
                    addAccountsRequest.rmNumber = rmNumber;
                    addAccountsRequest.confirmationNumber = confirmationNumber;
                    addAccountsRequest.accounts = loanAccuonts;
                    addAccountsRequest.platform = "web";

                    addAccountService.addAccountsRequest = addAccountsRequest;
                    addAccountService.openModal("confirmAccountModal.html");
                    addAccountService.accountNumbers = accNumbers;
                    addAccountService.accountType = accType;
                } else if (emptyAccountFlag == "true") {
                    self.errorMessage = "Please fill out the following field"
                    self.errorSection = "true";
                } else {
                    self.errorMessage = "Account number is minimum of 14 digits"
                    self.errorSection = "true";
                }
			}
			/* Loan Account Payload */
			function prepaidcardPayloadRequest(){
				self.accountNumberValidation(accNumbers, 16);
                if (validAccountFlag != "false") {
                    var prepaidCardAccuonts = [];

                    //prepaidCardAccuonts=accNumbers;
                    angular.forEach(accNumbers, function(acc) {
                        var prepaidCard = {};
                        prepaidCard.cardholderName = "";
                        prepaidCard.accountType = "PC";
                        prepaidCard.cardholderNumber = acc.accountNumber;
                        prepaidCard.atmCardNumber = "";
                        prepaidCard.atmCardJAI = "";
                        prepaidCard.relationshipAndPurpose = "";
                        prepaidCardAccuonts.push(prepaidCard);
                    })
                    addAccountsRequest.rmNumber = rmNumber;
                    addAccountsRequest.confirmationNumber = confirmationNumber;
                    addAccountsRequest.platform = "web";
                    addAccountsRequest.userName = userName;
                    addAccountsRequest.EnrollPrepaidCards = prepaidCardAccuonts;

                    addAccountService.addAccountsRequest = addAccountsRequest;
                    addAccountService.openModal("confirmAccountModal.html");
                    addAccountService.accountNumbers = accNumbers;
                    addAccountService.accountType = accType;
                } else if (emptyAccountFlag == "true") {
                    self.errorMessage = "Please fill out the following field"
                    self.errorSection = "true";
                } else {
                    self.errorMessage = "Card number is minimum of 16 digits"
                    self.errorSection = "true";
                }
			}
			
			
			
            if (accType == "Deposit Account") {
				depositPayloadRequest();
            } else if (accType == "Investment Account") {
				investmentPayloadRequest();
            } else if (accType == "Credit Card Account") {
                creditcardPayloadRequest();
            } else if (accType == "Loan Account") {
				loanPayloadRequest();
                
            } else if (accType == "Prepaid Card Account") {
				prepaidcardPayloadRequest();
            }

        };


        //RequestSubmitted Modal
        self.openRequestSubmittedModal = function() {
            addAccountService.openModal("requestSubmittedModal.html");
        };
        self.goToHomePage = function() {
            $window.location.href = accountDetailsUrl;
        };

        //refreshError

        addAccountService.getRefreshError = function() {
            var msg = addAccountService.errorMsg;
            if (msg != "" || msg != undefined) {
                self.errorMessage = addAccountService.errorMsg;
                self.errorSection = "true";
            }

        }


    };
    exports.ModalInstanceController = function($modalInstance, $window, addAccountService, $scope, $filter, lpCoreUtils, lpWidget) {
        addAccountService.refreshError();
        var self = this;
        var widget = lpWidget;

        var accDetailsObj = addAccountService.getAddAccountDetails();
        var today = new Date();
        self.confirmationNumDate = addAccountService.conDate;
        var rmNumber = $window.sessionStorage.getItem("rmNumber");
        var todayDate = $filter('date')(today, "MMM dd yyyy,hh:mm a");
        var accNoPresent = "true";
        //Random 10 digit confirmation No
        self.randomConfirmationNo = addAccountService.confirmationNumber;
        self.confirmationDate = $filter('date')(self.confirmationNumDate.transDate, "MMM dd yyyy,hh:mm a");


        var params = addAccountService.addAccountsRequest;
        self.tickIcon = addAccountService.getImage('tick');
        self.closeokModal = function() {
            $modalInstance.dismiss('cancel');
        };
        self.accDetailsObj = addAccountService.getAddAccountDetails();
        var accType = self.accDetailsObj.accountType;

        if (accType == "Deposit Account") {
            var accNumbers = params.EnrollDepositAccount;
            for (var i = 0; i < accNumbers.length; i++) {
                if (accNumbers[i].rmLinkFlag === "N")
                    accNoPresent = "false";
            }
        }
        if (accType == "Investment Account") {
            var accNumbers = params.EnrollInvestmentAccount;
            for (var i = 0; i < accNumbers.length; i++) {
                if (accNumbers[i].rmLinkFlag === "N")
                    accNoPresent = "false";
            }
        }
        self.params = params;

        self.openAccountAddedModal = function() {

            addAccountService.clearFields();
            angular.element(".accountsloader").removeClass("hidden");
            self.disableConfButton = true;
            addAccountService.addUserCard(params).then(function(response) {
                var data = response.data;
                var accNo = null;
                angular.element(".accountsloader").addClass("hidden");
                if (accNoPresent === "true" && (data.returnCode === "0" || data.returnCode === "00")) {
                    self.closeokModal();
                    addAccountService.conDate = addAccountService.getConfNum(rmNumber);
                    self.confirmationNumDate = addAccountService.conDate;

                    if (accType == "Deposit Account")
                        accNo = params.EnrollDepositAccount[0].accountNumber.substr(-4);
                    else if (accType == "Investment Account")
                        accNo = params.EnrollInvestmentAccount[0].accountNumber.substr(-4);
                    else if (accType == "Prepaid Card Account")
                        accNo = params.EnrollPrepaidCards[0].cardholderNumber.substr(-4);
                    else
                        accNo = params.accounts[0].accountNumber.substr(-4);


                    if (accType == "Deposit Account" || accType == "Investment Account") {
                        var maskAccnoutNumber = 'xxxx-xx' + accNo.substr(0, 2) + '-' + accNo.substr(-2);
                        var messageSTP = "We have already processed your request for additional account enrollment. You may now view account number " + maskAccnoutNumber + " in your portfolio."
                        self.sendEmailNotification(messageSTP);
                        addAccountService.openModal("accountAddedModal.html");
                    } else {
                        var messageNonSTP = "Your request for an additional account enrollment will be processed within (3) three banking days. We will confirm by e-mail after we have activated your additional account enrollment."
                        self.sendEmailNotification(messageNonSTP);
                        addAccountService.openModal("requestSubmittedModal.html");
                    }
                } else if (accNoPresent === "false") {
                    self.closeokModal();
                    addAccountService.conDate = addAccountService.getConfNum(rmNumber);
                    self.confirmationNumDate = addAccountService.conDate;
                    var messageNonSTP = "Your request for an additional account enrollment will be processed within (3) three banking days. We will confirm by e-mail after we have activated your additional account enrollment."
                    self.sendEmailNotification(messageNonSTP);
                    addAccountService.openModal("requestSubmittedModal.html");
                } else {
                    addAccountService.refreshError('No Valid Account');
                    addAccountService.getRefreshError();
                    self.closeokModal();
                    self.disableConfButton = false;
                }
            }, function(response) {
                angular.element(".accountsloader").addClass("hidden");
                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                    addAccountService.refreshError('Unexpected server error occurred');
                    addAccountService.getRefreshError();
                    self.closeokModal();
                    self.disableConfButton = false;
                }
            });


        };

        self.sendEmailNotification = function(message) {
            //Request to be made dynamic
            var emailId = $window.sessionStorage.getItem('emailId');
            var firstName = $window.sessionStorage.getItem('firstName');
            var lastName = $window.sessionStorage.getItem('lastName');
            var todayDate = $filter('date')(self.confirmationNumDate.transDate, "MMM dd yyyy,hh:mm a");
            var request = {
                "msg": {
                    "from": "abc@bpi.com.ph",
                    "to": emailId,
                    "subject": "Your BPI Express Online Additional Account Enrollment",
                    "html": " <html><head></head>" +
                        "<body><div class='row'><div class='col-md-12'><h3>Dear " + firstName + " " + lastName + ",</h3><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>Registration Date & Time : " + todayDate + "</div></div><div class='col-md-12'>Confirmation Number      : " + self.confirmationNumDate.confirmationNumber + "</div><p>" + message + "</p><p>Thank you for banking with us.</p><p>From the BPI Express Online team.</p></div></body></html>"
                }
            };
            addAccountService.sendEmailNotification(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    //This call is getting failure
                });
        };

    };


});