/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : addAccountService.js
 *  Description: Add Account - service
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
        "use strict";

    // @ngInject
        exports.addAccountService = function($http,$modal, $window,$filter,lpWidget,lpCoreUtils) {
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var ADD_DEPOSIT = protocolHost+lpWidget.getResolvedPreference('enrolldepositaccount');
		var ADD_INVESTMENT = protocolHost+lpWidget.getResolvedPreference('enrollinvestmentaccount');
		var ADD_LOANS = protocolHost+lpWidget.getResolvedPreference('enrollccac');
		var ADD_PREPAID = protocolHost+lpWidget.getResolvedPreference('enrollprepaidcard');
		var RM_TRAILER = protocolHost+lpWidget.getResolvedPreference('rmTrailerService');
		var EMAIL_NOTIFICATION = protocolHost+lpWidget.getResolvedPreference('emailNotification');
		var self=this;
		var accountType="";
		var accountNo;
		self.conDate={};
		self.setAccountDetails=function(accountType,accountNumbers){
		
		self.accountType=accountType;
		self.accountNumbers=accountNumbers;
		};
		
		//Getting Account details from add account page
		self.getAddAccountDetails=function(){
		//alert(self.accountType+'abb--abb'+self.accountNo);
		var accDetailsObj={};
		accDetailsObj.accountType=self.accountType;
		accDetailsObj.accountNumbers=self.accountNumbers;
		return accDetailsObj;
		};

			
		//open Model
		self.openModal = function(CurrentModal) {
            var modalInstance=$modal.open({
            templateUrl:CurrentModal,
            controller: 'ModalInstanceController as mic',
            windowClass: 'ModalContainer',
            backdrop: 'static'
            }); 
        };
		
		 self.addUserCard = function(req) {
		  if(self.accountType==='Deposit Account'){
          return $http({
                url: ADD_DEPOSIT,
                method: "POST",
                data: req,
				headers: {'URL':'ENROLL_DEPOSIT_ACCOUNT','KEY':'SPRINT1B','VALUE':'YES'}
             
			});
		}
		 else if(self.accountType==='Investment Account'){
          return $http({
                url: ADD_INVESTMENT,
                method: "POST",
                data: req,
				headers: {'URL':'ENROLL_INVESTMENT_ACCOUNT','KEY':'SPRINT1B','VALUE':'YES'}				
			});
		}
		 else if(self.accountType==='Credit Card Account' || self.accountType==='Loan Account'){
          return $http({
                url:  ADD_LOANS, 
                method: "POST",
                data: req,
				headers: {'URL':'ENROLL_CC_AC','KEY':'SPRINT1B','VALUE':'YES'}
			});
		}
		 else if(self.accountType==='Prepaid Card Account'){
          return $http({
                url: ADD_PREPAID, 
                method: "POST",
                data: req,
				headers: {'URL':'ENROLL_PREPAID_CARD','KEY':'SPRINT1B','VALUE':'YES'}
           
			});
		}
        };
		self.getConfNum = function(rmNumber) {
            var today = new Date();
            return {
                'transDate': today,
                'confirmationNumber': "00001"+$filter('date')(today, "yyyyMMddHHmmss")+ Math.floor(1000 + Math.random() * 9000)
            };
        };
		self.GetRMTrailer = function(req) {
            return $http({
                    url: RM_TRAILER,
                    method: "POST",
                    data: req,
					headers: {'URL':'RM_TRAILER','KEY':'SPRINT1B','VALUE':'YES'}
                    // Static API for Offshore testing
                  /*  url: "https://api.myjson.com/bins/qkku5",
                    method: "GET",*/
                });
        };
	 self.sendEmailNotification = function(req) {
		return $http({
			url: EMAIL_NOTIFICATION,
			method: "POST",
			data: req,
			headers: {'URL':'FINANCIAL_EMAIL_NOTIF'}
			
		})
	}
	self.refreshError=function(err){
		self.errorMsg=err;
	}
	self.getImage = function (value) {
            return lpCoreUtils.resolvePortalPlaceholders(lpWidget.model.getPreference(value)) || "";
        }
		
	self.clearFields=function(){
		// This function communicate main controll and modal controll
	}
};
});