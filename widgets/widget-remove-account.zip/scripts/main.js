/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : main.js
 *  Description: Add Account - main
 *  ----------------------------------------------------------------
 */

define( function (require, exports, module) {

        "use strict";

        module.name = "widget-remove-account";

        var base = require("base");
        var core = require("core");
        var ui = require("ui");

        var deps = [
                core.name,
                ui.name
        ];

    // @ngInject
        function run() {
        // Module is Bootstrapped
        }

        module.exports = base.createModule(module.name, deps)
        .controller( require("./removeAccountControllers") )
        .service( require("./removeAccountService") )
        .run( run );
});