/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : removeAccountControllers.js
 *  Description: Remove Account controller
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {


    // @ngInject
    exports.ModalInstanceController = function($modalInstance, RemoveAccountService, lpCoreUtils, lpWidget, $window, $filter) {

      //  var rmNumber = "00000010210007";
		var rmNumber = $window.sessionStorage.getItem("rmNumber");	
		//rmNumber = "00000010210007";
        var self = this;
        var today = new Date();
        var todayDate = $filter('date')(today, "MMM dd, yyyy,hh:mm a");
        //Random 10 digit confirmation No
        self.randomConfirmationNo = "00001"+$filter('date')(today, "yyyyMMddHHmmss")+ Math.floor(1000 + Math.random() * 9000);
        self.confirmationDate = todayDate;
        //Error Message
        self.errorMsg = "No Accounts Selected";
		self.errorInAccountMsg="Not able to remove the accounts at this time.Try again"
        //Getting the selected account info from the remove account page to modal
        var params = RemoveAccountService.GetSelectedAccountInfo();
		self.accountDetailsObj =RemoveAccountService.preferredNames;
		//Navigation urls
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var accountDetailsUrl = protocolHost+lpWidget.getResolvedPreference('goToHome');	
        //Close the modal 
        self.CloseModal = function() {
            $modalInstance.dismiss('cancel');
            //$window.location.reload();
        };
        self.CloseModalAndReloadPage = function() {
            $modalInstance.dismiss('cancel');
			$window.location.href = accountDetailsUrl;
            //$window.location.reload();
        };
			 
        //Validation and opening Account Removed Modal
        self.OpenAccountRemovedModal = function() {
			
        //rmNumber="00000010210007";
			self.disableConfButton=true;
			
			 
					angular.element(".accountsloader").removeClass("hidden");	
                  // alert(JSON.stringify(params));
                    RemoveAccountService.removeUserCards(params).then(function(response) {
                            var data = response.data;
							angular.element(".accountsloader").addClass("hidden");	
							self.disableConfButton=false;
                            if (data.returnCode === "0" || data.returnCode === "00") {
                                $modalInstance.dismiss('cancel');
								self.sendEmailNotification(params);
								//RemoveAccountService.OpenModal("validationMsgModal.html");
                                RemoveAccountService.OpenModal("accountRemovedModal.html");
                            } else {
								RemoveAccountService.OpenModal("validationMsgModal.html");
                                //alert("Processing Done With Errors");
                            }
                        },
                        function(response) {
							self.disableConfButton=false;
							angular.element(".accountsloader").addClass("hidden");	
							RemoveAccountService.OpenModal("validationMsgModal.html");
                        })
                
        };
		self.sendEmailNotification = function(params) {
            //Request to be made dynamic
			var today = new Date();
            var emailId = $window.sessionStorage.getItem('emailId');
            var todayDate = $filter('date')(today, "MMM dd yyyy,hh:mm a");
			var firstName = $window.sessionStorage.getItem('firstName');
            var lastName = $window.sessionStorage.getItem('lastName');
			var accNo=[];
			
			angular.forEach(params.RemoveAccount,function(account){
				var accNoTrim=account.accountNumber.substr(-4);
				accNo.push('xxxx-xx'+accNoTrim.substr(0,2)+'-'+accNoTrim.substr(-2));
			})
			
			var maskAccnoutNumber = accNo.toString();
            //var tranSrcAccccNo = "XXXX-XX" + srcNo + "-" + srcThreeDigits + " (" + self.payBillObj.preferredName + ")";
            var request = {
                "msg": {
                    "from": "abc@bpi.com.ph",
                    "to": emailId,
                    "subject": "Your BPI Express Online Additional Account Enrollment",
                    "html": " <html><head></head>" +
                        "<body><div class='row'><div class='col-md-12'><h3>Dear "+firstName+" "+lastName+",</h3><div class='col-md-12'><p>Greetings from BPI Express Online!</p></div><div class='col-md-12'>Your request for the removal of account number "+maskAccnoutNumber+" in Express Online has already been completed.</div><p>Should have questions,comments, or suggestions,please e-mail us at expressonline@bpi.com.ph. or you may call 89100 and dial 0 to talk to a phonebanker. These communication channels are available to you 24 hours a day, 7 days a week.</p><p>Thank you!</p><p>From The BPI Express Online Team </p></div></body></html>"
                }
            };
            RemoveAccountService.sendEmailNotification(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    //This call is getting failure
                });
        };
    };

    "use strict";
    exports.MainCtrl = function(RemoveAccountService,$scope, $http, $filter, lpCoreUtils, lpWidget, lpPortal, $window) {
        var self = this;
        var utils = lpCoreUtils;
        var widget = lpWidget;
        var selectedAccountInfo = [];
		var today = new Date();
		var params={};
		//var control4="";
		var rmTrailerResponse = JSON.parse($window.sessionStorage.getItem("accounts"));
		self.randomConfirmationNo = "00001"+$filter('date')(today, "yyyyMMddHHmmss")+ Math.floor(1000 + Math.random() * 9000);
		
			var rmNumber= $window.sessionStorage.getItem("rmNumber");	
			//var rmNumber = "00000010210007";
			var allPanelCards={};
			allPanelCards.userCards=[];
			
			var savingsObj={};//Tested Working just Replace savingsObj.totalCards with savingAccount
			var investmentObj={};//Tested Working just Replace savingsObj.totalCards with investmentAccount and so on
			var prepaidCardAccount={};
			var	consumerLoanAccount={};
			var	timeDepositAccount={};
			var	investmentAccount={};
	
		self.removeAccountSavings=JSON.parse($window.sessionStorage.getItem("removeAccountSavings"));		
		self.removeCreditCard=JSON.parse($window.sessionStorage.getItem("removeCreditCard"));
		//alert(JSON.stringify(self.removeCreditCard));
		self.removePrepaidCard=JSON.parse($window.sessionStorage.getItem("removePrepaidCard"));
		self.removeLoans=JSON.parse($window.sessionStorage.getItem("removeLoans"));
		self.removeTimeDeposit=JSON.parse($window.sessionStorage.getItem("removeTimeDeposit"));
		self.removeInvestment=JSON.parse($window.sessionStorage.getItem("removeInvestment"));		
		
		
		//Adding SavingsCheckings cards
		//savingsObj.cardType="Savings";
		savingsObj.totalCards=self.removeAccountSavings;
		allPanelCards.userCards.push(savingsObj);
		//Adding Investment cards and so on
		//investmentObj.cardType="Investment";
		investmentObj.totalCards=self.removeCreditCard;
		allPanelCards.userCards.push(investmentObj);
		prepaidCardAccount.totalCards=self.removePrepaidCard;
		allPanelCards.userCards.push(prepaidCardAccount);
		consumerLoanAccount.totalCards=self.removeLoans;
		allPanelCards.userCards.push(consumerLoanAccount);
		timeDepositAccount.totalCards=self.removeTimeDeposit;
		allPanelCards.userCards.push(timeDepositAccount);
		investmentAccount.totalCards=self.removeInvestment;		
		allPanelCards.userCards.push(investmentAccount);
	
		self.userCards = allPanelCards.userCards;
	    //Footer Panel Expand and collapse
        self.expanded = false;
        self.closed = true;
        self.ExpandPageInfo = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        };
		
		//hide main panel if it is empty
        //self.userCards = testData.userCards;
        if (self.userCards && self.userCards.length == 0) {
           // angular.element(".remove-account-panel").css("display", "none");

        } else if (self.userCards && self.userCards.length > 0) {
            angular.element(".remove-account-panel").css("display", "block");
        } else {
          //  angular.element(".remove-account-panel").css("display", "none");

        }

        //Dropdown icons show and hide
        self.Expand = function(elem, i,panel) {
            if (elem === 'glyphicon-menu-down') {
                angular.element(".arrowDown" + i).hide();
                angular.element(".arrowUp" + i).show();
                angular.element(".editName" + i).show();
				angular.element("."+panel).removeClass("panel-border-grey");
				angular.element("."+panel).addClass("panel-border-red");
            } else {
                angular.element(".arrowUp" + i).hide();
                angular.element(".arrowDown" + i).show();
                angular.element(".editName" + i).hide();
				angular.element("."+panel).removeClass("panel-border-red");
				angular.element("."+panel).addClass("panel-border-grey");
            }
        }

        //No of selected cards count		
        self.AccountSelectedCount = function() {
            var count = angular.element(".widget-remove-account .remove-account-panel [type='checkbox']:checked").length;
            if (count > 0){
				self.errorRemovingUserCards = false;
                return count;
				}else{
				self.errorRemovingUserCards = true;
            return "";
			}
        }
		
		//checking if account no is in rm trailer
		self.checkAccountInRm=function(accNumber) {
		
			angular.forEach(rmTrailerResponse, function(rmt) {
				if (rmt.rmAcctNumber!=undefined){
					if ((rmt.rmAcctNumber.trim()).replace(/\b0+/g, '') == (accNumber.trim()).replace(/\b0+/g, '')) {	
						//ctrl4= rmt.rmAcctControl4;
						self.rmt=rmt;
					}
				}	
			});
		}
		
        //Account removal function and opening confirmation Modal 
        self.AccountSelected = function() {
            selectedAccountInfo = [];
			var preferredName=[];
            angular.forEach(self.userCards, function(data) {
				
                angular.forEach(data.totalCards, function(selectedData) {
                    if (selectedData.checked) {
						self.checkAccountInRm(selectedData.accountNumber);
						
						if(self.rmt!=undefined){
								var selectedAcc={};
								selectedAcc.accountNumber = self.rmt.rmAcctNumber.trim();
								selectedAcc.accountType = self.rmt.rmAcctApplicationId;
								selectedAcc.institutionCode = self.rmt.rmAcctControl1;
								selectedAcc.currencyCode = self.rmt.rmAcctControl2;
								selectedAcc.branchCode = self.rmt.rmAcctControl3;
								selectedAcc.control4 = self.rmt.rmAcctControl4;
								preferredName.push(selectedData.preferredName);
								selectedAccountInfo.push(selectedAcc);
						}
				}

                });
            });
			
            if (selectedAccountInfo!=undefined && selectedAccountInfo.length > 0) {
               // alert(JSON.stringify(selectedAccountInfo));
			
				params.rmNumber = rmNumber;
                params.confirmationNumber = self.randomConfirmationNo;
                params.RemoveAccount = selectedAccountInfo;
					
                self.errorRemovingUserCards = false;
				RemoveAccountService.preferredNames=preferredName;
                RemoveAccountService.SetSelectedAccountInfo(params);
                RemoveAccountService.OpenModal("confirmRemoveAccountModal.html");
            } else {
               
                self.errorMsg = "No Accounts Selected";
                self.errorRemovingUserCards = true;
				//RemoveAccountService.OpenModal("accountRemovedModal.html");
            }

        };
		


    };
});