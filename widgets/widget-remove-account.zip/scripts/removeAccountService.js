/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : RemoveAccountService.js
 *  Description: RemoveAccountService
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
        "use strict";

    // @ngInject
        exports.RemoveAccountService = function($http,$modal,$window,lpWidget) {
		var self=this;
		//Api urls
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var REMOVE_ACCOUNT_DETAILS = protocolHost+lpWidget.getResolvedPreference('removeAccount');
		var EMAIL_NOTIFICATION = protocolHost+lpWidget.getResolvedPreference('emailNotification');
		self.SetSelectedAccountInfo=function(selectedAccountInfo){
		
		self.selectedAccountInfo=selectedAccountInfo;
		
        }
		self.GetSelectedAccountInfo=function(){
		return self.selectedAccountInfo;
		}
		
		self.OpenModal = function(CurrentModal) {
            var modalInstance=$modal.open({
            templateUrl:CurrentModal,
            controller: 'ModalInstanceController as mic',
            windowClass: 'ModalContainer',
            backdrop: 'static'
            }); 
        };
		 /*self.GetSavingAndCheckings = function(req) {
                return $http({
                  url: SAVINGS_AND_CHECKING_BALANCE,
                    method: "POST",
                    data: req,
                    // Static API for Offshore testing
                    // url: "https://api.myjson.com/bins/vnrhn",
                     // method: "GET",
                });
            }*/
     self.removeUserCards = function(req) {
        return $http({
               url:REMOVE_ACCOUNT_DETAILS,
                method: "POST",
                data: req,
				headers: {'URL':'REMOVE_ACCOUNT','KEY':'SPRINT1B','VALUE':'YES'}				
               // Static API for Offshore testing
               /*   url: "https://api.myjson.com/bins/1fby3r",
                 method: "GET",*/
        });
	};
		 self.sendEmailNotification = function(req) {
				return $http({
					url: EMAIL_NOTIFICATION,
					method: "POST",
					data: req,
					headers: {'URL':'FINANCIAL_EMAIL_NOTIF'}
					
				})
			}


        };
		
});