
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.MainCtrl = function() {
        var self = this;
		self.expanded=false;
		self.closed=true;		
		self.expand=function(){
			self.expanded = !self.expanded;
			self.closed = !self.closed;
		};
		self.listItems = {
			"listData" : "You will receive an Activation Code via SMS. It will expire in 5 days. ",
			"listData" : "Download the BPI App to link your device using the activation code, so that you can generate your OTP conveniently through your app. Upon Log In, go to Security Settings > One-Time PIN > Enter Activation Code > Link This Device.",
			"listData" : "If you do not link your device, you still have the option to request for a One-Time PIN via SMS, which is available in the OTP transaction screen."
		};
	};
});