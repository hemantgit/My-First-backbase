/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controllers.js
 *  Description: BPI Header controller
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget, $window, LogoutService,lpCoreBus) {
        var widget = lpWidget;
        var self = this;
        var utils = lpCoreUtils;
		var bus = lpCoreBus;
        var bgResize = function() {
            var headerHeight = angular.element('.post-menu-navbar').height() + 40;
            var windowHeight = angular.element(window).height();
            var manageableAreaHeight = angular.element('.bp-manageableArea');
            angular.element('.simple-page-layout').css("height", windowHeight);
            angular.element('.bp-manageableArea').css("max-height", (windowHeight - headerHeight));
        }
        bgResize();
        angular.element(window).bind('resize', function() {
            bgResize();
        });
        self.userImage = utils.resolvePortalPlaceholders(widget.model.getPreference("userImage")) || "";
        self.logout = utils.resolvePortalPlaceholders(widget.model.getPreference("logout")) || "";
        self.logo = utils.resolvePortalPlaceholders(widget.model.getPreference("logo")) || "";
        self.password = utils.resolvePortalPlaceholders(widget.model.getPreference("password")) || "";
        var logoutModal = document.getElementById('logout-modal');
        self.userId = $window.sessionStorage.getItem("userId");
		//navigation urls
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var addAccountUrl = protocolHost+widget.getResolvedPreference('addaccount');
		var loginUrl = protocolHost+widget.getResolvedPreference('login');
		var logoutUrl = protocolHost+widget.getResolvedPreference('logoutUrl');
		var accountDetailsUrl = protocolHost+widget.getResolvedPreference('goToHome');
		var surveyPageUrl = widget.getResolvedPreference('survey');

        self.openModal = function() {
            logoutModal.style.display = "block";
        }
        self.closeModal = function() {
            logoutModal.style.display = "none";
        } 
		self.addAccount = function() {
            $window.location.href = addAccountUrl;
        }
        window.onclick = function(event) {
            if (event.target == logoutModal) {
                logoutModal.style.display = "none";
            }
        }

		bus.subscribe('headerMenu', function(data){
			if(data.page==="accountDasboard" || data.page==="savingsChecking")
			{
			 self.savingsActive=true;
			}
			if(data.page==="creditCardOverview" || data.page==="creditCardDetails")
			{
			 self.creditCardActive=true;
			}
			if(data.page==="portfolio" || data.page==="portfolioDetails")
			{
			 self.investmentActive=true;
			}
			if(data.page==="loansDetails")
			{
			 self.loansActive=true;
			}
			if(data.page==="timeDeposit")
			{
			 self.timeDepositActive=true;
			}
			if(data.page==="investmentHistory")
			{
			 self.investmentActive=true;
			}
		}); 
        /*
        Logout function
        */
        self.doLogout = function() {
                $window.open(surveyPageUrl, '_blank');
                LogoutService.doLogout().success(function() {
                    $window.sessionStorage.clear();
                    $window.sessionStorage.removeItem("errorMsg");
                    $window.sessionStorage.setItem("errorMsg", widget.model.getPreference("errMsg"));
                    $window.location.href = loginUrl;
                }).error(function(response) {
                    console.log(response);
                });
            },
            /*
                    Logout once session expires
                    */
            self.doLogoutForSessionTimeOut = function() {
                $window.open(surveyPageUrl, '_blank');
                LogoutService.doLogout().success(function() {
                    $window.sessionStorage.clear();
                    $window.sessionStorage.removeItem("errorMsg");
                    $window.location.href = logoutUrl;
                }).error(function(response) {
                    console.log(response);
                });
            },

            /*
                    Navigate to Account dashboard
                    */            
			self.goToHomePage = function(){
			$window.location.href =accountDetailsUrl;
			};
        


        /*----------------------------------------------------------
                Display alert once the session is going to end
                -----------------------------------------------------------*/
        var time = new Date().getTime();
        $(window).bind("mousemove keypress", function() {
            time = new Date().getTime();
        });

        var timeOut1 = null;
        var alertTime = null;
        var timeout = 300000; // session time out time is 5 min
        var gracetime = 240000; //grace time to show popup is 4 min
        function refresh() {

            if (new Date().getTime() - time >= timeout) {
			
                self.doLogoutForSessionTimeOut();
            } else if (new Date().getTime() - time >= gracetime && new Date().getTime() - time < timeout) {
                OpenModal();
                timeOut1 = setTimeout(self.doLogoutForSessionTimeOut, timeout - gracetime);
            } else {
			
                setTimeout(refresh, 10000);
            }
        }

        function OpenModal() {
            angular.element("#myModal").css("display", "block");
            alertTime = new Date();
        }

        function CloseModal() {
            angular.element("#myModal").css("display", "none");


        }
						
		/* START: Disable back button*/

			history.pushState(null, null, document.URL);
			window.addEventListener('popstate', function () 
			{
			   history.pushState(null, null, document.URL);
			});
		/* START: Disable right click*/	
			document.addEventListener("contextmenu", function(e){
			e.preventDefault();
			}, false);
		//Backbase review Update
		self.continueSession=function(){ 
		CloseModal();
            if (new Date().getTime() - time < timeout) {

                clearTimeout(timeOut1);
                window.location.reload();
            } else {
                self.doLogoutForSessionTimeOut();
            }
		}
		//Backbase review Update
		self.closeSession=function(){
		 CloseModal();
            if (new Date().getTime() - time < timeout) {

                var cancelTime = alertTime.getSeconds();
                var oneMinute = 60;
                var expireSec = oneMinute - cancelTime;
                var millSec = 1000;
                var remSec = millSec * expireSec;
                reDirect(remSec);
            } else {
                self.doLogoutForSessionTimeOut();

            }
		}   
        function reDirect(sec) {
            setTimeout(self.doLogoutForSessionTimeOut, sec);
        }


        setTimeout(refresh, 1000);

        /* -------------------------------------------------------
                session timout logic ends here
                ----------------------------------------------------------*/


    };
});