/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : logout-service.js
 *  Description: post navbar - logout-service 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.LogoutService = function($http, lpPortal) {
        var config = {
            logoutUrl: lpPortal.root + "/j_spring_security_logout",
        };
        this.doLogout = function() {
            return $http({
                method: "POST",
                url: config.logoutUrl,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            });
        };
    };
});