/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : dashboardCtrl.js
 *  Description: BPI Account dashboard controller
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";
    exports.MainCtrl = function(AccountDetailsService,$filter, $http, lpCoreUtils, lpWidget, lpPortal, $window,conversionCodes,lpCoreBus) {
        var self = this;
        var utils = lpCoreUtils;
        var widget = lpWidget;
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'accountDasboard'	
        });
        self.ImgThMyAcc = utils.resolvePortalPlaceholders(widget.model.getPreference("ImgThMyAcc")) || "";
        self.reOrder = utils.resolvePortalPlaceholders(widget.model.getPreference("reOrder")) || "";
        self.edit = utils.resolvePortalPlaceholders(widget.model.getPreference("edit")) || "";
        self.hoverEditImage = utils.resolvePortalPlaceholders(widget.model.getPreference("edit_hover")) || "";
        self.showMainContentDiv = true;
        self.showRmDownDiv = false;
		self.institutionCodeJSON = conversionCodes.institutionCode;
        self.currencyCodeJSON = conversionCodes.currencyCode;
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var savingsCheckingUrl = protocolHost+lpWidget.getResolvedPreference('savingsCheckiingNavigation');
		var cardOverviewUrl = protocolHost+widget.getResolvedPreference('cardOverview');
		var prepaidHistoryUrl = protocolHost+widget.getResolvedPreference('prepaidHistory');
		var loansDetailsUrl = protocolHost+widget.getResolvedPreference('loansDetails');
		var timeDepositUrl = protocolHost+widget.getResolvedPreference('timedepositdetails');
		var investmentHistoryUrl = protocolHost+widget.getResolvedPreference('investmentHistory');
		var accountPortfolioUrl = protocolHost+widget.getResolvedPreference('investmentPortfolio');
		var payBillsUrl = protocolHost+widget.getResolvedPreference('paybills');
		var fundTransferUrl = protocolHost+widget.getResolvedPreference('fundstransfer');
        var rmNumber = $window.sessionStorage.getItem("rmNumber");	
		
        // Static RMNumber for Offshore testing
		//$window.sessionStorage.setItem("rmNumber","00000014454186");

        var savingAccount = [];
        var creditCardAccount = [];
        var prepaidCardAccount = [];
        var consumerLoanAccount = [];
        var timeDepositAccount = [];
        var investmentAccount = [];
        var taggedAccount = [];

        var savingsAndCheckingObject = {};
        var creditCardObject = {};
        var prepaidCardObject = {};
        var consumerLoanObject = {};
        var timeDepositObject = {};
        var investmentObject = {};

        var rmTrailerRequest = {};
        rmTrailerRequest.rmNumber = rmNumber;
        self.savingCheckingerror = null;
        self.creditCardserror = null;
        self.serverErrorMsg = null;
        self.savingAcc;
		
		var investmentPalyloadUI="";
		var investmentPalyloadMF="";
		
		/* sprint-2 Code Start */
        var payBillAccounts = [];
        var fundTransFromAccounts = [];
        var fundTransToAccounts = [];
        var payBillsSavingsAndCheckingReq = {};
        var TrnsFromSavingsAndCheckingReq = {};
        var TrnsToSavingsAndCheckingReq = {};
        /* Sprint-2 Code End */
		
        //Add Spinner
        angular.element(".accountsloader").removeClass("hidden");
        angular.element(".loader.snc").removeClass("hidden");
        angular.element(".loader.cc").removeClass("hidden");
        /*
         *      If RMNumber is generated call RMTrailer
         */
		function getLatestMobileNumber(){
			AccountDetailsService.getMobileNumber(rmNumber);		 
		};
        if (rmNumber) {
		/* sprint-2 Code Start */
			getLatestMobileNumber();
            self.trasMoneyPayBill = function(v) {
                if (v.rmIbBillsPayFlag === "Y" && v.rmAcctControl2.substring(1) == "01") {
                    var payBillAcc = {};
                    payBillAcc.accountNumber = v.rmAcctNumber.trim();
                    payBillAcc.accountType = v.rmAcctApplicationId;
                    payBillAcc.institutionCode = v.rmAcctControl1;
                    payBillAcc.currencyCode = v.rmAcctControl2;
                    payBillAcc.branchCode = v.rmAcctControl3;
                    payBillAccounts.push(payBillAcc);
                }
                if (v.rmIbXferFromFlag === "Y" && v.rmAcctControl2.substring(1) == "01") {
                    var fundTransFromAcc = {};
                    fundTransFromAcc.accountNumber = v.rmAcctNumber.trim();
                    fundTransFromAcc.accountType = v.rmAcctApplicationId;
                    fundTransFromAcc.institutionCode = v.rmAcctControl1;
                    fundTransFromAcc.currencyCode = v.rmAcctControl2;
                    fundTransFromAcc.branchCode = v.rmAcctControl3;
                    fundTransFromAccounts.push(fundTransFromAcc);
                }
                if (v.rmIbXferToFlag === "Y" && v.rmAcctControl2.substring(1) == "01") {
                    var fundTransToAcc = {};
                    fundTransToAcc.accountNumber = v.rmAcctNumber.trim();
                    fundTransToAcc.accountType = v.rmAcctApplicationId;
                    fundTransToAcc.institutionCode = v.rmAcctControl1;
                    fundTransToAcc.currencyCode = v.rmAcctControl2;
                    fundTransToAcc.branchCode = v.rmAcctControl3;
                    fundTransToAccounts.push(fundTransToAcc);
                }
            };
			/* Sprint-2 Code End */
            AccountDetailsService.getRMTrailer(rmTrailerRequest).then(function(response) {
                    var accounts = response.data.RMTrailers;
                    $window.sessionStorage.setItem("accounts",JSON.stringify(accounts));
					function checkInvestments(v){
						if(v.rmAcctApplicationId === "UI"){
									investmentPalyloadUI="Y";
								}else if(v.rmAcctApplicationId === "MF"){
									investmentPalyloadMF="Y"
								}
					}
					function savingsAndCheckingPayload(v){
						if (v.rmIbAcctFlag === "Y") {   
							var savingsPayload = {};
							savingsPayload.accountNumber = v.rmAcctNumber.trim();
							savingsPayload.accountType = v.rmAcctApplicationId;
							savingsPayload.institutionCode = v.rmAcctControl1;
							savingsPayload.currencyCode = v.rmAcctControl2;
							savingsPayload.branchCode = v.rmAcctControl3;
							savingAccount.push(savingsPayload);
							self.trasMoneyPayBill(v);
						}
					}
					function timeDepositPayload(v){
						if (v.rmIbAcctFlag === "Y") {  
							var timeDepositPayload = {};						
							timeDepositPayload.accountNumber = v.rmAcctNumber.trim();
							timeDepositPayload.accountType = "ST";
							timeDepositPayload.institutionCode = v.rmAcctControl1;
							timeDepositPayload.currencyCode = v.rmAcctControl2;
							timeDepositPayload.branchCode = v.rmAcctControl3;
							timeDepositAccount.push(timeDepositPayload);						
						}
					}		
                    angular.forEach(accounts, function(v) {
						//checking for account type
                        if (v.rmAcctApplicationId === "ST" || v.rmAcctApplicationId === "IM") {
                            savingsAndCheckingPayload(v)
                        } else if (v.rmAcctApplicationId === "CC") {							 	
								var creditCardPayload = {};
								creditCardPayload.control1 = v.rmAcctControl1;
								creditCardPayload.control2 = v.rmAcctControl2;
								creditCardPayload.control3 = v.rmAcctControl3;
								creditCardPayload.control4 = v.rmAcctControl4;
								creditCardPayload.accountNumber = v.rmAcctNumber.trim();
								creditCardAccount.push(creditCardPayload);							
                        } else if (v.rmAcctApplicationId === "PC") {
								var prepaidCardPayload = {};
								prepaidCardPayload.control1 = v.rmAcctControl1;
								prepaidCardPayload.control2 = v.rmAcctControl2;
								prepaidCardPayload.control3 = v.rmAcctControl3;
								prepaidCardPayload.control4 = v.rmAcctControl4;
								prepaidCardPayload.accountType = v.rmAcctApplicationId;
								prepaidCardPayload.accountNumber = v.rmAcctNumber.trim();
								prepaidCardAccount.push(prepaidCardPayload);
                        } else if (v.rmAcctApplicationId === "AC") {
								var loanPayload = {};
								//loanPayload.rmNumber = rmNumber;
								loanPayload.loanAccountNumber = v.rmAcctNumber.trim();
								loanPayload.accountControl1 = v.rmAcctControl1;
								loanPayload.accountControl2 = v.rmAcctControl2;
								loanPayload.accountControl3 = v.rmAcctControl3;
								loanPayload.accountControl4 = v.rmAcctControl4;
								consumerLoanAccount.push(loanPayload);
                        } else if (v.rmAcctApplicationId === "TD") { 
							timeDepositPayload(v);
						} else if (v.rmAcctApplicationId === "UI" || v.rmAcctApplicationId === "MF") {
							if (v.rmIbAcctFlag === "Y") {  
								var investmentPayload = {};
								taggedAccount.push(v.rmAcctNumber.trim());
								checkInvestments(v);
							}	
                        }						
                    });
					 
                    payBillsSavingsAndCheckingReq.rmNumber = rmNumber;
                    payBillsSavingsAndCheckingReq.SavingsChecking = payBillAccounts;
                    $window.sessionStorage.removeItem("paybillsMyAccounts");
                    $window.sessionStorage.setItem("paybillsMyAccounts", angular.toJson(payBillsSavingsAndCheckingReq));
                    TrnsFromSavingsAndCheckingReq.rmNumber = rmNumber;
                    TrnsFromSavingsAndCheckingReq.SavingsChecking = fundTransFromAccounts;
                    $window.sessionStorage.removeItem("transferFromAccounts");
                    $window.sessionStorage.setItem("transferFromAccounts", angular.toJson(TrnsFromSavingsAndCheckingReq));
                    TrnsToSavingsAndCheckingReq.rmNumber = rmNumber;
                    TrnsToSavingsAndCheckingReq.SavingsChecking = fundTransToAccounts;
                    $window.sessionStorage.removeItem("transferToAccounts");
                    $window.sessionStorage.setItem("transferToAccounts", angular.toJson(TrnsToSavingsAndCheckingReq));
                    savingsAndCheckingObject.rmNumber = rmNumber;
                    savingsAndCheckingObject.SavingsChecking = savingAccount;
                    if (savingAccount.length != 0) {
                        /*
                         *      Saving and checking API call
                         */
                        AccountDetailsService.getSavingAndCheckings(savingsAndCheckingObject).then(function(response) {
                                //Remove Spinner
                                angular.element(".accountsloader").addClass("hidden");
                                //angular.element(".loader.snc").addClass("hidden");

                                self.savingChecking = response.data.SavingsChecking;
								$window.sessionStorage.removeItem("removeAccountSavings");
								$window.sessionStorage.setItem("removeAccountSavings", JSON.stringify(self.savingChecking));
                                if (self.savingChecking && self.savingChecking.length == 0) {
                                    self.savingCheckingerror = widget.model.getPreference("noRecordsFound");
                                    self.savingCheckinglength = 0;

                                } else {
                                    self.savingCheckinglength = self.savingChecking.length;
                                    angular.element(".saving-checking-panel").css("display", "block");
                                }
                            },
                            function(response) {
                                self.savingCheckinglength = 0;
                                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                                    angular.element(".accountsloader").addClass("hidden");
                                    self.savingCheckingerror = widget.model.getPreference("serverError");

                                }
                            });
                    } else {
					//removing loader
                        angular.element(".accountsloader").addClass("hidden");
                        angular.element(".loader.snc").addClass("hidden");
                        self.savingCheckingerror = widget.model.getPreference("noRecordsFound");
                        self.savingCheckinglength = 0;
                        angular.element(".saving-checking-panel").css("display", "none");
                    }
                    creditCardObject.CreditCardAccountRequest = creditCardAccount;
                    if (creditCardAccount.length != 0) {
                        /*
                         *      creditcard balance  API call
                         */
                        AccountDetailsService.getCreditCardBB(creditCardObject).then(function(response) {
                                //Remove Spinner
                                angular.element(".accountsloader").addClass("hidden");
                                self.creditCards=[];
                                //self.creditCards = response.data.CreditCards;
								angular.forEach(response.data.CreditCards, function(creditCard) {
									creditCard.accountNumber=creditCard.customerNumber;
									self.creditCards.push(creditCard);
								})
								
								
								$window.sessionStorage.removeItem("removeCreditCard");
								 $window.sessionStorage.setItem("removeCreditCard", JSON.stringify(self.creditCards));
                                if (self.creditCards && self.creditCards.length == 0) {
                                    self.creditCardserror = widget.model.getPreference("noRecordsFound");
                                    self.creditCardslength = 0;
                                } else if (self.creditCards && self.creditCards.length > 0) {
                                    $window.sessionStorage.removeItem("cards");
                                    $window.sessionStorage.setItem("cards", self.creditCards);
                                    self.creditCardslength = self.creditCards.length;
                                    angular.element(".credit-card-panel").css("display", "block");
                                } else {
                                    angular.element(".credit-card-panel").css("display", "none");
                                }

                                var pattern;
                                self.creditCards.forEach(function(obj) {
                                    //Replace date from APT with date string
                                    if (obj.statementDate != undefined && obj.statementDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        obj.statementDate = new Date(obj.statementDate.replace(pattern, "$1/$2/$3"));
                                        obj.statementDate = obj.statementDate.toString("mmm,dd,yyyy");
                                    }
                                    if (obj.paymentDueDate != undefined && obj.paymentDueDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        obj.paymentDueDate = new Date(obj.paymentDueDate.replace(pattern, "$1/$2/$3"));
                                        obj.paymentDueDate = obj.paymentDueDate.toString("mmm,dd,yyyy");
                                    }
                                    if (obj.dateOfLastPayment != undefined && obj.dateOfLastPayment.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        obj.dateOfLastPayment = new Date(obj.dateOfLastPayment.replace(pattern, "$1/$2/$3"));
                                        obj.dateOfLastPayment = obj.dateOfLastPayment.toString("mmm,dd,yyyy");
                                    }
                                });

                            },
                            function(response) {
                                self.creditCardslength = 0;
                                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                                    angular.element(".accountsloader").addClass("hidden");
                                    self.creditCardserror = widget.model.getPreference("serverError");

                                }
                            });
                    } else {
                        angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                        angular.element(".loader.cc").addClass("hidden");
                        self.creditCardserror = widget.model.getPreference("noRecordsFound");
                        self.creditCardslength = 0;
                    }


                    /*	Prepaid card	*/

                    prepaidCardObject.CreditCardAccountRequest = prepaidCardAccount;
                    if (prepaidCardAccount.length != 0) {
                        AccountDetailsService.getPrepaidCardBB(prepaidCardObject).then(function(response) {

                                angular.element(".accountsloader").addClass("hidden"); //Remove Spinner

                                //self.prepaidCards = response.data.CreditCards;
								self.prepaidCards=[];
								angular.forEach(response.data.CreditCards, function(creditCard) {
									angular.forEach(creditCard.Cards, function(card) {
										self.prepaidCards.push(card);
									})
								})
								
								$window.sessionStorage.removeItem("removePrepaidCard");
								$window.sessionStorage.setItem("removePrepaidCard", JSON.stringify(self.prepaidCards));
                                if (self.prepaidCards && self.prepaidCards.length == 0) {
                                    angular.element(".prepaid-card-panel").css("display", "none");
                                    self.prepaidCardslength = 0;
                                } else if (self.prepaidCards && self.prepaidCards.length > 0) {
                                    angular.element(".prepaid-card-panel").css("display", "block");
                                } else {
                                    angular.element(".prepaid-card-panel").css("display", "none");
                                    self.prepaidCardslength = 0;
                                }

                            },
                            function(response) {
                                self.prepaidCardslength = 0;
                                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                                    angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                                    //self.creditCardserror = widget.model.getPreference("serverError");

                                }
                            });
                    } else {
                        angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                        self.prepaidCardserror = widget.model.getPreference("noRecordsFound");
                        self.prepaidCardslength = 0;
                    }

                    /* Loans */
					consumerLoanObject.rmNumber = rmNumber;
					consumerLoanObject.LoansRequest = consumerLoanAccount;
                    if (consumerLoanAccount.length != 0) {
                        AccountDetailsService.getLoans(consumerLoanObject).then(function(response) {

                                angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
								self.loans=[];
							
                                //var loansDetails = response.data.Loans;
								angular.forEach(response.data.Loans, function(loans) {
									angular.forEach(loans.loanAccounts, function(loan) {
										loan.accountNumber=loan.loanAccountNumber;
										self.loans.push(loan);
									})
								})
								$window.sessionStorage.removeItem("removeLoans");
								$window.sessionStorage.setItem("removeLoans", JSON.stringify(self.loans));
                                if (self.loans && self.loans.length == 0) {
                                    angular.element(".loan-panel").css("display", "none");
                                    self.loansAccountlength = 0;
                                } else if (self.loans && self.loans.length > 0) {
                                    angular.element(".loan-panel").css("display", "block");
                                } else {
                                    angular.element(".loan-panel").css("display", "none");
                                    self.loansAccountlength = 0;
                                }
								   var pattern;
                                self.loans.forEach(function(obj) {
                                    //Replace date from APT with date string
                                    if (obj.nextDueDate != undefined && obj.nextDueDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        obj.nextDueDate = new Date(obj.nextDueDate.replace(pattern, "$1/$2/$3"));
                                        obj.nextDueDate = obj.nextDueDate.toString("mmm,dd,yyyy");
                                    }
									if (obj.lastPaymentDate != undefined && obj.lastPaymentDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        obj.lastPaymentDate = new Date(obj.lastPaymentDate.replace(pattern, "$1/$2/$3"));
                                        obj.lastPaymentDate = obj.lastPaymentDate.toString("mmm,dd,yyyy");
                                    }
                                    
                                });

                            },
                            function(response) {
                                self.loansAccountlength = 0;
                                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                                    angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                                    //self.creditCardserror = widget.model.getPreference("serverError");

                                }
                            });
                    } else {
                        angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                        self.loanAccounterror = widget.model.getPreference("noRecordsFound");
                        self.loansAccountlength = 0;
                    }
                    /*	Time Deposit	*/
                    timeDepositObject.rmNumber = rmNumber;
                    timeDepositObject.TimeDeposit = timeDepositAccount;
                    if (timeDepositAccount.length != 0) {
                        AccountDetailsService.getTimeDeposit(timeDepositObject).then(function(response) {

                                angular.element(".accountsloader").addClass("hidden"); //Remove Spinner

                                self.timeDeposit = response.data.TimeDeposit;
								$window.sessionStorage.removeItem("removeTimeDeposit");
								$window.sessionStorage.setItem("removeTimeDeposit", JSON.stringify(self.timeDeposit));
                                if (self.timeDeposit && self.timeDeposit.length == 0) {
                                    angular.element(".time-deposit-panel").css("display", "none");
                                    self.timeDepositAccountslength = 0;
                                } else if (self.timeDeposit && self.timeDeposit.length > 0) {
                                    angular.element(".time-deposit-panel").css("display", "block");
                                } else {
                                    angular.element(".time-deposit-panel").css("display", "none");
                                    self.timeDepositAccountslength = 0;
                                }
								   var pattern;
                                self.timeDeposit.forEach(function(obj) {
                                    //Replace date from APT with date string
                                    if (obj.maturityDate != undefined && obj.maturityDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        obj.maturityDate = new Date(obj.maturityDate.replace(pattern, "$1/$2/$3"));
                                        obj.maturityDate = obj.maturityDate.toString("mmm,dd,yyyy");
                                    }
                                    
                                });

                            },
                            function(response) {
                                self.timeDepositAccountslength = 0;
                                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                                    angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                                    //self.creditCardserror = widget.model.getPreference("serverError");

                                }
                            });
                    } else {
                        angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                        self.timeDepositerror = widget.model.getPreference("noRecordsFound");
                        self.timeDepositAccountslength = 0;
                    }
                    /*	Investments Deposit	*/
					function investmentPalyloadRequest(){
						if(investmentPalyloadUI !=="" && investmentPalyloadUI==="Y"){
							var investmentUIPayload={};
							investmentUIPayload.customerNumber = rmNumber;
							investmentUIPayload.accountSubType = "UI";
							investmentAccount.push(investmentUIPayload);
						}
						if(investmentPalyloadMF !=="" && investmentPalyloadMF==="Y"){
							var investmentMFPayload={};
							investmentMFPayload.customerNumber = rmNumber;
							investmentMFPayload.accountSubType = "MF";
							investmentAccount.push(investmentMFPayload);
						}
					}	
					investmentPalyloadRequest();
                    investmentObject.TaggedAccounts = taggedAccount;
                    investmentObject.InvestmentsRequest = investmentAccount;
					
								if (investmentAccount.length != 0) {
                        AccountDetailsService.getInvestment(investmentObject).then(function(response) {

                                angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
								self.investments=[];
                                self.investmentsDetails = response.data.Investments;
								angular.forEach(self.investmentsDetails, function(investment) {
									angular.forEach(investment.investmentAccounts, function(invesmtentAccounts) {
										invesmtentAccounts.customerNumber=investment.customerNumber;
										self.investments.push(invesmtentAccounts)
									})
								
								})
								
								$window.sessionStorage.removeItem("removeInvestment");
								$window.sessionStorage.setItem("removeInvestment", JSON.stringify(self.investments));
                                if (self.investments && self.investments.length == 0) {
                                    angular.element(".investments-panel").css("display", "none");
                                    self.investmentAccountountslength = 0;
                                } else if (self.investments && self.investments.length > 0) {
                                    angular.element(".investments-panel").css("display", "block");
                                } else {
                                    angular.element(".investments-panel").css("display", "none");
                                    self.investmentAccountountslength = 0;
                                }

                            },
                            function(response) {
                                self.investmentAccountountslength = 0;
                                if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                                    angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                                    //self.creditCardserror = widget.model.getPreference("serverError");

                                }
                            });
                    } else {
                        angular.element(".accountsloader").addClass("hidden"); //Remove Spinner
                        self.investmentserror = widget.model.getPreference("noRecordsFound");
                        self.investmentAccountountslength = 0;
                    }

                },
                function(response) {
                    if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 503) {
                        //Remove Spinner
						self.showRmDownDiv = true;
                        angular.element(".accountsloader").addClass("hidden");
                        self.serverErrorMsg = widget.model.getPreference("serverErrMsg");
                        self.savingCheckingerror = widget.model.getPreference("serverErrMsg");
                        self.creditCardserror = widget.model.getPreference("serverErrMsg");
                        self.creditCardslength = 0;
                        self.savingCheckinglength = 0;

                    }

                });
        } else {
            //Remove Spinner
            angular.element(".accountsloader").addClass("hidden");
            self.serverErrorMsg = widget.model.getPreference("serverErrMsg");
            self.serverErrorMsg = widget.model.getPreference("serverErrMsg");
            self.showMainContentDiv = false;
            self.showRmDownDiv = true;
            self.savingCheckingerror = widget.model.getPreference("serverErrMsg");
            self.creditCardserror = widget.model.getPreference("serverErrMsg");
            self.creditCardslength = 0;
            self.savingCheckinglength = 0;
        }
        /*
         *      Currency code to currency value conversion
         */
        self.getCurrency = function(value) {
            var currencyCode;
            if (value) {
                currencyCode = value.substr(1, 2);
            }
            return currencyCode;
        };
         /*
         *      Account type
         */
        self.getAccountType = function(accounttype) {
            if (accounttype === "ST")
                return "Savings Account";
            else if (accounttype === "IM")
                return "Checking Account";
        };


        /*
         *      Navigate to savings and checking transaction page
         */
        self.savingsTransactionView = function(snc, bank) {

            $window.sessionStorage.removeItem("sncTransacitonRequest");
            var accNumber = snc.accountNumber.trim();
            var sncTransacitonRequest = {
                "accountNumber": accNumber,
                "fiCode": snc.institutionCode,
                "branchCode": snc.branchCode,
                "currency": snc.currencyCode,
                "accountType": snc.accountType,
                "rmNumber": rmNumber
            };
            $window.sessionStorage.setItem("sncTransacitonRequest", JSON.stringify(sncTransacitonRequest));
            $window.sessionStorage.removeItem("sncPrefferedName");
            $window.sessionStorage.setItem("sncPrefferedName", snc.preferredName);
            $window.sessionStorage.removeItem("saving_checking_availableBalance");
            $window.sessionStorage.setItem("saving_checking_availableBalance", snc.availableBalance);
            $window.sessionStorage.removeItem("saving_checking_totalBalance");
            $window.sessionStorage.setItem("saving_checking_totalBalance", snc.totalBalance);
            $window.sessionStorage.removeItem("bank");
            $window.sessionStorage.setItem("bank", bank);
            $window.location.href = savingsCheckingUrl;
        };
        /*
         *      Navigate to card overview screen
         */
        self.creditCardTransactionView = function(accountNumber) {
            $window.sessionStorage.removeItem("ccTransacitonRequest");
            var creditcardDetails = self.creditCards;
            for (var i in creditcardDetails) {
                if (creditcardDetails[i].accountNumber == accountNumber) {
                    $window.sessionStorage.setItem("ccTransacitonRequest", JSON.stringify(creditcardDetails[i]));
                    break;
                }
            }

            $window.location.href = cardOverviewUrl;
        };
        /*
         *      Navigate to Prepaid card Transaction history screen
         */

        self.prepaidTransactionView = function(totalPrepaid,prepaidAccountNumber,prepaidPreferredName,prepaidAvailableBalance) {
			var prepaidCardNumber=totalPrepaid.cardNumber;
			var prepaidOrg=totalPrepaid.accountOrg;
			var prepaidType=totalPrepaid.accountType;
			var prepaidAccountNumber=totalPrepaid.accountNumber.trim();			
			var CardTransDetailsReq = {};
                CardTransDetailsReq.accountNumber = prepaidAccountNumber;
                CardTransDetailsReq.org = prepaidOrg;
                CardTransDetailsReq.type = prepaidType;
                CardTransDetailsReq.cardNumber = prepaidCardNumber;
            $window.sessionStorage.removeItem("prepaidAccountNumber");
			$window.sessionStorage.setItem("prepaidAccountNumber", prepaidAccountNumber);
			$window.sessionStorage.removeItem("prepaidPreferredName");
			$window.sessionStorage.setItem("prepaidPreferredName", prepaidPreferredName);
			$window.sessionStorage.removeItem("prepaidAvailableBalance");
			$window.sessionStorage.setItem("prepaidAvailableBalance", prepaidAvailableBalance);
			$window.sessionStorage.removeItem("prepaidTransacitonRequest");
			$window.sessionStorage.removeItem("prepaidHistoryRequest");
			$window.sessionStorage.setItem("prepaidHistoryRequest", JSON.stringify(CardTransDetailsReq));
            var prepaidCardDetails = self.prepaidCards;
            for (var i in prepaidCardDetails) {
                if (prepaidCardDetails[i].accountNumber === prepaidAccountNumber) {
                    $window.sessionStorage.setItem("prepaidTransacitonRequest", JSON.stringify(prepaidCardDetails[i]));
                    break;
                }
            }			
            $window.location.href = prepaidHistoryUrl;
        };
        /*
         *      Navigate to Loans Transaction history screen
         */
        self.loansTransactionView = function(loansRequest,loansPreferredName,loansAccountNumber) {
            $window.sessionStorage.removeItem("loansTransacitonRequest");
			$window.sessionStorage.setItem("loansTransacitonRequest", JSON.stringify(loansRequest));
			$window.sessionStorage.removeItem("loansPreferredName");			
			$window.sessionStorage.setItem("loansPreferredName", loansRequest.preferredName);  
			$window.sessionStorage.removeItem("loansAccountNumber");			
			$window.sessionStorage.setItem("loansAccountNumber", loansAccountNumber);  
            $window.location.href = loansDetailsUrl;
        };
        /*
         *      Navigate to Time Deposit Transaction history screen
         */
        self.depositDetailsView = function(timeDepositDetails) {
            $window.sessionStorage.removeItem("depositTransacitonRequest");
			$window.sessionStorage.setItem("depositTransacitonRequest", JSON.stringify(timeDepositDetails)); 
            $window.location.href = timeDepositUrl;
        };
        /*
         *      Navigate to Investments Transaction history screen
         */
        self.investmentsAccountDetails = function(investmentData,investmentAccountNumber) {
			var portfolioAccountNo=investmentAccountNumber.trim();
            $window.sessionStorage.removeItem("portfolioPayloadRequest");                                
			var portfolioRequest = {};
			var portfolioDetailsRequest = {};
			var portfolioAccount = [];
			// Service call request
			portfolioRequest.accountNumber = portfolioAccountNo;
			portfolioRequest.portfolioDate = investmentData.portfolioDate;
			portfolioRequest.accountType = investmentData.accountType;
			portfolioRequest.investmentType = "";
			portfolioRequest.productType = "";
			portfolioRequest.customerNumber = "4907092399882240";
			portfolioAccount.push(portfolioRequest);
			portfolioDetailsRequest.InvestmentsRequest = portfolioAccount;
			$window.sessionStorage.setItem("portfolioPayloadRequest", JSON.stringify(investmentData));     
			$window.sessionStorage.removeItem("portfolioPayloadAccount");			
			$window.sessionStorage.setItem("portfolioPayloadAccount", investmentAccountNumber);  
			   
			$window.location.href= accountPortfolioUrl;		
        };

        /*
         *      Navigate to Investments Transaction history screen
         */
        self.investmentsTransactionHistoryDetails = function(accountNumberDetails,portfolioPreferredName,dateOpened,accountType,customerNumber,accountName) {
			var investmentsTransactionHistoryPayload={};
			investmentsTransactionHistoryPayload.customerNumber= customerNumber;			
			investmentsTransactionHistoryPayload.accountNumber= accountNumberDetails;
			investmentsTransactionHistoryPayload.accountType= accountType;
			investmentsTransactionHistoryPayload.fiCode= "";
			investmentsTransactionHistoryPayload.startDate= "";
			investmentsTransactionHistoryPayload.endDate= "";
			$window.sessionStorage.removeItem("investmentsTransactionHistoryPayload");
			$window.sessionStorage.setItem("investmentsTransactionHistoryPayload", JSON.stringify(investmentsTransactionHistoryPayload)); 
			
			$window.sessionStorage.removeItem("accountNumberDetails");			
			$window.sessionStorage.setItem("accountNumberDetails", accountNumberDetails);   
			$window.sessionStorage.removeItem("portfolioPreferredName");			
			$window.sessionStorage.setItem("portfolioPreferredName", portfolioPreferredName);   
			$window.sessionStorage.removeItem("dateOpened");			
			$window.sessionStorage.setItem("dateOpened", dateOpened);
			$window.sessionStorage.removeItem("accountType");			
			$window.sessionStorage.setItem("accountType", accountType);
			$window.sessionStorage.removeItem("historyAccountName");			
			$window.sessionStorage.setItem("historyAccountName", accountName);
			
            $window.location.href = investmentHistoryUrl;
        };
        //Expand and collapse account dashboard
        self.expandPanel = function(value, i,panel) {
            if (value === 'glyphicon-menu-down') {
                angular.element(".arrowDown" + i).hide();
                angular.element(".arrowUp" + i).show();
                angular.element(".editName" + i).show();
				angular.element(".account-head ."+panel+".panel-default").css("border-left","10px solid #c0010c");
            } else {
                angular.element(".arrowUp" + i).hide();
                angular.element(".arrowDown" + i).show();
                angular.element(".editName" + i).hide();
				angular.element(".account-head ."+panel+".panel-default").css("border-left","10px solid #7f7f7f");
            }
        }

        self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 16))
                    return dateString.slice(4, 16);
                else
                    return "";
            }
        };
        /*
         *      Add paranthesis for negative values
         */
        self.addBracket = function(value) {
            if (value) {
                var negativeValue = value.toString();
                if (negativeValue.charAt(0) === "-") {
                    var removeMinus = negativeValue.slice(1);
                    var trimNegative = Number(removeMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    var trimedValue = "(" + trimNegative + ")";
                    return trimedValue;
                } else {
                    var trimNonNegative = Number(negativeValue).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    return trimNonNegative;
                }
            }
        };
        /*Added for Edit prefered name hover */
        self.onMouseEnterEdit = function(editValue) {
            angular.element('.' + editValue + ' ').addClass('selected');
            angular.element('.' + editValue + ' .edit').hide();
            angular.element('.' + editValue + ' .edit_hover').show();
        }
        self.onMouseLeaveEdit = function(editValue) {
            angular.element('.' + editValue + ' ').removeClass('selected');
            angular.element('.' + editValue + ' .edit').show();
            angular.element('.' + editValue + ' .edit_hover').hide();
        }
	 /* Sprint-2 Code Start */
        self.doPayBillsView = function(accountNumber, preferredName, currCode, accType, availableBal) {
            var accNumber = accountNumber.trim();
            $window.sessionStorage.removeItem("payBillsAccountNumber");
            $window.sessionStorage.setItem("payBillsAccountNumber", accNumber);
            $window.sessionStorage.removeItem("payBillsAccountType");
            $window.sessionStorage.setItem("payBillsAccountType", accType);
            $window.sessionStorage.removeItem("payBillsPrefferedName");
            $window.sessionStorage.setItem("payBillsPrefferedName", preferredName);
            $window.sessionStorage.removeItem("payBillsCurrencyCode");
            $window.sessionStorage.setItem("payBillsCurrencyCode", currCode);
            $window.sessionStorage.removeItem("payBillsAvailableBalance");
            $window.sessionStorage.setItem("payBillsAvailableBalance", availableBal);
            $window.location.href = payBillsUrl;
        };
        self.doFundTransView = function(accountNumber, preferredName, currCode, accType, availableBal) {
            var accNumber = accountNumber.trim();
            $window.sessionStorage.removeItem("fundTransAccountNumber");
            $window.sessionStorage.setItem("fundTransAccountNumber", accNumber);
			$window.sessionStorage.removeItem("fundTransAccountType");
			$window.sessionStorage.setItem("fundTransAccountType", accType);
            $window.sessionStorage.removeItem("fundTransPrefferedName");
            $window.sessionStorage.setItem("fundTransPrefferedName", preferredName);
            $window.sessionStorage.removeItem("fundTransCurrencyCode");
            $window.sessionStorage.setItem("fundTransCurrencyCode", currCode);
            $window.sessionStorage.removeItem("fundTransAvailableBalance");
            $window.sessionStorage.setItem("fundTransAvailableBalance", availableBal);
            $window.location.href = fundTransferUrl;
        };
        self.showPayBill = function(accountNum) {
            var flag = true;
            angular.forEach(payBillAccounts, function(payBillAccount) {
                if (payBillAccount.accountNumber.trim() === accountNum) {
                    flag = false;
                }

            });
            return flag;
        };
        self.showFundTransfer = function(accNum) {
            var fundTransFlag = true;
            angular.forEach(fundTransFromAccounts, function(fundTransAccount) {
                if (fundTransAccount.accountNumber.length > 10) {
                    fundTransAccount.accountNumber = fundTransAccount.accountNumber.substr(fundTransAccount.accountNumber.length - 10);
                }
                if (fundTransAccount.accountNumber === accNum)
                    fundTransFlag = false;
            });
            return fundTransFlag;
        };
		function checkOTPStatus(){
			var otpFlag = $window.sessionStorage.getItem("otpFlag");
			var currentSessionStatus = $window.sessionStorage.getItem("currentSessionStatus");
			var lastlonDate = $window.sessionStorage.getItem("lastLoggedIn");
			if (lastlonDate && lastlonDate !== "") {
				var lastLoggedIn = lastlonDate.substring(0, 12);
			}
			var today = new Date();
			var todayDate = $filter('date')(today, "MMM dd, yyyy");
			if(otpFlag === '' && currentSessionStatus === 'show'){
				AccountDetailsService.otpModalStatus('openOtpStatusModal.html');
			}
			if (otpFlag === 'M' && lastLoggedIn !== todayDate && currentSessionStatus === 'show') {
				AccountDetailsService.otpModalStatus('openOtpStatusModal.html');
			}
		}
		checkOTPStatus();
        /* Sprint-2 Code End */
    };
		
     exports.otpModalCtrl = function($modalInstance, $window, AccountDetailsService,lpWidget) {
        var omCtrl = this;
        omCtrl.mobNumber = $window.sessionStorage.getItem('mobileNum');
        var userName = $window.sessionStorage.getItem("userName");
        omCtrl.closeModal = function() {
            $modalInstance.dismiss('cancel');
        }
        omCtrl.enableOtp = function() {
			$modalInstance.dismiss('cancel');
			var otpRegistrationUrl = lpWidget.getResolvedPreference('otpregistration');
            $window.location.href = otpRegistrationUrl;
        };
        omCtrl.maybeLater = function() {
            var reqPayload = {
                "status": "M",
                "userName": userName
            };
            AccountDetailsService.dontAskAgainApiCall(reqPayload).then(function(response) {
                    //This call is getting successful
                },
                function(error) {
                    //This call is getting failure
                });
            $window.sessionStorage.setItem("currentSessionStatus", "hide");
            $modalInstance.dismiss('cancel');
        };
        omCtrl.dontAskAgain = function() {
            var reqPayload = {
                "status": "NA",
                "userName": userName
            };
            AccountDetailsService.dontAskAgainApiCall(reqPayload).then(function(response) {
                    //This call is getting successful
                },
                function(error) {
                    //This call is getting failure
                });
            $window.sessionStorage.setItem("currentSessionStatus", "hide");
            $modalInstance.dismiss('cancel');
        };

    };
});