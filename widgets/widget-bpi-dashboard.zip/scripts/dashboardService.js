/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : accountDetails-service.js
 *  Description: account details-service
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.AccountDetailsService = function($http,$modal,$window,lpWidget) {
			var protocolHost = $window.location.protocol+'//'+$window.location.host;
			var RM_TRAILER = protocolHost+lpWidget.getResolvedPreference('rmTrailer');
			var SAVINGS_AND_CHECKING_BALANCE = protocolHost+lpWidget.getResolvedPreference('savingAndCheckingBalance');
			var CREDIT_CARD_BALANCE = protocolHost+lpWidget.getResolvedPreference('ccBalance');
			var CONSUMER_LOANS = protocolHost+lpWidget.getResolvedPreference('consumerLoans');
			var TIME_DEPOSIT_DETAILS = protocolHost+lpWidget.getResolvedPreference('timedeposit');
			var ACCOUNT_PORTFOLIO_DETAILS = protocolHost+lpWidget.getResolvedPreference('investmentBalance');
			var RM_MOBILE_NUMBER = protocolHost+lpWidget.getResolvedPreference('rmmobilenumberservice');
			var NA_REGISTER = protocolHost+lpWidget.getResolvedPreference('transactionlog');
			this.otpModalStatus = function(CurrentModal) {
                var modalInstance=$modal.open({
                    templateUrl:CurrentModal,
                    controller: 'otpModalCtrl as mic',
                    windowClass: 'ModalContainer',
                    backdrop: 'static'
                }); 
            };
            this.dontAskAgainApiCall = function(reqPayload) {
                return $http({
                   url: NA_REGISTER,
                    method: "POST",
                    data: reqPayload,
					headers: {'URL':'NA'}
                })
            };
        this.getRMTrailer = function(req) {
                return $http({
                    url: RM_TRAILER,
                    method: "POST",
                    data: req,
					headers: {'URL':'RM_TRAILER','KEY':'SPRINT1B','VALUE':'YES'}
                    // Static API for Offshore testing
                    // url: "https://api.myjson.com/bins/qkku5",
                    // method: "GET",
                });
            },
            this.getSavingAndCheckings = function(req) {
                return $http({
                    url: SAVINGS_AND_CHECKING_BALANCE,
                    method: "POST",
					data: req,
					headers: {'URL':'SAVING_CHECKING_BALANCE','KEY':'SPRINT1B','VALUE':'YES'}
                    // Static API for Offshore testing
                     // url: "https://api.myjson.com/bins/vnrhn",
                     // method: "GET",
                });
            },
            this.getCreditCardBB = function(req) {
                return $http({
					url: CREDIT_CARD_BALANCE,
                    method: "POST",
                    data: req,
					headers: {'URL':'CREDITCARD_BALANCE','KEY':'SPRINT1B','VALUE':'YES'}
                    //Static API for Offshore testing
					 // url: "https://api.myjson.com/bins/wmzed",
                     // method: "GET",
                });
            };
        this.getPrepaidCardBB = function(req) {
            return $http({
				url: CREDIT_CARD_BALANCE,
				method: "POST",
                data: req,
				headers: {'URL':'CREDITCARD_BALANCE','KEY':'SPRINT1B','VALUE':'YES'}
                // Static API for Offshore testing
                // url: "https://api.myjson.com/bins/o79gp",
                 // method: "GET",
            });
        };

        this.getLoans = function(req) {
            return $http({
                 url: CONSUMER_LOANS,
				 method: "POST",
				 data: req,
				 headers: {'URL':'CONSUMER_LOANS','KEY':'SPRINT1B','VALUE':'YES'}
                // Static API for Offshore testing
                 // url: "https://api.myjson.com/bins/e1nqh",
                 // method: "GET",
            });
        };
        this.getTimeDeposit = function(req) {
            return $http({
				//Actual API
                url: TIME_DEPOSIT_DETAILS,
                method: "POST",
				data: req,
				headers: {'URL':'TIME_DEPOSIT','KEY':'SPRINT1B','VALUE':'YES'}
                // Static API for Offshore testing
                 // url: "https://api.myjson.com/bins/7rx6x",
                 // method: "GET",
            });
        };
        this.getInvestment = function(req) {
            return $http({
                //Actual API
				url: ACCOUNT_PORTFOLIO_DETAILS,
                method: "POST",
				data: req,
				headers: {'URL':'INVESTMENT_BALANCE_DETAILS','KEY':'SPRINT1B','VALUE':'YES'}
				// Static API for Offshore testing
				 // url:"https://api.myjson.com/bins/o19q1",
				 // method:"GET"
            });
        };
		this.getMobileNumber = function(rmNumber){
		 var otpStatus = $window.sessionStorage.getItem("otpStatus");
			if (!otpStatus || otpStatus === "") {
				var req = {"rmNumber":rmNumber,"mobileNumber":""};
				$http({
                    url: RM_MOBILE_NUMBER,
                    method: "POST",
                    data: req,
					headers: {'URL':'MOBILE_VALIDATION_URL'}	
                }).then(function(response) {
					if (response.data.returnCode === "0") {
						$window.sessionStorage.setItem("mobileNum", response.data.returnMessage);
					} else {
						$window.sessionStorage.setItem("mobileNum", '');
					}
				},
				function(response) {
					var returnErrorMessage = response.status;
				});
			}
		};
    };

});
