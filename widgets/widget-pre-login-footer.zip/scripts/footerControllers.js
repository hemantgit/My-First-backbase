/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : footerControllers.js
 *  Description: BPI Footer controller
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget) {
        var widget = lpWidget;
        var self = this;
        var utils = lpCoreUtils;
        self.logo = utils.resolvePortalPlaceholders(widget.model.getPreference("logo")) || "";
        self.bancnet = utils.resolvePortalPlaceholders(widget.model.getPreference('bancnet')) || ''
        self.verisign = utils.resolvePortalPlaceholders(widget.model.getPreference('verisign')) || ''
		//getting height of the footer
        var footerHeight = angular.element(".pageContainer [data-pid*='Footer']").height();
        angular.element('.pageContainer [data-pid*="container-simple-page-layout"]').css('padding-bottom', footerHeight);
		//method for resizing background
        var BackgroundResize = function() {
            var headerHeight = angular.element('.bpiPreHeader').height();
            var footerHeight = angular.element('.preFooter').height();
            var windowHeight = angular.element(window).height();
            angular.element('.simple-page-layout').css("min-height", windowHeight);
            angular.element('.simple-page-layout').css("padding-top", headerHeight);
            angular.element('.simple-page-layout').css("padding-bottom", footerHeight);
            //angular.element('.simple-page-layout').css("margin-bottom",footerHeight);
            //angular.element('.bp-manageableArea').css("max-height",(windowHeight - (headerHeight+footerHeight)));
            //console.log("windowHeight :"+windowHeight);

        }
		//calling method for resizing background
        BackgroundResize();
        angular.element(window).bind('resize', function() {
            BackgroundResize();
        });


    };
});