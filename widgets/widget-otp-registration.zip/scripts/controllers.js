
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.OtpMainCtrl = function($filter,lpWidget, lpCoreBus, $window, modalCalService, CountriesInfo) {
        var self = this;
		var bus = lpCoreBus;
        self.mobileActivated = true;
		self.enteredMobileNumber='';
		self.showPhilipInput = true;
		self.disSubmitBtm = false;
		self.dateConfNum =null;
		var userId = $window.sessionStorage.getItem("userName");
		var firstName = $window.sessionStorage.getItem('firstName');
		var lastName = $window.sessionStorage.getItem('lastName');
		var emailId = $window.sessionStorage.getItem('emailId');
		var rmNumber = $window.sessionStorage.getItem("rmNumber");
		var invalidFormatModal = lpWidget.getResolvedPreference('InvalidFormatModal');
		var invalidInterMobModal = lpWidget.getResolvedPreference('InvalidInterMobModal');
		var invalidMobileModal = lpWidget.getResolvedPreference('InvalidMobileModal');
		var okModal = lpWidget.getResolvedPreference('OkModal');
		var serverErrorModal = lpWidget.getResolvedPreference('ServerErrorModal');
		//rmNumber =  "00000000633442";
		self.mobileNum = $window.sessionStorage.getItem('mobileNum');
		var onAction1 = parseInt(lpWidget.getPreference('onAction1'), 10) - 1;
        var onAction2 = parseInt(lpWidget.getPreference('onAction2'), 10) - 1;
		var _deck = document.querySelector('[data-pid^="deck-container"]');
        if(_deck){
			_deck = _deck.viewController;
		}
		self.optionsSize = 0;
		self.increaseSize = function(){
			self.optionsSize = 8;
		}
		self.setSizeZero = function(){
			self.optionsSize = 0;
		};
		if(rmNumber){
			self.hideRmDownDiv = true;
		}
		else {
			self.serverErrorMsg = lpWidget.model.getPreference("serverErrMsg");
			self.hideRmDownDiv = false;
		}
		self.selectMobCun=CountriesInfo.countries;
		self.matchToPhilip = {"name":"Philippines (+63)","code":"+63"};
		self.countryCode = self.matchToPhilip.code;
		self.updateMobCode=function(ccode, id){
		    self.countryCode=ccode; 
			if(self.countryCode=='+63'){
				self.showPhilipInput = true;
			} else {
				self.showPhilipInput = false;
			}
			self.setSizeZero();
		};
		self.onSubmit = function() {
			self.disSubmitBtm = true;
			if(self.showPhilipInput){
				if(self.enteredMobileNumber.length == 10){
					self.dateConfNum = modalCalService.getDateConfNum(rmNumber);
					var PhilipreqPayload={
						"rmNumber": rmNumber,
						"username": userId,
						"firstName": firstName,
						"lastName": lastName,
						"mobileNumber": self.countryCode+''+self.enteredMobileNumber,
						"confirmationNumber":self.dateConfNum.confirmationNumber
					};
					self.otpGenerationApiCall(PhilipreqPayload);
				} else{
					modalCalService.openModal(invalidFormatModal);
				}
			}else{
				if(self.enteredMobileNumber.length >= 5){
					self.dateConfNum = modalCalService.getDateConfNum(rmNumber);
					var interNationReqPayload={
						"rmNumber": rmNumber,
						"username": userId,
						"firstName": firstName,
						"lastName": lastName,
						"mobileNumber": self.countryCode+''+self.enteredMobileNumber,
						"confirmationNumber":self.dateConfNum.confirmationNumber
					};
					self.otpGenerationApiCall(interNationReqPayload);
				} else{
					modalCalService.openModal(invalidInterMobModal);
				}
			}	
		};
		self.otpGenerationApiCall = function (reqPayload){
			modalCalService.doOtpGeneration(reqPayload).then(function(response) {
				if (response.data.returnCode == '200') {
					modalCalService.openModal(okModal);
					self.sendEmailNotification(reqPayload);
					$window.sessionStorage.setItem("otpFlag", "YES");
					$window.sessionStorage.setItem("otpStatus", "1");
					$window.sessionStorage.setItem("mobileNum", reqPayload.mobileNumber);
					bus.publish('OtpConfNumDate', {
						mobileNum:reqPayload.mobileNumber,
						conformationNumber:self.dateConfNum.transDate,
						transDateTime:self.dateConfNum.confirmationNumber
					});
					_deck.showPanel(_deck.getPanel(onAction2));
				} else {
					modalCalService.openModal(invalidMobileModal);
				}
			},
			function(response) {
					modalCalService.openModal(serverErrorModal);
			});
		};
		self.sendEmailNotification = function(reqPayload) {
           var regDate = $filter('date')(self.dateConfNum.transDate, "MMM. dd, yyyy h:mm:ss a");
            var request = {
                "msg": {
                    "from": "abc@bpi.com.ph",
                    "to": emailId,
                    "subject": "One-Time PIN Registration",
                    "text": "Your Transaction got Successful",
                    "html": "<html><head></head>"+
					"<body><div class='row'><h4>Dear "+firstName+" "+lastName+", </h4><p>Greetings from BPI Online Banking! </p><p>This is to confirm your registration in the One-Time PIN facility:</p>"+
					"<div class='table table-responsive'><table style='border:2px solid #c7c7c7;border-radius:5px;width:40%;margin:0 auto;'>" +
					"<tr><td style='text-align:center;'colspan='2'> </td></tr>"+
					"<tr><td style='text-align:left;padding:4px;width:24%; text-align:center;'colspan='2'><span style='font-size:25px;'>OTP Registration Details</span></td></tr>"+ 
					"<tr><td style='text-align:left;padding-left:20px;padding-right:24px;width:24%; text-align:center;'colspan='2'><div style='border-bottom:1px solid #c7c7c7'></div></td></tr>"+ 
					"<tr><td style='text-align:left;padding-left:20px;width:24%;'>Mobile Number </td>"+"<td style='text-align:left;padding:4px;width:24%;'>"+reqPayload.mobileNumber +"</td></tr>"+					
					"<tr><td style='text-align:left;padding-left:20px;width:24%;'>Registration Date and Time</td><td style='text-align:left;padding:4px;width:24%;'>"+regDate+"</td></tr>"+
					"<tr><td style='text-align:left;padding-left:20px;width:24%;'>Confirmation Number</td><td style='text-align:left;padding:4px;width:24%;'>"+self.dateConfNum.confirmationNumber+"</td></tr>"+
					"<tr><td style='padding-bottom:15px;'></td></tr></table></div>"+		
					"<br><br><div class='row'>An SMS containing an activation code has been sent to your mobile number. This lets you link a device to your profile, allowing you to generate an OTP using the BPI app. <br><br>"+
					"To use the activation code, login to the BPI app > Menu > Security Settings > One-Time PIN > Link this device<br><br>"+
					"Should you have comments, questions or complaints regarding this particular transaction, please e-mail us at <a href='javascript:void(0)'>expressonline@bpi.com.ph</a> <br><br>"+
					"Thank you for banking with us! <br><br>From the BPI Online Banking Team</div></div></body></html>"
             

					}
            };
            modalCalService.sendEmailNotification(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    
						//This call is getting failure
				});
        };
		modalCalService.communicateCtrl = function(){
			self.disSubmitBtm = false;
		}
    };
	exports.modalInstanceCtrl = function($modalInstance, $window, modalCalService) {
		var self= this;
		var rmNumber = $window.sessionStorage.getItem("rmNumber");
		
		self.closeGuideModal = function () {
            $modalInstance.dismiss('cancel');
        };
		self.closeokModal = function () {
            $modalInstance.dismiss('cancel');
        };
		self.cancelModal = function () {
            $modalInstance.dismiss('cancel');
			modalCalService.communicateCtrl();
        };
	};
});