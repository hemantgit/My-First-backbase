define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.focusMe = function($timeout) {
        return {
            scope: {
                focusMeIf: "="
            },
            link: function(scope, element, attrs) {
                if (scope.focusMeIf === undefined || scope.focusMeIf) {
                    $timeout(function() {
                        element[0].focus();
                    });
                }
            }
        };
    };
});