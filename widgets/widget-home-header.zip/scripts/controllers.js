/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : homeHeaderCtrl.js
 *  Description: BPI Home Header controller
 *  ----------------------------------------------------------------
 */ 
define(function(require, exports) {

        "use strict";

    // @ngInject
        exports.MainCtrl = function(lpCoreUtils, lpWidget, lpPortal) {
                var utils = lpCoreUtils;
                var widget = lpWidget;
                var self = this;
                self.logout = utils.resolvePortalPlaceholders(widget.model.getPreference("logout")) || "";
                self.bpiLogo = utils.resolvePortalPlaceholders(widget.model.getPreference("bpiLogo")) || "";

 angular.element('li.dropdown-submenu').on("mouseenter", function(e){
   angular.element(this).children('ul').css('display','block');
    e.stopPropagation();
    e.preventDefault();
  });
  
angular.element('li.dropdown-submenu').on("mouseleave", function(e){
   angular.element(this).children('ul').css('display','none');
    e.stopPropagation();
    e.preventDefault();
  });
};
});