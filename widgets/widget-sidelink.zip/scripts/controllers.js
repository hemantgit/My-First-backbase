/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controllers.js
 *  Description: sidelink controllers 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";
	exports.MainCtrl = function(lpCoreUtils, lpWidget, $window, $location) {
		var utils = lpCoreUtils;
		var widget = lpWidget;
		var self = this;
		//self.pageUri = lpCoreUtils.last($location.absUrl().split('/'));
		//console.log(lpCoreUtils.last($location.absUrl().split('/')));
		//var protocol_Host = $window.location.protocol+'//'+$window.location.host;
		var login_success = lpWidget.getResolvedPreference('loginsuccess');
		var credit_cardoverview = lpWidget.getResolvedPreference('creditcardoverview');		
		var funds_transfer = lpWidget.getResolvedPreference('fundstransfer');
		var pay_bills = lpWidget.getResolvedPreference('paybills');
		var otpRegistration = lpWidget.getResolvedPreference('otpregistration');
		var otpLinkYourDeviceNavUrl = lpWidget.getResolvedPreference('otplinkyourdevice');
		var otpOtherServices = lpWidget.getResolvedPreference('otpothersevices');
		var removeAccount = lpWidget.getResolvedPreference('removeaccount');
		
		self.otpStatusSubMenu = true;
		/*if( $window.sessionStorage.getItem("otpFlag") == 'YES'){
			self.otpStatusSubMenu = false;
        }*/
		self.ImgUrl = getImage("ImgUrl");
		self.myAcc = getImage("myAcc");
		self.myAcc1 = getImage("myAcc1");
		self.transfer = getImage("transfer");
		self.transfer1 = getImage("transfer1");
		self.paybill = getImage("paybill");
		self.paybill1 = getImage("paybill1");
		self.customer = getImage("customer");
		self.customer1 = getImage("customer1");
		self.security = getImage("security");
		self.security1 = getImage("security1");
		self.bpiApp = getImage("bpiApp");
		self.bpiApp1 = getImage("bpiApp1");
		self.investment = getImage("investment");
		self.investment1 = getImage("investment1");
		self.sideLinkReorder = getImage("sideLinkReorder");
		self.appointment = getImage("appointment");
		function getImage(imageName){
			return utils.resolvePortalPlaceholders(widget.model.getPreference(imageName)) || "";
		}
		self.goToHomePage = function() {
				$window.location.href = login_success;//ACCOUNT_DETAILS;
		};
		self.lastLoggedIn = $window.sessionStorage.getItem('lastLoggedIn');
		self.gotoFundsTransfer = function() {
            $window.location.href = funds_transfer;//FUNDS_TRANSFER;
        }
		self.gotoPayBills = function() {
            $window.location.href = pay_bills;//PAY_BILLS;
        }
		self.gotoOtpGeneration = function() {
			$window.location.href = otp_generation;//OTP_GENERATION;
        }
		self.gotoOtpOtherServices = function() {
			$window.location.href = otp_otherservices;//OTP_OTHER_SERVICES;
        }
		self.removeAccount = function() {
			$window.location.href = removeAccount;
        }
		/*self.gotoSecuritySettings = function(){
			//$window.location.href = otpOtherServices;
			if( $window.sessionStorage.getItem("otpFlag") === "NA" ){
				if( $window.sessionStorage.getItem("otpStatus") === "3" ){
					if( $window.sessionStorage.getItem("deviceName") !== "" ){
						$window.location.href = otpOtherServices;
					} else {
						$window.location.href = otpLinkYourDeviceNavUrl;
					}
				} else {
					$window.location.href = otpLinkYourDeviceNavUrl;
				}
			} else if( $window.sessionStorage.getItem("otpFlag") === "YES" ){
				if( $window.sessionStorage.getItem("otpStatus") === "1" ){
					$window.location.href = otpLinkYourDeviceNavUrl;
				} else if( $window.sessionStorage.getItem("otpStatus") === "2" ){
					$window.location.href = otpOtherServices;
				}
			} else {
				$window.location.href = otpLinkYourDeviceNavUrl;
			}
		};*/
		self.gotoSecuritySettings = function(){
			if( $window.sessionStorage.getItem("otpStatus") === "2" ){
				$window.location.href = otpOtherServices;
			} else if( $window.sessionStorage.getItem("otpStatus") === "3" ){
				if( $window.sessionStorage.getItem("deviceName") !== "" ){
					$window.location.href = otpOtherServices;
				} else {
					$window.location.href = otpLinkYourDeviceNavUrl;
				}
			} else {
				$window.location.href = otpLinkYourDeviceNavUrl;
			}
		};
        angular.element('.sideLinks li').mouseenter(function() {
            if (!angular.element(this).hasClass('activeLink')) {
                angular.element(this).find('.bhover').hide();
                angular.element(this).find('.ahover').show();
            }
        })
        angular.element('.sideLinks li').mouseleave(function() {
            if (!angular.element(this).hasClass('activeLink')) {
                angular.element(this).find('.bhover').show();
                angular.element(this).find('.ahover').hide();
            }
        })
		var index, filenameWithExtension, filename;
		var url=window.location.href;
		if(url.search("#")>=0) {
			var urlTrimed= url.substring(0, url.indexOf('#'));
			index = urlTrimed.lastIndexOf("/") + 1,
			filenameWithExtension = urlTrimed.substr(index),
			filename = filenameWithExtension.split(".")[0]; 
			angular.element("."+filename).addClass("activeLink");
			setTimeout(function(){angular.element("."+filename).parents("ul").prev("li").click()},100);
			angular.element("."+filename).siblings().removeClass("activeLink");
		}
		else {
			index = window.location.href.lastIndexOf("/") + 1,
			filenameWithExtension = window.location.href.substr(index),
			filename = filenameWithExtension.split(".")[0]; 
			angular.element("."+filename).addClass("activeLink");
			setTimeout(function(){angular.element("."+filename).parents("ul").prev("li").click()},100);	
			angular.element("."+filename).siblings().removeClass("activeLink");
		}
		/*angular.element(".security").next("ul").hide();
		angular.element(".security").click(function(){
			angular.element(this).next("ul").toggle();
			angular.element(this).children("i").toggleClass("glyphicon-menu-right");
			angular.element(this).children("i").toggleClass("glyphicon-menu-down");
		});
		angular.element(".otp-pin-fac").next("ul").hide();
		angular.element(".otp-pin-fac").click(function(){
			angular.element(this).next("ul").toggle();
			angular.element(this).children("i").toggleClass("glyphicon-menu-right");
			angular.element(this).children("i").toggleClass("glyphicon-menu-down");
		});*/
	};
});