/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : main.js
 *  Description: Provides functioality for sideLinks
 *  ----------------------------------------------------------------
 */

define( function (require, exports, module) {

        "use strict";

        module.name = "widget-sideLinks";

        var base = require("base");
        var core = require("core");
        var ui = require("ui");

        var deps = [
                core.name,
                ui.name
        ];

    // @ngInject
        function run() {
        // Module is Bootstrapped
        }

        module.exports = base.createModule(module.name, deps)
        .controller( require("./controllers") )
        .run( run );
});