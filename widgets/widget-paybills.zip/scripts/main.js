/**
 *  ----------------------------------------------------------------
 *  Copyright © BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : main.js
 *  Description: ${widget.description}
 *  ----------------------------------------------------------------
 */

define( function (require, exports, module) {

    'use strict';

    module.name = 'widget-paybills';

    var base = require('base');
    var core = require('core');
	var ui = require('ui');
    var customModule = require('module-custom-bpi');
    var deps = [
        core.name,
        ui.name,
		customModule.name
    ];

    // @ngInject
    function run() {
        // Module is Bootstrapped
    }
	

    module.exports = base.createModule(module.name, deps)
        .controller( require('./controllers'))
		.directive(require('./auto-focus-next-directive'))
		.directive(require('./input-format-directive'))
        .directive(require('./currency-format-directive'))
		.service(require('./payBills-Service'))
        .run( run );
});
