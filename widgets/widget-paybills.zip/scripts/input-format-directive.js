define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.formatInputField = function() {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function(scope, element, attrs, modelCtrl) {
                if (attrs.format == 'number') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\d]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
                if (attrs.format == 'phoneNumber') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\d+]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
                if (attrs.format == 'alphaNumeric') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^a-zA-Z0-9]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
                if (attrs.format == 'notes') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\sa-zA-Z0-9,.-]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
            }
        };
    };
});