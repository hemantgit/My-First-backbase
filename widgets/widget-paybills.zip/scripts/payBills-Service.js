define(function(require, exports) {
    'use strict';

    // @ngInject
    exports.PayBillsService = function($http, $window, $modal,lpWidget) {
        var self = this;
        self.payBillReqObj = {};
        self.addRef_Notes = {};
        self.dateConfirmObj = {};
        self.returnErrorMessage = null;
        self.toolTip = null;
        self.resetForm = false;
		self.showNewMobReg = true;
		/* API Calls*/
		
		var protocol_Host = $window.location.protocol+'//'+$window.location.host;
		var bp_Merchlist = protocol_Host+lpWidget.getResolvedPreference('bpmerchlist');
		var bills_pay = protocol_Host+lpWidget.getResolvedPreference('billspay');
		var request_SmsOtp = protocol_Host+lpWidget.getResolvedPreference('requestsmsotp');
		var forceRegistration = protocol_Host+lpWidget.getResolvedPreference('forceregistration');
		var auth_SmsOtp = protocol_Host+lpWidget.getResolvedPreference('authsmsotp');
		var auth_MobileOtp = protocol_Host+lpWidget.getResolvedPreference('authmobileotp');
		var transaction_Log = protocol_Host+lpWidget.getResolvedPreference('transactionlog');
		var financial_Emailnotif = protocol_Host+lpWidget.getResolvedPreference('financialemailnotif');
		var savings_Checking = protocol_Host+lpWidget.getResolvedPreference('savingAndCheckingBalance');
		
        self.openModal = function(CurrentModal) {
            var modalInstance = $modal.open({
                templateUrl: CurrentModal,
                controller: 'ModalInstanceController as mic',
                windowClass: 'ModalContainer',
                backdrop: 'static'
            });
        };
        self.getConfNum = function(rmNumber) {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            var yy = yyyy.toString().slice(-2);
            var hh = today.getHours();
            var minits = today.getMinutes();
            var ss = today.getSeconds();
            var ran = Math.floor((Math.random() * 10));
            if (dd < 10) {
                dd = '0' + dd;
            }
            if (mm < 10) {
                mm = '0' + mm;
            }
            if (hh < 10) {
                hh = '0' + hh;
            }
            if (ss < 10) {
                ss = '0' + ss;
            }
            if (minits < 10) {
                minits = '0' + minits;
            }
            return {
                'transDate': today,
                'confirmationNumber': rmNumber.toString().slice(-10) + '' + dd + '' + mm + '' + yy + '' + hh + '' + minits + '' + ss + '' + ran
            };
        };
        self.getSourceAcctDetails = function(req) {
                return $http({
                    url: savings_Checking,//SAVINGS_AND_CHECKING_BALANCE,
                    method: "POST",
                    data: req,
					headers: {'URL':'SAVING_CHECKING_BALANCE'}					
                    //Static API for Offshore testing
					// url: "https://api.myjson.com/bins/pxo7h",
                    // method: "GET"
                })
            },
            self.getMerchantListDetails = function(req) {

                return $http({
					url: bp_Merchlist,//PAY_BILLS_MERCHANTS, 
					method: "POST",
					data: req,
					headers: {'URL':'BP_MERCH_LIST'}
                    // Static API for Offshore testing
                    //url: "https://api.myjson.com/bins/yfaar",
                    // url: "https://api.myjson.com/bins/168sv7",
                    // method: "GET"
                })
            },
            self.makeBillPayment = function() {
                return $http({
                    url: bills_pay,//MAKE_PAY_BILL,
                    method: "POST",
                    data: self.payBillReqObj,
					headers: {'URL':'BILLS_PAY'}
                })
            },
            self.sendSMSforOTP = function(req) {
                return $http({
                    url: request_SmsOtp,//REQUEST_SMS_OTP,
                    method: "POST",
                    data: req,
					headers: {'URL':'SMS'}
                })
            },
			self.doForceRegistration = function(req) {
                return $http({
                    url: forceRegistration,
                    method: "POST",
                    data: req
                })
            },
            self.submitAuthMobileOTPVal = function(req) {
                return $http({
                    url: auth_MobileOtp,//AUTH_MOBILE_OTP,
                    method: "POST",
                    data: req
                })
            },
            self.submitOTP = function(req) {
                return $http({
                    url: auth_SmsOtp,//AUTH_SMS_OTP,
                    method: "POST",
                    data: req
                })
            },
            self.insertToTransactionLog = function(req) {
                return $http({
                    url: transaction_Log,//TRANSACTION_LOG,
                    method: "POST",
                    data: req,
					headers: {'URL':'TRANSACTION_LOG'}
                })
            },
			self.getOtpStatus = function(req) {
                return $http({
                    url: transaction_Log,//TRANSACTION_LOG,
                    method: "POST",
                    data: req,
					headers: {'URL':'GET_OTP_STATUS'}
                })
            },
            self.sendEmailNotification = function(req) {
                return $http({
                    url: financial_Emailnotif,//EMAIL_NOTIFICATION,
                    method: "POST",
                    data: req,
					headers: {'URL':'FINANCIAL_EMAIL_NOTIF'}
                })
            }
    };
});