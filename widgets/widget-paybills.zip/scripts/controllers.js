/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : paybillsCtrl.js
 *  Description: BPI Pay Bills controller
 *  ----------------------------------------------------------------
 */ 
define(function(require, exports) {

    'use strict';

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget, $window, PayBillsService, $rootScope, conversionCodes) {
        var self = this;
		self.loading = true;
        self.toolTip = lpCoreUtils.resolvePortalPlaceholders(lpWidget.model.getPreference('toolTip')) || '';
        self.addIcon = lpCoreUtils.resolvePortalPlaceholders(lpWidget.model.getPreference('addIcon')) || '';
		var validation = lpWidget.getResolvedPreference('validation');
		var ReviewModal = lpWidget.getResolvedPreference('ReviewModal');
        PayBillsService.toolTip = self.toolTip;
        var rmNumber = $window.sessionStorage.getItem('rmNumber');
        //rmNumber = 12345678901234;
        self.showMainContentDiv = true;
        self.showRmDownDiv = false;
        self.showNoAccFoundDiv = false;
        self.showNoMerAccDiv = false;
        self.payFromSelected = false;
        self.myAccountsData = [];
		self.enrolledMerchantsData = [];
        self.confNum = null;
        var rmtReq = {};
        self.expanded = false;
        self.closed = true;
        self.expand = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        };
        $rootScope.$on('resettags', function() {
            self.resetToStarting();
            self.getMyAccounts();
        });
		/* If Rmtrailer has rmNUmber */
        if (rmNumber) {
            self.currentState = 'payTo';
            self.amountTo = true;
            self.toDayDate = new Date();
            self.enteredAmount = "";
            self.responseMsg = null;
            self.myAccountsData = [];
			/* Source accounts from Session */
            self.paybillsMyAccounts = angular.fromJson($window.sessionStorage.getItem('paybillsMyAccounts'));
            self.currencyCodeJSON = conversionCodes.currencyCode;
			/* Object to hide and show different components in paybills form*/
            self.ngifObj = {
                "merDiv": true,
                "parentMerList": true,
                "sourceAccListDiv": false,
                "paymentTypeDiv": false,
                "refNoDiv": false,
                "addRefNoDiv": false,
                "payFromInput": true,
                "payToInput": true,
                "addRefNoInput": false,
                "amountTabDiv": false
            };
			/* Object to hold the Selected account details */
            self.billPaymentObj = {
                "noteToPay": '',
                "payTo": '',
                "preferredName": '',
                "tranID": "IMPB",
                "termID": "", 
                "sourceAcctType": null, 
                "sourceCurrCode": null,
                "sourceAcctNum": null,
                "amount": '',
                "sourceRMNum": rmNumber,
                "sourceTraceNum": "9999999",
                "destinationAcctType": null, 
                "destinationCurrCode": null, 
                "destinationAcctNum": null,
                "destinationTraceNum": "9999999",
                "referenceNum": null,
                "additionalRefNum": '',
                "mercCode": null, 
                "prodCode": null, 
                "merchantFINum": null 
            };
            self.transFromErr = false;
            self.transFromTOErr = false;
            self.transamt = false;
            self.greatthanzero = false;
            self.lessthanzero = false;
            self.addrefval = false;
            self.payToRemove = true;
            self.payFromRemove = true;
            var payBillsAccountNumber = $window.sessionStorage.getItem('payBillsAccountNumber');
            var payBillsPrefferedName = $window.sessionStorage.getItem('payBillsPrefferedName');
            var payBillsAccountType = $window.sessionStorage.getItem('payBillsAccountType');
            var payBillsAvailableBalance = $window.sessionStorage.getItem('payBillsAvailableBalance');
            var payBillsCurrencyCode = $window.sessionStorage.getItem('payBillsCurrencyCode');
            if (payBillsAccountNumber && payBillsPrefferedName && payBillsCurrencyCode && payBillsAccountType) {
                self.billPaymentObj.preferredName = payBillsPrefferedName;
                self.billPaymentObj.sourceAcctNum = payBillsAccountNumber;
                self.billPaymentObj.sourceCurrCode = payBillsCurrencyCode;
                self.billPaymentObj.sourceAcctType = payBillsAccountType;
                self.maxAmount = payBillsAvailableBalance;
                self.payFromSelected = true;
                self.ngifObj.payFromInput = false;
                self.payFromSelected = true;
                $window.sessionStorage.removeItem("selAccCurrencyName");
                $window.sessionStorage.setItem("selAccCurrencyName", self.currencyCodeJSON[payBillsCurrencyCode.substring(1)]);
                $window.sessionStorage.removeItem("payBillsAccountNumber");
                $window.sessionStorage.removeItem("payBillsAccountType");
                $window.sessionStorage.removeItem("payBillsPrefferedName");
                $window.sessionStorage.removeItem("payBillsCurrencyCode");
                $window.sessionStorage.removeItem("payBillsAvailableBalance");
            }
            rmtReq.rmNumber = rmNumber;
			/* Get merchants account details */
            self.getMerchants = function() {
				self.loading = true;
                PayBillsService.getMerchantListDetails(rmtReq).then(function(response) {
                        self.enrolledMerchantsData = response.data.MerchantList;
                        if (response.data.MerchantList && response.data.MerchantList.length == 0) {
                            self.showMainContentDiv = false;
                            self.showNoMerAccDiv = true;
                        }
						self.loading = false;
                    },
                    function(response) {
						self.loading = false;
                        if (conversionCodes.errorStatus(response)) {
                            self.errorMsg = lpWidget.model.getPreference('serverError');
                        }
                    });
            };
			/* Get source accounts details */
            self.getMyAccounts = function() {
				self.loading = true;
                PayBillsService.getSourceAcctDetails(self.paybillsMyAccounts).then(function(response) {
                        self.mydata = response.data;
                        self.myAccountsData = response.data.SavingsChecking;
						self.loading = false;
                    },
                    function(response) {
						self.loading = false;
                        if (conversionCodes.errorStatus(response)) {
                            self.errorMsg = lpWidget.model.getPreference('serverError');
                        }
                    });
            };
            if (self.paybillsMyAccounts && self.paybillsMyAccounts.SavingsChecking.length >= 1) {
                self.getMerchants();
                self.getMyAccounts();
            } else {
                self.showNoAccFoundDiv = true;
                self.showMainContentDiv = false;
				self.loading = false;
            }
            self.onSelectMerchantAccount = function(acc) {
                self.removeErrorMsg();
                self.setBillPaymentObjonSelectMerchant(acc);

                self.setStateonSelectMerchant(acc);
            };
			/* On select Merchant account for bill payment*/
            self.setBillPaymentObjonSelectMerchant = function(acc) {
                self.billPaymentObj.additionalRefNum = "";
                self.billPaymentObj.destinationAcctNum = acc.settlementAccount;
                self.billPaymentObj.destinationAcctType = acc.merchantName;
                self.billPaymentObj.destAccType = acc.accountType;
                self.billPaymentObj.destinationCurrCode = acc.currencyCode;
                self.billPaymentObj.referenceNum = acc.referenceNumber;
                self.billPaymentObj.mercCode = acc.merchantCode;
                self.billPaymentObj.merchantFINum = acc.institutionCode;
                self.billPaymentObj.prodCode = acc.productCode;
                self.billPaymentObj.payTo = acc.merchantName;
            };
            self.setStateonSelectMerchant = function(acc) {
                self.addrefval = false;
                self.ngifObj.addRefNoInput = false;
                self.ngifObj.addRefNoDiv = false;
                self.payToRemove = false;
                self.ngifObj.addRefNoInput = (acc.additionalRefNum == "N" || acc.additionalRefNum == "") ? false : true;
                self.payToQuery = '';
                self.transFromTOErr = false;
                self.transFromErr = false;
                if (self.payFromSelected && self.ngifObj.addRefNoInput == false) {
                    self.currentState = "inputAmount";
                    self.amountTo = false;
                    self.ngifObj.merDiv = false;
                    self.ngifObj.sourceAccListDiv = false;
                    self.ngifObj.amountTabDiv = true;
                    self.ngifObj.payToInput = false;
                } else if (self.ngifObj.addRefNoInput) {
                    self.ngifObj.payToInput = false;
                } else {
                    self.currentState = 'payFrom';
                    self.ngifObj.merDiv = false;
                    self.ngifObj.sourceAccListDiv = true;
                    self.ngifObj.payToInput = false;
                }
            };
			/* On select source account for bill payment*/
            self.onSelectSourceAccount = function(acc) {
                self.removeErrorMsg();
                self.transFromErr = false;
                self.transFromTOErr = false;
                self.addrefval = false;
                self.ngifObj.merDiv = false;
                self.ngifObj.sourceAccListDiv = false;
                self.ngifObj.paymentTypeDiv = false;
                self.ngifObj.amountTabDiv = true;
                self.currentState = 'inputAmount';
                self.amountTo = false;
                self.payFromSelected = true;
                self.ngifObj.payFromInput = false;
                self.payFromRemove = false;
                self.maxAmount = parseFloat(acc.availableBalance);
                self.billPaymentObj.preferredName = acc.preferredName;
                self.payFromQuery = '';
                self.billPaymentObj.sourceAcctType = acc.accountType;
                self.billPaymentObj.sourceAcctNum = acc.accountNumber;
                self.billPaymentObj.sourceRMNum = rmNumber;
                self.billPaymentObj.sourceCurrCode = acc.currencyCode;
                $window.sessionStorage.removeItem("selAccCurrencyName");
                $window.sessionStorage.setItem("selAccCurrencyName", self.currencyCodeJSON[acc.currencyCode.substring(1)]);
            };
			/* Reset the form after clear or bill payment*/
            self.resetToStarting = function() {
                self.removeErrorMsg();
                self.currentState = 'payTo';
                self.amountTo = true;
                self.payFromSelected = false;
                self.payToRemove = true;
                self.payFromRemove = true;
                self.enteredAmount = "";
                self.payToQuery = "";
                self.payFromQuery = "";
                self.maxAmount = null;
                resetVisibilityOfComponents();
                resetBillPaymentObject();
            };
            function resetVisibilityOfComponents() {
                self.ngifObj = {
                    "merDiv": true,
                    "parentMerList": true,
                    "sourceAccListDiv": false,
                    "paymentTypeDiv": false,
                    "refNoDiv": false,
                    "addRefNoDiv": false,
                    "payFromInput": true,
                    "payToInput": true,
                    "addRefNoInput": false,
                    "amountTabDiv": false
                };
            };
            function resetBillPaymentObject() {
                self.billPaymentObj = {
                    "noteToPay": '',
                    "payTo": '',
                    "preferredName": '',
                    "tranID": "IMPB",
                    "termID": "",
                    "sourceAcctType": null, 
                    "sourceCurrCode": null,
                    "sourceAcctNum": null,
                    "amount": '',
                    "sourceRMNum": rmNumber,
                    "sourceTraceNum": "9999999",
                    "destinationAcctType": null, 
                    "destAccType": null,
                    "destinationCurrCode": null,
                    "destinationAcctNum": null,
                    "destinationTraceNum": "9999999",
                    "additionalRefNum": '',
                    "referenceNum": null,
                    "mercCode": null, 
                    "prodCode": null, 
                    "merchantFINum": null 
                };
            };
            self.removeErrorMsg = function() {
                self.transFromErr = false;
                self.transFromTOErr = false;
                self.transamt = false;
                self.greatthanzero = false;
                self.lessthanzero = false;
                self.addrefval = false;
            };
			/* Object to hide and show the Merchant account Details*/
            self.showPayToMerchants = function() {
                self.ngifObj.merDiv = true;
                self.ngifObj.sourceAccListDiv = false;
                self.ngifObj.paymentTypeDiv = false;
                self.ngifObj.amountTabDiv = false;
                self.ngifObj.addRefNoDiv = false;
                if (self.billPaymentObj.additionalRefNum && self.currentState !== 'payTo') {
                    self.ngifObj.addRefNoInput = true;
                    self.ngifObj.addRefNoDiv = false;
                }
                if (self.billPaymentObj.sourceAcctNum) {
                    self.ngifObj.payFromInput = false;
                }
                self.currentState = 'payTo';
            };
			/* Object to hide and show the source account Details*/
            self.showPayFromAccouts = function() {
                if (self.billPaymentObj.additionalRefNum && self.billPaymentObj.additionalRefNum.length > 0) {
                    self.ngifObj.addRefNoInput = false;
                }
                self.ngifObj.merDiv = false;
                self.ngifObj.sourceAccListDiv = true;
                self.ngifObj.paymentTypeDiv = false;
                self.ngifObj.amountTabDiv = false;
                self.ngifObj.addRefNoDiv = true;
                self.currentState = 'payFrom';
                if (self.billPaymentObj.referenceNum) {
                    self.ngifObj.payToInput = false;
                }

            };
			/* Object to hide and show pay on Details*/
            self.showPaymentType = function() {
                self.ngifObj.merDiv = false;
                self.ngifObj.sourceAccListDiv = false;
                self.ngifObj.paymentTypeDiv = true;
                self.ngifObj.amountTabDiv = false;
                self.currentState = 'payOn';
                if (self.billPaymentObj.referenceNum && self.billPaymentObj.sourceAcctNum) {
                    self.ngifObj.payToInput = false;
                    self.ngifObj.payFromInput = false;
                }
            };
            self.inputAmountBgc = function() {
                self.ngifObj.merDiv = false;
                self.ngifObj.sourceAccListDiv = false;
                self.ngifObj.paymentTypeDiv = false;
                self.ngifObj.amountTabDiv = true;
                self.currentState = 'inputAmount';
                if (self.billPaymentObj.additionalRefNum && self.billPaymentObj.additionalRefNum.length > 0) {
                    self.ngifObj.addRefNoDiv = true;
                    self.ngifObj.addRefNoInput = false;
                }
                if (self.billPaymentObj.referenceNum) {
                    self.ngifObj.payToInput = false;
                }
                if (self.billPaymentObj.sourceAcctNum) {
                    self.ngifObj.payFromInput = false;
                }
            };
			/* Clear selected merchant account*/
            self.removeSelectedMar = function() {
                self.payToRemove = true;
                self.ngifObj.payToInput = true;
                self.ngifObj.addRefNoInput = false;
                self.billPaymentObj.additionalRefNum = "";
                self.billPaymentObj.destinationAcctNum = "";
                self.billPaymentObj.destinationAcctType = "";
                self.billPaymentObj.referenceNum = null;
            };
			/*Clear selected source account*/
            self.removeSelectedAcc = function() {
                self.payFromRemove = true;
                self.ngifObj.payFromInput = true;
                self.billPaymentObj.preferredName = "";
                self.billPaymentObj.sourceAcctType = "";
                self.billPaymentObj.sourceAcctNum = null;
            };
			/* Validate selection on submit and make bill patyment api call */
            self.onSubmitValidation = function() {
                formPayBillRequest();
                if (!self.billPaymentObj.referenceNum) {
                    self.transFromTOErr = true;
                    self.showPayToMerchants();
                    PayBillsService.openModal(validation);
                } else if (self.ngifObj.addRefNoInput === true && self.billPaymentObj.additionalRefNum.length <= 0) {
                    self.addrefval = true;
                    self.showPayToMerchants();
                    PayBillsService.openModal(validation);
                } else if (!self.billPaymentObj.sourceAcctNum) {
                    self.transFromErr = true;
                    self.showPayFromAccouts();
                    PayBillsService.openModal(validation);
                } else if (self.billPaymentObj.amount || self.billPaymentObj.amount == "") {
                    self.transamt = true;
                    self.inputAmountBgc();
                    PayBillsService.openModal(validation);
                } else if (parseFloat(self.billPaymentObj.amount) <= 0) {
                    self.lessthanzero = true;
                    self.inputAmountBgc();
                } else if (parseFloat(self.billPaymentObj.amount) > parseFloat(self.maxAmount)) {
                    self.greatthanzero = true;
                    self.inputAmountBgc();
                } else {
                    PayBillsService.openModal(ReviewModal);
                }
            };
			/* form request for  paybill api*/
            function formPayBillRequest() {
                self.billPaymentObj.amount = self.enteredAmount;
                PayBillsService.payBillReqObj = {
                    "tranID": "IMBP",
                    "termID": "",
                    "sourceAcctType": self.billPaymentObj.sourceAcctType,
                    "sourceCurrCode": self.billPaymentObj.sourceCurrCode,
                    "sourceAcctNum": self.billPaymentObj.sourceAcctNum,
                    "amount": self.billPaymentObj.amount,
                    "sourceRMNum": rmNumber,
                    "sourceTraceNum": "9999999",
                    "destinationAcctType": self.billPaymentObj.destAccType,
                    "destinationCurrCode": self.billPaymentObj.destinationCurrCode,
                    "destinationAcctNum": self.billPaymentObj.destinationAcctNum,
                    "destinationTraceNum": "9999999",
                    "referenceNum": self.billPaymentObj.referenceNum,
                    "mercCode": self.billPaymentObj.mercCode,
                    "prodCode": self.billPaymentObj.prodCode,
                    "merchantFINum": self.billPaymentObj.merchantFINum,
                    "additionalRefNum": self.billPaymentObj.additionalRefNum
                };
                PayBillsService.addRef_Notes = {
                    "noteToPay": self.billPaymentObj.noteToPay,
                    "payTo": self.billPaymentObj.payTo,
                    "preferredName": self.billPaymentObj.preferredName
                };
            };
            self.removeAddrefErrorMsg = function() {
                self.addrefval = false;
            };
            self.searchMearchants = function(obj) {
                return (angular.lowercase(obj.merchantName).indexOf(angular.lowercase(self.payToQuery) || '') !== -1 ||
                    angular.lowercase(obj.referenceNumber).indexOf(angular.lowercase(self.payToQuery) || '') !== -1);
            };
            self.searchAccounts = function(obj) {
                return (angular.lowercase(obj.preferredName).indexOf(angular.lowercase(self.payFromQuery) || '') !== -1 ||
                    angular.lowercase(obj.accountNumber).indexOf(angular.lowercase(self.payFromQuery) || '') !== -1);
            };
            self.conPayLow = function(req) {
                return angular.lowercase(req);
            };
            self.conMarAccLow = function(req) {
                return angular.lowercase(req);
            };
           /* self.searchText = function(keyEve) {
                if (keyEve.which == 13 && keyEve.target.value) {
                    if (document.getElementsByClassName("fre-mer-pad") && document.getElementsByClassName("fre-mer-pad")[0]) {
                        keyEve.target.blur();
                        var ele = document.getElementsByClassName("fre-mer-pad")[0];
                        ele.focus();
                        window.angular.element(ele).select()

                        if (document.selection) {
                            var range = document.body.createTextRange();
                            range.moveToElementText(ele);
                            range.select();
                        } else if (window.getSelection) {
                            var range = document.createRange();
                            range.selectNode(ele);
                            window.getSelection().addRange(range);

                        } else {}
                    }
                }
            };*/
        } else {
            self.serverErrorMsg = lpWidget.model.getPreference("serverErrMsg");
            self.showMainContentDiv = false;
            self.showRmDownDiv = true;
			self.loading = false;
        }
    };
    exports.ModalInstanceController = function($modalInstance, $window, PayBillsService, $filter, $rootScope, lpWidget, conversionCodes) {
        var self = this;
		var ServiceFailed = lpWidget.getResolvedPreference('ServiceFailed');
		var login_success = lpWidget.getResolvedPreference('loginsuccess');
		var otpRegistration = lpWidget.getResolvedPreference('otpregistration');
		var otpRegistrationViaApp = lpWidget.getResolvedPreference('otpregistrationviaapp');
        self.enteredOTP = null;
        self.returnErrorMessage = PayBillsService.returnErrorMessage;
        self.otpReadonly = true;
        self.addRefFlag = true;
        self.notesFlag = true;
        self.payOnDate = new Date();
        self.otpErrorMsgDiv = false;
        self.otpPinLenght = false;
        self.disabled = true;
		self.showNewMobReg = PayBillsService.showNewMobReg;
        self.toolTip = PayBillsService.toolTip;
        self.dateConfirmObj = PayBillsService.dateConfirmObj;
        self.payBillObj = PayBillsService.payBillReqObj;
        self.payBillObj.noteToPay = PayBillsService.addRef_Notes.noteToPay;
        self.payBillObj.payTo = PayBillsService.addRef_Notes.payTo;
        self.payBillObj.preferredName = PayBillsService.addRef_Notes.preferredName;
        self.mobileNum = $window.sessionStorage.getItem('mobileNum');
		if(self.mobileNum){
			self.maskedMobileNum = self.mobileNum.substr(0, 3)+' '+self.mobileNum.substr(3, 3)+' xxx x'+self.mobileNum.substr(-3);
		}
        var rmNumber = $window.sessionStorage.getItem('rmNumber');
        var userName = $window.sessionStorage.getItem('userName');
        self.selAccCurrencyName = $window.sessionStorage.getItem('selAccCurrencyName');
		
		var keyMatch = function (array, str) {
			var AccountClosed = lpWidget.getResolvedPreference('AccountClosed');
			for (var i = 0; i < array.length; i++) {
				if (str.includes(array[i])) {
					TransferMoneyService.openModal(AccountClosed);			
					return value;				
				}
			}
			return false;
		};
        self.closeokModal = function() {
            $modalInstance.dismiss('cancel');
        };
		self.newMobileReg = function() {
			$window.location.href = otpRegistration;
        };
		self.sendOtpBpiMob = function() {
			$window.location.href = otpRegistrationViaApp;
        };
		self.gotoMyAccPage = function() {
            $modalInstance.dismiss('cancel');
			$window.location.href = login_success;//ACCOUNT_DETAILS;
        };
        self.clearOtpErrorMsg = function() {
            self.otpErrorMsgDiv = false;
            self.otpPinLenght = false;
        };
		
		/* Display/hide OTP screen before payment */
        self.submitDetailsForBillPayment = function() {
			var OTPModalForLD = lpWidget.getResolvedPreference('OTPModalForLD');
			var OTPModalWithOutLD = lpWidget.getResolvedPreference('OTPModalWithOutLD');
			var OtpSuspendedModal = lpWidget.getResolvedPreference('OtpSuspendedModal');
            self.disabled = false;
            $modalInstance.dismiss('cancel');
            if ($window.sessionStorage.getItem("otpStatus") === "2") {
                PayBillsService.openModal(OTPModalForLD);
            } else if ($window.sessionStorage.getItem("otpStatus") === "1") {
				PayBillsService.showNewMobReg = false;
                PayBillsService.openModal(OTPModalWithOutLD);
            } else {
                PayBillsService.openModal(OTPModalWithOutLD);
            }
        };
		/*API call for OTP authentication */
        self.submitOTPPinForValidation = function() {
			var OtpSuspendedModal = lpWidget.getResolvedPreference('OtpSuspendedModal');
			
            var enteredOtpPin = self.otpDig1 + self.otpDig2 + self.otpDig3 + self.otpDig4 + self.otpDig5 + self.otpDig6;
            if (enteredOtpPin && enteredOtpPin.length === 6) {
                var request = {
                    "rmNumber": rmNumber,
                    "smsRecipient": self.mobileNum,
                    "smsOtp": enteredOtpPin,
                    "username": userName
                };
                PayBillsService.submitOTP(request).then(function(response) {
                        if (response.data.code === "0") {
                            $modalInstance.dismiss('cancel');
                            self.makeBillPaymentApiCall();
                        } else if (response.data.code === "22033") {
							$modalInstance.dismiss('cancel');
                            PayBillsService.openModal(OtpSuspendedModal);
							$window.sessionStorage.setItem("otpStatus", "3");
                        } else {
                            self.otpErrorMsgDiv = true;
                            clearEntereOtp();
                        }
                    },
                    function(response) {
                        if (conversionCodes.errorStatus(response)) {
                            PayBillsService.returnErrorMessage = response.status;
                            PayBillsService.openModal(ServiceFailed);
                        }
                    });
            } else {
                self.otpPinLenght = true;
                clearEntereOtp();
            }

        };
        /* Clear entered OTP */
        function clearEntereOtp() {
            self.otpDig1 = "";
            self.otpDig2 = "";
            self.otpDig3 = "";
            self.otpDig4 = "";
            self.otpDig5 = "";
            self.otpDig6 = "";
        }
		/*API call for OTP authentication */
        self.submitOTPPinForAuthMobileOTP = function() {
            var enteredOtpPin = self.otpDig1 + self.otpDig2 + self.otpDig3 + self.otpDig4 + self.otpDig5 + self.otpDig6;
			var OtpSuspendedModal = lpWidget.getResolvedPreference('OtpSuspendedModal');
			
            if (enteredOtpPin && enteredOtpPin.length === 6) {
                var request = {
                    "username": userName,
                    "rmNumber": rmNumber,
                    "otp": enteredOtpPin
                };
                PayBillsService.submitAuthMobileOTPVal(request).then(function(response) {
                        if (response.data.code === "0") {
                            $modalInstance.dismiss('cancel');
                            self.makeBillPaymentApiCall();
                        } else if (response.data.code === "22033") {
                            $modalInstance.dismiss('cancel');
                            PayBillsService.openModal(OtpSuspendedModal);
							$window.sessionStorage.setItem("otpStatus", "3");
                        } else {
                            self.otpErrorMsgDiv = true;
                            clearEntereOtp();
                        }
                    },
                    function(response) {
                        if (conversionCodes.errorStatus(response)) {
                            PayBillsService.returnErrorMessage = response.status;
                            PayBillsService.openModal(ServiceFailed);
                        }
                    });
            } else {
                self.otpPinLenght = true;
                clearEntereOtp();
            }
        };
		/* API call for send OTP via sms */
        self.sendOTPPinViaSms = function() {
            self.otpReadonly = false;
			var ResponseError = lpWidget.getResolvedPreference('ResponseError');
            
			if(!$window.sessionStorage.getItem("otpStatus") || $window.sessionStorage.getItem("otpStatus") === "" || $window.sessionStorage.getItem("otpStatus") === "0"){
				var firstName = $window.sessionStorage.getItem('firstName');
				var lastName = $window.sessionStorage.getItem('lastName');
				var trxCfm = PayBillsService.getConfNum(rmNumber);
				var request = {"rmNumber":rmNumber,"username":userName,"mobileNumber":self.mobileNum,"firstName":firstName,"lastName":lastName,"confirmationNumber":trxCfm.confirmationNumber}; 
				PayBillsService.doForceRegistration(request).then(function(response) {
						/* Success */
					},
					function(response) {
						if (conversionCodes.errorStatus(response)) {
							PayBillsService.returnErrorMessage = response.status;
							PayBillsService.openModal(ServiceFailed);
						}
					});
			} else{
				var request = {
					"rmNumber": rmNumber,
					"smsRecipient": self.mobileNum,
					"smsBody": "test",
					"username": userName
				};
				PayBillsService.sendSMSforOTP(request).then(function(response) {
						/* if(response.data.code === "0"){ */
						if (response.data.smsOtp && response.data.smsOtp.trim()) {
							/* Success */
						} else {
							PayBillsService.returnErrorMessage = response.data.message;
							PayBillsService.openModal(ResponseError);
						}
					},
					function(response) {
						if (conversionCodes.errorStatus(response)) {
							PayBillsService.returnErrorMessage = response.status;
							PayBillsService.openModal(ServiceFailed);
						}
					});
			}
        };
		self.getOtpStatus = function() {
			if($window.sessionStorage.getItem("otpStatus") && $window.sessionStorage.getItem("otpStatus") !== "") {
				var request = {"userName":userName};
				PayBillsService.getOtpStatus(request).then(function(response) {
						if(response.data.result){
							self.submitDetailsForBillPayment();
						} else {
							$modalInstance.dismiss('cancel');
							var OtpSuspendedModal = lpWidget.getResolvedPreference('OtpSuspendedModal');
							PayBillsService.openModal(OtpSuspendedModal);
						}
					},
					function(response) {
						if (conversionCodes.errorStatus(response)) {
							$modalInstance.dismiss('cancel');
							PayBillsService.openModal(ServiceFailed);
						}
					});
			} else {
				self.submitDetailsForBillPayment();
			}
        };
        self.doTrxLogAndEmailAfterSuccess = function() {
            $modalInstance.dismiss('cancel');
            self.makeTransactionLogInsert('Success');
            self.sendEmailNotification();
        };
        self.doTrxLogAfterFailure = function() {
            $modalInstance.dismiss('cancel');
            self.makeTransactionLogInsert('Failed');
        };
		/*API call for Bill Payment */
        self.makeBillPaymentApiCall = function() {
            //Make funds transfer call and in the call back display the OTP screen/ success screen
			var TransactionSuccess = lpWidget.getResolvedPreference('TransactionSuccess');
			var DorSpinTransactionFail = lpWidget.getResolvedPreference('DorSpinTransactionFail');
			var ErrorCode = lpWidget.getResolvedPreference('ErrorCode');
			var TransactionFail = lpWidget.getResolvedPreference('TransactionFail');
			var ServiceFailed = lpWidget.getResolvedPreference('ServiceFailed');
            PayBillsService.makeBillPayment().then(function(response) {
                    $rootScope.$broadcast('resettags');
                    PayBillsService.dateConfirmObj = PayBillsService.getConfNum(rmNumber);
                    if (response.data.returnCode == 0) {
                        PayBillsService.openModal(TransactionSuccess);
                    } else if (response.data.returnCode == 1) {
                        //self.responseMsg = response.data.returnMessage;
                        PayBillsService.returnErrorMessage = response.data.returnMessage;
						 if(keyMatch(conversionCodes.errorCode, PayBillsService.returnErrorMessage)){
							 //succes Case
							 }else if((PayBillsService.returnErrorMessage).includes("ST0787")){
								PayBillsService.openModal(DorSpinTransactionFail);
							}else if((PayBillsService.returnErrorMessage).includes("IM7887")){
								PayBillsService.openModal(DorSpinTransactionFail);
							}else {
								PayBillsService.returnErrorMessage = response.data.returnMessage;
								PayBillsService.openModal(ErrorCode);
                        }
                    } else {
                        PayBillsService.openModal(TransactionFail);
                    }
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
                        PayBillsService.returnErrorMessage = response.status;
                        PayBillsService.openModal(ServiceFailed);
                    }
                });
        };
		/* API call for EmailNotification */
        self.sendEmailNotification = function() {
            //Request to be made dynamic
            var emailId = $window.sessionStorage.getItem('emailId');
            var firstName = $window.sessionStorage.getItem('firstName');
            var lastName = $window.sessionStorage.getItem('lastName');
            var transDate = $filter('date')(self.dateConfirmObj.transDate, "MMMM dd, yyyy: h:mm:ss a") + " (GMT +8)";
            var amountFormat = $filter('currency')(self.payBillObj.amount, "PHP ");
            var confNo = self.dateConfirmObj.confirmationNumber;
            var payTo = self.payBillObj.payTo;
            var refNo = self.payBillObj.referenceNum;
            var addnlRefNo = self.payBillObj.additionalRefNum;
            var noteToPay = self.payBillObj.noteToPay;
            var srcAccNo = self.payBillObj.sourceAcctNum.toString().slice(-5);
            var srcThreeDigits = self.payBillObj.sourceAcctNum.toString().slice(-3);
            var srcNo = srcAccNo.slice(1, 2);
            var tranSrcAccccNo = "XXXX-XX" + srcNo + "-" + srcThreeDigits + " (" + self.payBillObj.preferredName + ")";
            var request = {
                "msg": {
                    "from": "",
                    "to": "",
                    "subject": "Bills Payment Confirmation to  " + payTo,
                    "text": "Your Transaction got Successful",
                    "html": " <html><head></head>" +
                        "<body><div class='row'><h4>Dear " + firstName + " " + lastName + ",</h4><p>This is to confirm your Bills Payment with the following details:</p>" +
                        "<div class='table table-responsive'><table style='border:2px solid #c7c7c7;border-radius:5px;width:40%;margin:0 auto;'>" +
                        "<tr><td style='text-align:left;padding:4px;width:24%; text-align:center;'colspan='2'><span style='font-size:25px;'> Payment Transaction Confirmation</span></td></tr>" +
						"<tr><td style='text-align:left;padding-left:20px;padding-right:24px;width:24%; text-align:center;'colspan='2'><div style='border-bottom:1px solid #c7c7c7'></div></td></tr>"+ 
						"<tr><td style='text-align:left;padding-left:20px;width:24%;'>Paid to</td><td style='text-align:left;padding:4px;width:24%;'>" + payTo + "</td></tr>" +
						"<tr><td style='text-align:left;padding-left:20px;width:24%;'>Paid from</td><td style='text-align:left;padding:4px;width:24%;'>" + tranSrcAccccNo + "</td></tr>" +
					    "<tr><td style='text-align:left;padding-left:20px;width:24%;'>Reference Number</td><td style='text-align:left;padding:4px;width:24%;'>" + refNo + "</td></tr>" +
						"<tr><td style='text-align:left;padding-left:20px;width:24%;'>Addt'| Reference Number</td><td style='text-align:left;padding:4px;width:24%;'>" + addnlRefNo + "</td></tr>" +
					    "<tr><td style='text-align:left;padding-left:20px;width:24%;'>Amount</td><td style='text-align:left;padding:4px;width:24%;'> " + amountFormat + "</td></tr>"+
					    "<tr><td style='padding-bottom:8px;'></td></tr>"+
					    "<tr><td style='text-align:left;padding-left:20px;width:24%;'>Notes</td><td style='text-align:left;padding:4px;width:24%;'>" + noteToPay + "</td></tr>" +
					    "<tr><td style='text-align:left;padding-left:20px;width:24%;'>Transaction Date and Time</td><td style='text-align:left;padding:4px;width:24%;'>" + transDate + "</td> </tr>" +
                        "<tr><td style='text-align:left;padding-left:20px;width:24%;'>Confirmation Number</td><td style='text-align:left;padding:4px;width:24%;'>" + confNo + "</td></tr>" +                       
						"<tr><td style='padding-bottom:15px;'></td></tr>"+
					    "</table></div><br><br><div class='row col-xs-12 col-sm-12 col-md-12 col-lg-12'>BPI Express Online guarantees that your payment will be forwarded to your merchant one banking day from today." +
                        "<br>Depending on the merchant's updating policy,your payment will be reflected on the merchant's record within 1-3<br>" +
                        "banking days from your transaction  date.<br><br>Should you have comments,questions or complaints regarding this particular payment transaction,please e-mail us<br>" +
                        " at <a href='#'>expressonline@bpi.com.ph.</a> We shall take care of coordinating with the merchant on your behalf.<br><br>Thank you for using BPI Express Online.</div></div></body></html>"
          

					}
            };
            PayBillsService.sendEmailNotification(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    //This call is getting failure
                });
        };
		/* API call for Transaction Log insert*/
        self.makeTransactionLogInsert = function(status) {
			var transAmount = self.selAccCurrencyName+" "+self.payBillObj.amount;
            var request = {
                "userName": userName, //To be changes as First name and last name
                "rmNumber": rmNumber,
                "transactionType": "BillPay",
                "sourceAccountNumber": self.payBillObj.sourceAcctNum,
                "beneficiaryAccountNumber": self.payBillObj.destinationAcctNum,
                "merchantReferenceNumber": self.payBillObj.destinationAcctNum,
                "settlementAccountNumber": self.payBillObj.sourceAcctNum,
                "transactionAmount": transAmount,
                "serviceCharge": "",
				"merchantName":self.payBillObj.payTo,
                "confirmationNumber": self.dateConfirmObj.confirmationNumber,
				"amountCurrency":self.selAccCurrencyName,
                "status": status
            };
            PayBillsService.insertToTransactionLog(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
                        //This call is getting failure
                    }
                });

        };

    };


});