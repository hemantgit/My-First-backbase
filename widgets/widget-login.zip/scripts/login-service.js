/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : login-service.js
 *  Description: login details - login service 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.LoginService = function($http, $window, lpPortal, lpCoreUtils, lpWidget) {

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Login model
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        var self = this;
        var widget = lpWidget;
        var config = {
            loginUrl: "/portalserver/j_spring_security_check",
            logoutUrl: lpPortal.root + "/j_spring_security_logout?portalName=" + lpPortal.name,
            successPage: null
        };
        var loginStorageConfig = {
            userId: "launchpad.userId",
            userData: "launchpad.userData"
        };

        // Allow user to configure some attributes
        this.configure = function(_config) {
            lpCoreUtils.extend(config, _config);
        };

        /* UI validation*/
        this.validateUILogin = function(userId, password) {
            self.error = null;
            if (password === undefined || password === "") {
                self.error = widget.model.getPreference("emptyErr");
                return self.error;
            }
        };
        /* Login service */
        this.doLogin = function(userId, password, isRememberMe, callback, errCallback) {
            userId = userId.toUpperCase();
            var promise;
            var errorMsg = null;
            if (!this.validateUILogin(userId, password)) {
                promise = this.getLoginPromise(userId, password).success(function(response) {
                    if (response.accountStatus === "3") {
                        /* Account is disabled */
                        errorMsg = response.errorMessage;
                    } else {
                        if (response.statusCode === "01") {
                            /* Account is active */
                            $window.sessionStorage.setItem("lastLoggedIn", response.lastLoginDate);
                            $window.sessionStorage.setItem("userId", response.username);
							$window.sessionStorage.setItem("userName", response.userId);
							$window.sessionStorage.setItem("firstName", response.firstName);
							$window.sessionStorage.setItem("lastName", response.lastName);
							$window.sessionStorage.setItem("emailId", response.emailId);
                            $window.sessionStorage.setItem("mobileNum", response.mobileNumber);
                            $window.sessionStorage.setItem("currentSessionStatus", "show");
                            $window.sessionStorage.setItem("otpFlag", response.otpFlag);
							$window.sessionStorage.setItem("otpStatus", response.otpStatus);
							$window.sessionStorage.setItem("deviceName", response.deviceName);
							$window.sessionStorage.setItem("deviceId", response.deviceId);
							var trimedRMNUMBER = response.rmNo;
                            self.checkTrimmedRmNumber(trimedRMNUMBER);

                        } else if (response.statusCode === "02" || response.statusCode === "03") {
                            errorMsg = response.errorMessage;

                        } else {
                            errorMsg = widget.model.getPreference("errMsg");
                        }
                    }

                    if (!errorMsg) {
                        callback(response);
                    } else {
                        errCallback(errorMsg);
                    }
                }).error(function() {
                    errorMsg = widget.model.getPreference("errMsg");
                    errCallback(errorMsg);
                });
            }
            return promise;
        };
        self.checkTrimmedRmNumber = function(trimedRMNUMBER){
            if (trimedRMNUMBER) {
                /* Trimmed Account Number*/
                $window.sessionStorage.setItem("rmNumber", trimedRMNUMBER.trim());
            }
        };

        this.getLoginPromise = function(userId, password) {
            var data = {
                j_username: userId,
                j_password: password,
                portal_name: lpPortal.name,
                page_name: lpPortal.page.name
            };
            return $http({
                method: "POST",
                url: config.loginUrl,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                transformRequest: function(obj) {
                    var str = [];
                    for (var p in obj)

                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));

                    return str.join("&");

                },
                data: data
            });

        };

        /*  Logout  */
        this.doLogout = function() {
            $window.sessionStorage.clear();
            $window.location.href = config.logoutUrl;
        };

        /* Retrieve stored user data */
        this.getStoredData = function() {
            return $window.sessionStorage.getItem(loginStorageConfig.userData);
        };
    };
});