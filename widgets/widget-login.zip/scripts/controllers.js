/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controllers.js
 *  Description: login details - controllers 
 *  ----------------------------------------------------------------
 */

define(function(require, exports) {
        "use strict";

    // @ngInject
        exports.LoginController = function(i18nUtils, lpCoreUtils, lpWidget, $window, LoginService, $location,lpPortal) {
                var widget = lpWidget;
                var utils = lpCoreUtils;
                var stored = LoginService.getStoredData();
                var self = this;
				var ACCOUNT_DETAILS = lpPortal.root+"/"+ lpPortal.name +"/" + widget.model.getPreference("redirectTo");
                i18nUtils.loadMessages(widget).success(function(bundle) {
                        self.messages = bundle.messages;
                });

                self.user = {};
                self.successMsg = $window.sessionStorage.getItem("errorMsg");
                $window.sessionStorage.removeItem("errorMsg");
                if (!utils.isNull(stored)) {
                        utils.extend(self.user, {
                                id: stored,
                                remember: false
                        });
                }
        /*
        Login submit
        */
                self.allowSubmit = function() {
                        return self.user.id;
                };
        /*
        Clear UI fields and error message
        */
                self.clear = function() {
                        self.user.id = "";
                        self.error = null;
                        $("[name='j_username']").focus();
                };
        /*
        Clear UI fields
        */
                self.clearUsernamePwd = function() {
                        self.user.id = "";
                        self.user.password = "";
                        $("[name='j_username']").focus();

                };
        /*
        Login functionallity
        */
                self.doLogin = function() {
                        self.successMsg = null;
                        $window.sessionStorage.removeItem("errorMsg");
						 //Add Spinner
						angular.element(".accountsloader").removeClass("hidden");
						angular.element(".loginPannel").addClass("addSpinner");
						
                        LoginService.doLogin(self.user.id, self.user.password, self.user.remember, function() {
                                self.error = null;
                                $window.sessionStorage.removeItem("errorMsg");
                                window.location.href = ACCOUNT_DETAILS;
                        }, function(errorMsg) {
							//Remove Spinner 
							angular.element(".accountsloader").addClass("hidden");
							angular.element(".loginPannel").removeClass("addSpinner");
                                self.error = errorMsg;
                                self.clearUsernamePwd();
                                $window.sessionStorage.clear();
                        });
                        if (LoginService.error) {
							//Remove Spinner 
							angular.element(".accountsloader").addClass("hidden");
							angular.element(".loginPannel").removeClass("addSpinner");
                                self.error = LoginService.error;
                                self.clearUsernamePwd();
                        }


                };
        /*
        Retrieve Query parameters
        */
                self.getQueryStringParams = function(name) {
                        var url = $location.absUrl();
                        name = name.replace(/[\[\]]/g, "\\$&");
                        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                                results = regex.exec(url);
                        if (!results) 
						return null;
                        if (!results[2]) 
						return "";
                        return decodeURIComponent(results[2].replace(/\+/g, " "));
                };
        /*
        Display session timeout error messages on page load
        */
                var isLoginError = self.getQueryStringParams("login_error");
                if (isLoginError === "sessionTimeOut") {
                        self.error = widget.model.getPreference("sessionTimeOutMsg");
                } else if (isLoginError === "alreadyLoggedIn") {
                        self.error = widget.model.getPreference("alreadyLoggedIn");

                }

                widget.addEventListener("preferencesSaved", function() {
                        widget.refreshHTML();
                });
                self.LoginUrl = utils.resolvePortalPlaceholders(widget.model.getPreference("LoginUrl")) || "";
        };
});