/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : directives.js
 *  Description: login details - directives 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
        "use strict";

    // @ngInject
        exports.autofill = function() {
                return {
                        require: "?ngModel",
                        restrict: "A",
                        link: function (scope, element, attrs, ngModel) {
                                scope.$on("autofill:update", function() {
                                        ngModel.$setViewValue(element.val());
                                });
                        }
                };
        };
});