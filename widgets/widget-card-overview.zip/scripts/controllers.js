/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controllers.js
 *  Description: card Overview - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function($scope, $http, lpWidget, lpPortal, $window, conversionCodes,lpCoreBus) {
        var self = this;

        var widget = lpWidget;
        self.errorMsg = null;
        self.display = false;
        self.orgnoOneCodeJSON = conversionCodes.codeJson;
        self.orgnoEightCodeJSON = conversionCodes.orgEightCode;
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'creditCardOverview'	
        });
        /*
         * Get values from Session
         */

        var creditCardtTransactionReq = JSON.parse($window.sessionStorage.getItem("ccTransacitonRequest"));
        self.cardOverview = creditCardtTransactionReq;
        if (self.cardOverview.Cards && self.cardOverview.Cards.length == 0) {
            self.errorMsg = widget.model.getPreference("noRecordsFound");
        }
		//Navigation urls
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var accountDetailsUrl = protocolHost+lpWidget.getResolvedPreference('loginsuccess');
		var cardDetailsUrl = protocolHost+lpWidget.getResolvedPreference('cardTransactionDetails');
        self.bank = $window.sessionStorage.getItem("bank");

        /*
         *  Display Card details
         */
        self.cardDetails = function(co, coCardType, coCardHolderName, coCreditLimit, ccCurrency) {
            $window.sessionStorage.removeItem("CardDetailsReq");
            var accountNumber = co.accountNumber.trim();
            var CardDetailsReq = {
                "coCardType": coCardType,
                "coOutstanding": co.accountOutstandingBalance,
                "coCardHolderName": coCardHolderName,
                "coCreditLimit": coCreditLimit,
                "ccCurrency": ccCurrency,
                "ccStatementBalance": co.statementBalance
            };
            $window.sessionStorage.setItem("CardDetailsReq", JSON.stringify(CardDetailsReq));
            var CardTransDetailsReq = {
                "accountNumber": accountNumber,
                "org": co.accountOrg,
                "type": co.accountType,
                "cardNumber": co.cardNumber
            };
            $window.sessionStorage.setItem("CardTransDetailsReq", JSON.stringify(CardTransDetailsReq));
            $window.location.href = cardDetailsUrl;

        };
         /*
         *  Add paranthesis for negative values
         */

        self.addBracket = function(negValue) {
            if (negValue) {
                var negativeVal = negValue.toString();
                if (negativeVal.charAt(0) === "-") {
                    var remMinus = negativeVal.slice(1);
                    var trimNeg = Number(remMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    var trimNegValue = "(" + trimNeg + ")";
                    return trimNegValue;
                } else {
                    var trimNonNeg = Number(negativeVal).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    return trimNonNeg;
                }
            }
        };
        /*
         *  Return card type for given org & type
         */
        self.getCardType = function(org, type) {
            while (org.length < 3) {
                org = "0" + org;
            }
            while (type.length < 3) {
                type = "0" + type;
            }
            if (org === "001") {
                return self.orgnoOneCodeJSON[type];
            } else if (org == "008") {
                return self.orgnoEightCodeJSON[type];
            } else {
                return "";
            }
        };
        /*
         * Navigate to Account details page
         */
        self.goToHomePage = function() {
            $window.location.href = accountDetailsUrl;
        };


    };

});