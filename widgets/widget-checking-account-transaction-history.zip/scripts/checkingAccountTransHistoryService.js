/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : casa-service.js
 *  Description: Account transaction history - services 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.CASAService = function($http,$window,lpWidget) {
			
		var self=this;
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var SAVINGS_AND_CHECKING_TRANSACTION_HISTORY = protocolHost+lpWidget.getResolvedPreference('checkingTransactionHistory');
		
        self.getTransactions = function(sncTransactionHistoryReq) {

            return $http({
			    url: SAVINGS_AND_CHECKING_TRANSACTION_HISTORY,
			    method: "POST",
			    data: sncTransactionHistoryReq,
				headers: {'URL':'SAVING_CHECKING_TRANS_HISTORY'}				
               // Static API for testing
                // url : "https://api.myjson.com/bins/ogdwv",
                // method: "GET",
            });
        };

    };

});