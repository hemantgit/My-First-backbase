/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : filters.js
 *  Description: Account transaction history - filters
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.OrderObjectBy = function() {
        return function(items, field, reverse) {

            var filtered = [];
            angular.forEach(items, function(item) {
                filtered.push(item);
            });
            filtered.sort(function(a, b) {
                var x = a[field].substring(4, 8) + a[field].substring(0, 2) + a[field].substring(2, 4);
                var y = b[field].substring(4, 8) + b[field].substring(0, 2) + b[field].substring(2, 4);
                return (x > y ? 1 : -1);
            });
            if (reverse)
                filtered.reverse();
            return filtered;
        };
    };
});