/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controllers.js
 *  Description: Account transaction history - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(CASAService, $http, lpCoreUtils, lpWidget, lpPortal, $window, conversionCodes,lpCoreBus) {
        var utils = lpCoreUtils;
        var widget = lpWidget;
        var self = this;
        self.ImgUrl = utils.resolvePortalPlaceholders(widget.model.getPreference("ImgUrl")) || "";
        self.ImgTh = utils.resolvePortalPlaceholders(widget.model.getPreference("ImgTh")) || "";
		//Getting Image from model
        self.downloadTransaction = utils.resolvePortalPlaceholders(widget.model.getPreference("downloadTrans")) || "";
        self.downloadElectronic = utils.resolvePortalPlaceholders(widget.model.getPreference("downloadElectronic")) || "";
		//Navigation Urls
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var loginSuccessUrl = protocolHost+lpWidget.getResolvedPreference('loginsuccess');
        self.errorMsg = null;
        self.downloadDisable = false;
        self.order_item = "date";
        /* Getting data form sessionStorage */
        var sncTransactionHistoryReq = JSON.parse($window.sessionStorage.getItem("sncTransacitonRequest"));
        self.snctran = sncTransactionHistoryReq;
        self.preferredName = $window.sessionStorage.getItem("sncPrefferedName");
        self.availableBalance = $window.sessionStorage.getItem("saving_checking_availableBalance");
        self.totalBalance = $window.sessionStorage.getItem("saving_checking_totalBalance");
        self.bank = $window.sessionStorage.getItem("bank");
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'savingsChecking'	
        });
        /* Currency And Institution code conversion */
        self.currencyCodeJSON = conversionCodes.currencyCode;
        self.institutionCodeJSON = conversionCodes.institutionCode;;

        /*
         *       Adding Load spinner
         */
        angular.element(".loader").removeClass("hidden").parents("tr").removeClass("hidden");

        /* To display data from real API */
        CASAService.getTransactions(sncTransactionHistoryReq).then(function(response) {
                angular.element(".loader").addClass("hidden").parents("tr").addClass("hidden");
                self.mydata = response.data;
                response.data.TransactionHistory.forEach(function(obj) {
                    var pattern = /(\d{2})(\d{2})(\d{4})/;
                    obj.date = new Date(obj.date.replace(pattern, "$1/$2/$3"));
                    if (obj.date != "Invalid Date") {
                        obj.date = obj.date.toString("MMM, dd,yyyy");
                    }
                });
                if (self.mydata.TransactionHistory && self.mydata.TransactionHistory.length == 0) {
                    self.errorMsg = widget.model.getPreference("noRecordsFound");
                    self.downloadDisable = true;
                }

            },
            function(response) {
                if (conversionCodes.errorStatus(response)) {
                    angular.element(".loader").addClass("hidden").parents("tr").addClass("hidden");
                    self.errorMsg = widget.model.getPreference("serverError");
                    self.downloadDisable = true;
                }
            });



        /* To Convert sanded date format */
        self.dateFilter = function(obj) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(obj);

            } else {
                if (obj && obj.slice(4, 11))
                    return obj.slice(4, 11);
                else
                    return "";
            }
        };
		/*Date filter for IE*/
        self.dateFilterForIE = function(obj) {
            if (obj && obj.slice(4, 11)) {
                var date = obj.slice(8, 10);
                if (Number(date) <= 9) {
                    return obj.slice(4, 7) + " 0" + obj.slice(8, 10);
                } else {
                    return obj.slice(4, 11);
                }
            } else {
                return "";
            }
        };


        self.toDate = function(obj) {
            return (new Date(obj.date));
        };
        self.getTransactionAmount = function(obj) {
            return Number(obj.transactionAmount);
        };
        self.searchTransaction = function() {
            var searchData = self.transactionSearch;
            return searchData.replace(/\,/g, "").replace(/\./g, "").replace(/\(/g, "-").replace(/\)/g, "");
        };
        /* To Reverse the Sorting order */
        self.casaSort = self.toDate;
        self.sortDsc = true;
        self.reversesort = function(casa) {
            self.sortDsc = !self.sortDsc;
            self.casaSort = casa;
        };

        /* To navigate to back to my accounts */

        self.goToHomePage = function() {
            $window.location.href = loginSuccessUrl;
        };
        /*
         *  Export CSV file
         */
        self.exportTableToCSV = function($table, filename) {

            var $rows = $table.find("tr:has(td),tr:has(th)"),

                tmpColDelim = String.fromCharCode(11),
                tmpRowDelim = String.fromCharCode(0),
                colDelim = "\",\"",
                rowDelim = "\"\r\n\"",
                csv = "\"" + $rows.map(function(i, row) {
                    var $row = $(row),
                        $cols = $row.find("td,th");

                    return $cols.map(function(j, col) {
                        var $col = $(col),
                            text = $col.text();
                        return text.replace(/"/g, "\"\"");
                    }).get().join(tmpColDelim);
                }).get().join(tmpRowDelim)
                .split(tmpRowDelim).join(rowDelim)
                .split(tmpColDelim).join(colDelim) + "\"",
                csvData = "data:application/csv;charset=utf-8," + encodeURIComponent(csv);
            if (window.navigator.msSaveBlob) {
                window.navigator.msSaveOrOpenBlob(new Blob([csv], {
                    type: "text/plain;charset=utf-8;"
                }), "csvname.csv");
            } else {
                $(this).attr({
                    "download": filename,
                    "href": csvData,
                    "target": "_blank"
                });
            }
        };
        $("#check-acc-trans-his-det-download").on("click", function() {

            self.exportTableToCSV.apply(this, [$("#projectSpreadsheet"), "TransactionHistory.csv"]);
        });
        $("#check-acc-trans-his-det-download2").on("click", function() {

            self.exportTableToCSV.apply(this, [$("#projectSpreadsheet"), "TransactionHistory.csv"]);
        });
        /*
         * Trim description if has spaces
         */
        self.trimDesc = function(desc) {
            if (desc) {
                var trimedDesc = desc.substr(desc.indexOf(" ") + 1);
                return trimedDesc;
            } else {
                return "";
            }

        };
        /*
         * Convert currency code to currency value
         */
        self.getCurrency = function(val) {
            var currencyCode;
            if (val) {
                currencyCode = val.substr(1, 2);
            }
            return currencyCode;
        };
        /*
         * Add paranthesis for negative values
         */
        self.addBracket = function(negValue) {
            if (negValue) {
                var negativeVal = negValue.toString();
                if (negativeVal.charAt(0) === "-") {
                    var remMinus = negativeVal.slice(1);
                    var trimNeg = Number(remMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    var trimNegValue = "(" + trimNeg + ")";
                    return trimNegValue;
                } else {
                    var trimNonNeg = Number(negativeVal).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    return trimNonNeg;
                }
            }
        };
        self.filteredCardDetails = [];

    };

});