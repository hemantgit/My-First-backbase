/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : prepaidControllers.js
 *  Description: Prepaid Card Transaction Details - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(InvestmentHistoryService, $http, lpCoreUtils, lpWidget, lpPortal, $window,lpCoreBus) {
        var utils = lpCoreUtils;
        var widget = lpWidget;
        var self = this;
		function getImage(value){
			return utils.resolvePortalPlaceholders(widget.model.getPreference(value)) || "";
		}
        self.ImgUrl = getImage("ImgUrl");
        self.ImgTh = getImage("ImgTh");
        self.downloadTrans = getImage("downloadTrans");
        self.downloadElectronic = getImage("downloadElectronic");
        self.noRecordFound = getImage("noRecordsFound");
		self.investmentMutualFund = getImage("investmentMutualFund");
		self.unitInvestmentFund = getImage("investmentUitf");
        self.errorMsg = null;
        self.downloadDisable = false;
        self.order_item = "date";
		var account="";
		//getting values from session
		var accountNumberDetails=$window.sessionStorage.getItem("accountNumberDetails");	
		self.portfolioPreferredName=$window.sessionStorage.getItem("portfolioPreferredName");	
		self.dateOpened=$window.sessionStorage.getItem("dateOpened");	
		self.investmentAccountType=$window.sessionStorage.getItem("accountType");	
		self.historyAccountName=$window.sessionStorage.getItem("historyAccountName");	
		self.historyAccountNumber=accountNumberDetails;
		self.noRecord=false;
		//Getting protocol and host values
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var accountDetailsUrl = protocolHost+lpWidget.getResolvedPreference('goToHome');
		var investmentHistoryDetailsUrl = protocolHost+widget.getResolvedPreference('investmentTransactionDetails');
		// Link urls
		self.glossary = widget.getResolvedPreference('glossary');		
		self.alfMutualFunds = widget.getResolvedPreference('alfMutualFunds');
		self.openLink = function(url){
			$window.open(url,"_blank");
		}
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'investmentHistory'	
        });
		//Displaying logo based on account type
		if(self.investmentAccountType==='ALFM' || self.investmentAccountType==='MF'){
			self.mutualFundLogo=true;
		}
		else if(self.investmentAccountType==='UITF'){
			self.unitInvestmentLogo=true;
		}
        /*
         *       Adding Load spinner
         */       
		self.loaderCollapse=true;
        /* To display data from real API */
		var investmentsTransactionHistoryPayload = JSON.parse($window.sessionStorage.getItem("investmentsTransactionHistoryPayload"));
        InvestmentHistoryService.getTransactions(investmentsTransactionHistoryPayload).then(function(response) {
                //angular.element(".loader").addClass("hidden").parents("tr").addClass("hidden");
				self.loaderCollapse=false;
				self.investmentLength=response.data.InvestmentsTransactionHistory;
				 if (self.investmentLength && self.investmentLength.length == 0) {
					self.noRecord=true;
                    self.noRecordFound = widget.model.getPreference("noRecordsFound");
                    self.display = true;
				 }
				 angular.forEach(response.data.InvestmentsTransactionHistory, function(investments, $index) {                
				//formatting the date fields
				//Replace date from APT with date string
				var pattern;
                if (investments.date != undefined && investments.date.length === 8) {
                pattern = /(\d{2})(\d{2})(\d{4})/;
                investments.date = new Date(investments.date.replace(pattern, "$1/$2/$3"));
                investments.date = investments.date.toString("mmm,dd,yyyy");
                }
            });	
		//Date filter for formatting
		self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 11))
                    return dateString.slice(4, 11);
                else
                    return "";
            }
        };
            self.transactionData = response.data;		
			var transactionAccount = [];
			self.investmentDetailsRequest={};
			transactionAccount.push(self.transactionData);
			self.investmentDetailsRequest.InvestmentsRequest = transactionAccount;
						
              //  self.transactionData = response.data;            
            },
            function(response) {
               if(CallBackErrorStatus(response)){
					// removing spinner
                    //angular.element(".loader").addClass("hidden").parents("tr").addClass("hidden");
					self.loaderCollapse=false;
                    self.errorMsg = widget.model.getPreference("serverError");
                    self.downloadDisable = true;
                }
            });     
        /* To navigate to back to my accounts */
     
		self.goToHomePage = function() {
			$window.location.href = accountDetailsUrl;
		};	
        //Navigation history details
		self.investmentHistoryDetails=function(investmentHistory){
			$window.sessionStorage.removeItem("investmentHistoryPayload");
			$window.sessionStorage.setItem("investmentHistoryPayload", JSON.stringify(investmentHistory)); 
			$window.sessionStorage.removeItem("investmentDateOPened");
			$window.sessionStorage.setItem("investmentDateOPened", self.dateOpened);  
			$window.sessionStorage.removeItem("investmentDetailsType");
			$window.sessionStorage.setItem("investmentDetailsType", self.investmentAccountType);
			$window.sessionStorage.removeItem("investmentDetailsName");
			$window.sessionStorage.setItem("investmentDetailsName", self.historyAccountName);
			$window.sessionStorage.removeItem("investmentPreferredName");
			$window.sessionStorage.setItem("investmentPreferredName", self.portfolioPreferredName);  
			$window.location.href = investmentHistoryDetailsUrl;
		}
		//Date formatting
		 self.toDate = function(obj) {
            return (new Date(obj.date));
        };
		//format the amount
		 self.getTransactionAmount = function(obj) {
            return Number(obj.amount);
        };
		//sorting
		self.sortingData=self.toDate;
                self.sortDescending = true;
                self.reverseSort = function(sortType) {
                       self.sortDescending = !self.sortDescending;
					   self.sortingData = sortType;
                };
		//search investment data
		self.searchTransaction = function() {
            var searchData = self.transactionSearch;
            return searchData.replace(/\,/g, "").replace(/\./g, "").replace(/\(/g, "-").replace(/\)/g, "");
        };
        self.filteredCardDetails = [];
		 //About this page accordian 
        self.expanded = false;
        self.closed = true;
        self.expandedView = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        }
					 /*
         * Add paranthesis for negative values
         */
		self.addBracket = function(negValue) {
            if (negValue) {
                var negativeValue = negValue.toString();
                if (negativeValue.charAt(0) === "-") {
                    var removeMinus = negativeValue.slice(1);     
					if(removeMinus.indexOf('.')!== -1){					
						var afterDot = removeMinus.substr(removeMinus.indexOf('.'));
						var beforeDot=removeMinus.substring(0,removeMinus.indexOf("."));					
					    var negativeFinal = beforeDot.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDot);
						var trimNegValue = "(" + negativeFinal + ")";
						return trimNegValue;
					}else{				
					var negativeFinal = Number(removeMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					var trimWithoutNegative = "(" + negativeFinal + ")";
					return trimWithoutNegative;
					}
                }else{
				if(negativeValue.indexOf('.')!== -1){
					  var afterDotPositive = negativeValue.substr(negativeValue.indexOf('.'));
					  var beforeDotPositive=negativeValue.substring(0,negativeValue.indexOf("."));
					  var negativeFinal = beforeDotPositive.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDotPositive);
					  return negativeFinal;
                }
				else{
				var negativeFinal = Number(negativeValue).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					return negativeFinal;
				}
				}
            }
        };
	
    };

});