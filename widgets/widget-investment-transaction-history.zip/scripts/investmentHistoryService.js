/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : prepaidService.js
 *  Description: Prepaid Card Transaction Details - services 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.InvestmentHistoryService = function($http,lpWidget,$window) {
	    var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var INVESTMENT_HISTORY = protocolHost+lpWidget.getResolvedPreference('investmentTransactionService');
        this.getTransactions = function(req) {
            return $http({
                url: INVESTMENT_HISTORY,
                method: "POST",
				data: req,
				headers: {'URL':'INVESTMENTS_TRANSACTION_HISTORY','KEY':'SPRINT1B','VALUE':'YES'}
				//data: history,
                // Static API for testing
                /*url: "https://api.myjson.com/bins/w44eh",
                method: "GET"*/
            })
        };
    };
});