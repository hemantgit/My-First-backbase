/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : porfolioControllers.js
 *  Description: Investment Account Portfolio - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function($http, lpCoreUtils, lpWidget, lpPortal, $window,lpCoreBus) {
        var self = this;
        var widget = lpWidget;
		var utils=lpCoreUtils
        var portfolioRequest = {};
        var portfolioDetailsRequest = {};
        var portfolioAcc = [];
		//getting host and protocol
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var portfolioUrl = protocolHost+widget.getResolvedPreference('goToPortfolio');
		//Getting image from model for logo
		self.investmentMutualFund= utils.resolvePortalPlaceholders(widget.model.getPreference("investmentMutualFund")) || "";
		self.unitInvestmentFund = utils.resolvePortalPlaceholders(widget.model.getPreference("investmentUitf")) || "";
		//Response from portfolio
		var portfolioDetailsPayloadRequest = JSON.parse($window.sessionStorage.getItem("portfolioDetailsPayloadRequest"));
		//Getting values from session
		self.portfolioAccountNumber=$window.sessionStorage.getItem("portfolioAccountNumber");	
		self.portfolioName=$window.sessionStorage.getItem("portfolioName");	
		self.portfolioDate=$window.sessionStorage.getItem("portfolioDate");	
		self.portfolioPreferredName=$window.sessionStorage.getItem("portfolioPreferredName");	
		self.portfolioDateOpened=$window.sessionStorage.getItem("portfolioDateOpened");
		self.portfolioMarketValue=$window.sessionStorage.getItem("portfolioMarketValue");
		self.investmentAccountType=$window.sessionStorage.getItem("investmentAccountType");
		self.investmentCurrency=$window.sessionStorage.getItem("investmentCurrency");	
		self.portfolioDetails=portfolioDetailsPayloadRequest;
									//formatting the date fields
								    //Replace date from APT with date string
									var pattern;
                                   if (self.portfolioDateOpened != undefined && self.portfolioDateOpened.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.portfolioDateOpened = new Date(self.portfolioDateOpened.replace(pattern, "$1/$2/$3"));
                                       // self.portfolioDateOpened = self.portfolioDateOpened.toString("mmm,dd,yyyy");
                                    } 
									if (self.portfolioDate != undefined && self.portfolioDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.portfolioDate = new Date(self.portfolioDate.replace(pattern, "$1/$2/$3"));
                                        //self.portfolioDate = self.portfolioDate.toString("mmm,dd,yyyy");
                                    }
		//To find account type
		self.bpiassetmanagement="";
		self.glossary="";		
		if(self.investmentAccountType==='ALFM' || self.investmentAccountType==='MF'){
			self.mutualFundLogo=true;
			self.glossary = widget.getResolvedPreference('mutualGlossary');		
	    	self.bpiassetmanagement = widget.getResolvedPreference('alfMutualFunds');
		}
		else if(self.investmentAccountType==='UITF'){
			self.unitInvestmentLogo=true;
			self.glossary = widget.getResolvedPreference('unitGlossary');		
		    self.bpiassetmanagement = widget.getResolvedPreference('bpiAssetManagement');
		}
		self.openLink = function(url){
			$window.open(url,"_blank");
		}
		//setting value for header
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'portfolioDetails'	
        });
		//Date filter for formatting
		self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 15))
                    return dateString.slice(4, 15);
                else
                    return "";
            }
        };
		//About this page accordian 
        self.expanded = false;
        self.closed = true;
        self.expandedView = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        }
		//Navigate to account dashboard
        self.goToPortfolio =function(){
		$window.location.href =portfolioUrl;
		};
			 /*
         * Add paranthesis for negative values
         */
            self.addBracket = function(negValue) {
            if (negValue) {
                var negativeValue = negValue.toString();
                if (negativeValue.charAt(0) === "-") {
                    var removeMinus = negativeValue.slice(1);     
					if(removeMinus.indexOf('.')!== -1){					
						var afterDot = removeMinus.substr(removeMinus.indexOf('.'));
						var beforeDot=removeMinus.substring(0,removeMinus.indexOf("."));					
					    var negativeFinal = beforeDot.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDot);
						var trimNegValue = "(" + negativeFinal + ")";
						return trimNegValue;
					}else{				
					var negativeFinal = Number(removeMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					var trimWithoutNegative = "(" + negativeFinal + ")";
					return trimWithoutNegative;
					}
                }else{
				if(negativeValue.indexOf('.')!== -1){
					  var afterDotPositive = negativeValue.substr(negativeValue.indexOf('.'));
					  var beforeDotPositive=negativeValue.substring(0,negativeValue.indexOf("."));
					  var negativeFinal = beforeDotPositive.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDotPositive);
					  return negativeFinal;
                }
				else{
				var negativeFinal = Number(negativeValue).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					return negativeFinal;
				}
				}
            }
        };
        
    };

});