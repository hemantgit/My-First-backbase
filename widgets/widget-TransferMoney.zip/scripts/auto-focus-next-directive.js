define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.autoFocusNext = function() {
        return {
            restrict: "A",
            link: function(scope, element) {
                element.on("input", function() {
                    if (element.val().length == element.attr("maxlength")) {
                        var $nextElement = element.next();
                        if ($nextElement.length) {
                            $nextElement[0].focus();
                        }
                    }
                });
            }
        }
    };
});