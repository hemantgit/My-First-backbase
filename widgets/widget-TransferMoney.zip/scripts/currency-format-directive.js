define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.currenyFormat = function($filter) {
        return {
            require: '?ngModel',
            link: function(scope, element, attrs, ngModelCtrl) {
                if (!ngModelCtrl) {
                    return;
                }
                ngModelCtrl.$parsers.push(function(val) {
                    if (angular.isUndefined(val)) {
                        //var val = '';
                    }
                    var clean = val.replace(/[^0-9\.]/g, '');
                    var decimalCheck = clean.split('.');
                    if (!angular.isUndefined(decimalCheck[1])) {
                        decimalCheck[1] = decimalCheck[1].slice(0, 2);
                        clean = decimalCheck[0] + '.' + decimalCheck[1];
                    }
                    if (val !== clean) {
                        ngModelCtrl.$setViewValue(clean);
                        ngModelCtrl.$render();
                    }
                    return clean;
                });
                var finalValue = 0;
                element.bind('blur', function() {
                    var plainNumber = element.val().replace(/[^\d|\-+|\.+]/g, '');
                    if (plainNumber <= 999999999.99 && plainNumber > 0) {
                        element.val($filter('currency')(plainNumber, 'PHP '));
                    } else {
                        element.val("");
                    }
                });
                element.bind('focus', function() {
                    var plainNumber = element.val().replace(/[^\d|\-+|\.+]/g, '');
                    element.val(plainNumber);
                });
                element.bind('keypress', function(event) {
                    if (event.keyCode === 32) {
                        event.preventDefault();
                    }
                    var x = event.which || event.keyCode;
                    var currentValue = String.fromCharCode(x);
                    finalValue = element.val() + currentValue;
                    if (finalValue > 999999999.9901) {
                        event.preventDefault();
                    }
                });
            }
        }
    };
});