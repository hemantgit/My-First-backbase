/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controller.js
 *  Description: BPI TransferMoney controller
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {

    'use strict';

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget, $window, TransferMoneyService, conversionCodes) {
        var self = this;
		var validation = lpWidget.getResolvedPreference('validation');
		var ReviewModal = lpWidget.getResolvedPreference('ReviewModal');
		self.loading = true;
		self.Imgtransfer = lpCoreUtils.resolvePortalPlaceholders(lpWidget.model.getPreference('Imgtransfer')) || '';
		self.toolTip = lpCoreUtils.resolvePortalPlaceholders(lpWidget.model.getPreference('toolTip')) || '';
		self.addIcon = lpCoreUtils.resolvePortalPlaceholders(lpWidget.model.getPreference('addIcon')) || '';
		TransferMoneyService.toolTip = self.toolTip;
		var rmNumber = $window.sessionStorage.getItem('rmNumber');
		//var rmNumber = 12345678901234;
	    TransferMoneyService.selectedDestAccType = "";
        self.showMainContentDiv = true;
		self.showRmDownDiv = false;
		self.showNoAccFoundDiv = false;
		self.showNoMerAccDiv = false;
		self.expanded=false;
		self.closed=true;		
		self.expand=function(){
			self.expanded = !self.expanded;
			self.closed = !self.closed;
		};
		/* If Rmtrailer has rmNUmber */
		if(rmNumber){
            self.currentState = 'TransFrom';
            self.amountTo = true; 
			self.toDayDate = new Date();			
            self.enteredAmount= '';
			self.myAccountsData = [];
			self.myAccountsDataDest = [];
			self.thirdPartyAccData = [];
            self.responseMsg = null;
			self.errorMsg = null;
			self.responseMsg = null;
			self.selectedAccnum = "";
			self.selectedDestAccnum = "";
			self.maxAmount = "";
			self.currencyName="";
			self.amounterrorMsg = null;
			self.enteredAmount= null;
			self.noteDiv= true;		
			self.transFromErr=false;
            self.transFromTOErr=false;
            self.transamt=false;
            self.amtlessZer=false;
            self.amtgtr0=false;
            self.amtavail=false;
            self.amtzero=false;
            self.greatthanzero=false;
            self.lessthanzero=false;
			/* Source and Beneficiary accounts from Session */
			self.transferFromAccounts=angular.fromJson($window.sessionStorage.getItem('transferFromAccounts'));
			self.transferToAccounts=angular.fromJson($window.sessionStorage.getItem('transferToAccounts'));			
            self.currencyCodeJSON = conversionCodes.currencyCode;
			/* Object to hold the Selected account details */
            self.transfermoneyObj = {
                "noteToTransfer": '',
                "payTo": '',
                "preferredName": '',
                "tranID": "IMPB",
                "termID": "", 
                "sourceAcctType": null, 
                "sourceCurrCode": null, 
                "sourceAcctNum": null, 
                "amount": '', 
                "sourceRMNum": null, 
                "sourceTraceNum": "9999999",
                "destinationAcctType": null, 
                "destinationCurrCode": null, 
                "destinationAcctNum": null, 
                "destinationTraceNum": "9999999"                
            };
			/* Object to hide and show the Beneficiary account Details*/
			self.showObjects = {
				"showTransferFromAcc": true,
				"showTransferToAcc": false,
				"amountTab": false,
				"transferToshow": true,
				"transferOn": true,
				"thirdParty": true,
				"transferFromInput": true,
				"transferToInput" : true,
				"ownAcc": true,
				"search": true
			};
			/*  To selct the source Account Details  */
			self.showPayFromAccouts = function (){
				self.currentState = 'TransFrom';
				self.transfermoneyObj.destinationAcctType = "";
				self.transfermoneyObj.destinationAcctNum = "";
				self.showObjects.transferToInput = true;
				self.showObjects.transferFromInput = true;
				self.showObjects.showTransferToAcc = false;
				self.showObjects.amountTab = false;
				self.showObjects.showTransferFromAcc = true;
				self.showObjects.transferToshow = true;
				self.removeErrorMsg();
			};
			/* To select the Beneficiary Account details */
			self.showPayToAccounts = function (){
				if(self.transfermoneyObj.sourceAcctNum && self.transfermoneyObj.sourceAcctNum != "") {
					self.currentState = 'TransTo';
					self.showObjects.transferToInput = true;
					self.showObjects.transferFromInput = false;
					self.showObjects.showTransferFromAcc = false;
					self.showObjects.amountTab = false;
					self.showObjects.showTransferToAcc = true;
					self.showObjects.transferToshow = false;
				}
				self.removeErrorMsg();
			};
			self.inputAmountBgc = function (){
				self.currentState = "amountField";
				self.showObjects.showTransferFromAcc = false;
				self.showObjects.showTransferToAcc = false;
				self.showObjects.amountTab = true;
				if(self.transfermoneyObj.sourceAcctNum && self.transfermoneyObj.sourceAcctNum != "") {
					self.showObjects.transferFromInput = false;
				}
				if(self.transfermoneyObj.destinationAcctNum && self.transfermoneyObj.destinationAcctNum != "") {
					self.showObjects.transferToInput = false;
				}
				self.removeErrorMsg();
            };
			self.fundTransAccountNumber = $window.sessionStorage.getItem('fundTransAccountNumber');
			self.fundTransPrefferedName = $window.sessionStorage.getItem('fundTransPrefferedName');
			self.fundTransCurrencyCode = $window.sessionStorage.getItem('fundTransCurrencyCode');
			self.fundTransAccountType = $window.sessionStorage.getItem('fundTransAccountType');
			if(self.fundTransAccountNumber && self.fundTransPrefferedName && self.fundTransCurrencyCode){
				self.showObjects.transferFromInput = false;
				self.currentState = 'TransTo';
				self.showObjects.showTransferFromAcc = false;
				self.showObjects.amountTab = false;
				self.showObjects.showTransferToAcc = true;
				self.transfermoneyObj.sourceAcctType=self.fundTransPrefferedName;
				self.transfermoneyObj.sourceAcct=self.fundTransAccountType;
				self.transfermoneyObj.sourceAcctNum=self.fundTransAccountNumber;
				self.transfermoneyObj.sourceCurrCode=self.fundTransCurrencyCode;
				self.maxAmount = $window.sessionStorage.getItem('fundTransAvailableBalance');
				self.selectedAccnum = self.transfermoneyObj.sourceAcctNum;
				self.payFromSelected=true;
				$window.sessionStorage.removeItem("selAccCurrencyName");
				$window.sessionStorage.setItem("selAccCurrencyName", self.currencyCodeJSON[self.fundTransCurrencyCode.substring(1)]);
				$window.sessionStorage.removeItem("fundTransAccountNumber");
				$window.sessionStorage.removeItem("fundTransPrefferedName");
			} 
            var rmtReq = {};
            rmtReq.rmNumber = rmNumber;	
		   /* To get the Source Account details from API Response */
		    self.getFromAccounts = function() {
				self.loading = true;
                TransferMoneyService.getSourceAcctDetails(self.transferFromAccounts).then(function(response) {
                    self.myAccountsData = response.data.SavingsChecking;
					self.loading = false;
				},
				function(response) {
					self.loading = false;
					if (conversionCodes.errorStatus(response)) {
						self.errorMsg = lpWidget.model.getPreference('serverError');
					}
				});
            };
			/* To get the beneficiary Account details from API Response */
			self.getToAccounts = function() {
				self.loading = true;
                TransferMoneyService.getSourceAcctDetails(self.transferToAccounts).then(function(response) {
                    self.myAccountsDataDest = response.data.SavingsChecking;
					if (response.data.SavingsChecking && response.data.SavingsChecking.length == 0) {
                            self.showMainContentDiv = false;
                            self.showNoMerAccDiv = true;
                        }
					self.loading = false;
				},
				function(response) {
					self.loading = false;
					if (conversionCodes.errorStatus(response)) {
						self.errorMsg = lpWidget.model.getPreference('serverError');
					}
				});
            };		   
			/* To get the Third Party Account details from API Response */
		   self.getThirdPartyAccounts = function(){
				self.loading = true;
				TransferMoneyService.getDestinationAcctDetails(rmtReq).then(function(response) {							 
							self.thirdPartyAccData = response.data.enrolledAccounts;
						if (response.data.enrolledAccounts && response.data.enrolledAccounts.length == 0) {
                            self.showMainContentDiv = false;
                            self.showNoMerAccDiv = true;
                        }							
							self.loading = false;
						},
						function(response) {
							self.loading = false;
							if (conversionCodes.errorStatus(response)) {
							self.errorMsg = lpWidget.model.getPreference('serverError');
					}
				});
		   };	
			 /*self.getFromAccounts();
			self.getToAccounts();
			self.getThirdPartyAccounts();*/				
			if (self.transferFromAccounts && self.transferFromAccounts.SavingsChecking.length >= 1) {				
                self.getFromAccounts();
				self.getToAccounts();
				self.getThirdPartyAccounts();
            } else {
				self.showNoAccFoundDiv = true;
				self.showMainContentDiv = false;
				self.loading = false;
			}			
			/* Method to display Source Account Details   */
			self.chooseSourceAccount = function(srcAcc,transferMoneyForm) {
				self.currentState = 'TransTo';
				self.beneficiaryDisabled = false;
				self.showObjects.showTransferFromAcc = false;
				self.showObjects.amountTab = false;
				self.showObjects.showTransferToAcc = true;
				self.showObjects.transferToshow = false;
				self.showObjects.search = false;
				self.showObjects.transferFromInput = false;
				self.maxAmount =  parseFloat(srcAcc.availableBalance);
				self.transfermoneyObj.sourceCurrCode = srcAcc.currencyCode;
				self.transfermoneyObj.sourceAcctNum = srcAcc.accountNumber;
				self.transfermoneyObj.sourceAcctType = srcAcc.preferredName;
				self.transFromQuery = '';
				self.transfermoneyObj.sourceTraceNum = "9999999";
				self.transfermoneyObj.sourceAcct= srcAcc.accountType;
				self.transfermoneyObj.sourceRMNum = rmNumber;
				self.selectedAccnum = srcAcc.accountNumber;
				self.currencyName = self.currencyCodeJSON[srcAcc.currencyCode.substring(1)];
				self.transFromErr=false;				
				$window.sessionStorage.removeItem("selAccCurrencyName");
                $window.sessionStorage.setItem("selAccCurrencyName", self.currencyCodeJSON[srcAcc.currencyCode.substring(1)]);
                self.clearForm = angular.copy(transferMoneyForm);
				self.removeErrorMsg();				
			};
			self.chooseOwnAccount = function(ownAcc, transferMoneyForm) {
				self.currentState = "amountField";
				self.showObjects.showTransferFromAcc = false;
				self.showObjects.showTransferToAcc = false;
				self.showObjects.amountTab = true;
				self.showObjects.transferToshow = false;
				self.showObjects.transferOn = false;
				self.showObjects.search = true;
				self.showObjects.transferFromInput = false;
				self.showObjects.transferToInput = false;
				self.showObjects.thirdParty = true;
				self.amountTo = false;
				self.transfermoneyObj.destinationAcctType = ownAcc.preferredName;
				self.transferToQuery = '';
				self.transfermoneyObj.destinationAcct = ownAcc.accountType;
				self.transfermoneyObj.destinationAcctNum = ownAcc.accountNumber;
				self.selectedDestAccnum = ownAcc.accountNumber;
				self.transfermoneyObj.destinationCurrCode = ownAcc.currencyCode;
				self.transfermoneyObj.destinationTraceNum = "9999999";
				self.clearForm = angular.copy(transferMoneyForm);
				TransferMoneyService.selectedDestAccType = "OwnAccount";
				self.transFromTOErr=false;
				$window.sessionStorage.removeItem("selAccCurrencyName");
                $window.sessionStorage.setItem("selAccCurrencyName", self.currencyCodeJSON[ownAcc.currencyCode.substring(1)]);
				self.removeErrorMsg();
			};
			self.chooseThirdPartyAccount = function(acc) {
				TransferMoneyService.selectedDestAccType = "ThirdPartyAccount";
				self.currentState = 'amountField';
				self.showObjects.showTransferFromAcc = false;
				self.showObjects.showTransferToAcc = false;
				self.showObjects.amountTab = true;
				self.showObjects.transferToshow = false;
				self.showObjects.transferOn = false;
				self.showObjects.search = true;
				self.showObjects.transferToInput = false;
				self.showObjects.thirdParty = true;
				self.amountTo = false;
				self.transfermoneyObj.destinationAcctType = acc.thirdPartyAcctName;
				self.transferToQuery = '';
				self.transfermoneyObj.destinationAcct = acc.accountType;
				self.transfermoneyObj.destinationAcctNum = acc.thirdPartyAcct;
				self.transfermoneyObj.destinationCurrCode = acc.currencyCode;
				self.transfermoneyObj.destinationTraceNum = "9999999";
				self.transFromTOErr=false;
				self.removeErrorMsg();
			};
			/* Calling the function to clear all the Fields */
           self.clearallFields = function(){
				TransferMoneyService.resetToStarting ();
		   };
		    TransferMoneyService.refreshApiValues = function(){		   
				self.getFromAccounts();
				self.getToAccounts();
				self.getThirdPartyAccounts();
		   };
		   /* Reset all values to null */
            TransferMoneyService.resetToStarting = function() {
                self.currentState = 'TransFrom';
				self.amountTo = true;
				self.transamt=false;
				 self.lessthanzero=false;
				 self.greatthanzero=false;
				 self.transFromErr = false;
				 self.transFromTOErr=false;
				 self.beneficiaryDisabled = true;
				 self.srcAcc=false;
				 self.transFromQuery = "";
				 self.transferToQuery = "";
				 self.selectedDestAccnum = "";
				 self.maxAmount = null;
				self.showObjects = {
					"showTransferFromAcc": true,
					"showTransferToAcc": false,
					"amountTab": false,
					"transferToshow": true,
					"transferOn": true,
					"thirdParty": true,
					"transferFromInput": true,
					"transferToInput" : true,
					"ownAcc": true,
					"search": true
				};
				self.enteredAmount= null;
				self.transfermoneyObj = {
					"destinationAcctType": "",
					"destinationAcct":null,
					"sourceAcct":null,
					"sourceAcctType": "",
					"sourceAcctNum": null,
					"transferOn": self.toDayDate,
					"amount": null,
					"destinationAcctNum": null,
					"noteToTransfer": null
				}				
            };          
			/* Form request to submit the selected account details */
            self.onSubmitValidation =  function(){
               self.transfermoneyObj.amount = self.enteredAmount;
				self.inputAmountBgc();
                TransferMoneyService.transferMoneyReqObj={
                    "tranID": "IMBP",
                    "termID": "",
                    "sourceAcctType": self.transfermoneyObj.sourceAcctType,
					"sourceAcct": self.transfermoneyObj.sourceAcct,
                    "sourceCurrCode": self.transfermoneyObj.sourceCurrCode,
                    "sourceAcctNum": self.transfermoneyObj.sourceAcctNum,
                    "amount":self.transfermoneyObj.amount,
                    "sourceRMNum":self.transfermoneyObj.sourceRMNum,
                    "sourceTraceNum":"9999999",
				   "destinationAcctType":self.transfermoneyObj.destinationAcctType,
				   "destinationAcct":self.transfermoneyObj.destinationAcct,
                    "destinationCurrCode":self.transfermoneyObj.destinationCurrCode,
                    "destinationAcctNum":self.transfermoneyObj.destinationAcctNum,
                    "destinationTraceNum":"9999999"                    
                };
                TransferMoneyService.Notes={
                    "noteToTransfer": self.transfermoneyObj.noteToTransfer,
                    "preferredName":self.transfermoneyObj.preferredName
                }
                if (!self.transfermoneyObj.sourceAcctNum || self.transfermoneyObj.sourceAcctNum == ""){
                    self.transFromErr=true;	
					TransferMoneyService.openModal(validation);					
                }else if (!self.transfermoneyObj.destinationAcctNum || self.transfermoneyObj.destinationAcctNum == ""){
                    self.transFromTOErr=true;
					TransferMoneyService.openModal(validation);
                }else if (!self.transfermoneyObj.amount || self.transfermoneyObj.amount == ""){
                    self.transamt=true;
					TransferMoneyService.openModal(validation);
                }else if (parseFloat(self.transfermoneyObj.amount) <= 0) {
                    self.lessthanzero=true;
                }else if (parseFloat(self.transfermoneyObj.amount) > parseFloat(self.maxAmount) ) {
                    self.greatthanzero = true;
                }
                else{
                    TransferMoneyService.openModal(ReviewModal);
                } 
            };
            /* To clear the error messages */
            self.removeErrorMsg = function(){
                self.transFromErr=false;
				self.transFromTOErr=false;
				self.transamt=false;
				self.amtlessZer=false;
				self.amtgtr0=false;
				self.amtavail=false;
				self.amtzero=false;
				self.greatthanzero=false;
				self.lessthanzero=false;
            };
			/*  Search Functionality for source accounts */
            self.searchSourceAccounts = function(obj) {
                return (angular.lowercase(obj.preferredName).indexOf(angular.lowercase(self.transFromQuery) || '') !== -1 ||
                        angular.lowercase(obj.accountNumber).indexOf(angular.lowercase(self.transFromQuery) || '') !== -1);
            };
			/*  Search Functionality for Beneficiary accounts */
			self.searchBeneficiaryAccounts = function(obj) {
                return (angular.lowercase(obj.preferredName).indexOf(angular.lowercase(self.transferToQuery) || '') !== -1 ||
                        angular.lowercase(obj.accountNumber).indexOf(angular.lowercase(self.transferToQuery) || '') !== -1);
            };
			/*  Search Functionality for Third party accounts */
			self.searchThirdPartyAccounts = function(obj) {
                return (angular.lowercase(obj.thirdPartyAcctName).indexOf(angular.lowercase(self.transferToQuery) || '') !== -1 ||
                        angular.lowercase(obj.thirdPartyAcct).indexOf(angular.lowercase(self.transferToQuery) || '') !== -1);
            };
        } else {
			self.serverErrorMsg = lpWidget.model.getPreference("serverErrMsg");
			self.showMainContentDiv = false;
			self.showRmDownDiv = true;
			self.loading = false;
		}
    };
	 // Transfer Money  Service
    // @ngInject
    exports.ModalInstanceController = function ($modalInstance, lpWidget, $window, TransferMoneyService, $filter, $rootScope, conversionCodes) {
        var self= this;
		var OTPSuspendModal = lpWidget.getResolvedPreference('OTPSuspendModal');
		var ServiceFailed = lpWidget.getResolvedPreference('ServiceFailed');
		var otpRegistration = lpWidget.getResolvedPreference('otpregistration');
		var otpRegistrationViaApp = lpWidget.getResolvedPreference('otpregistrationviaapp');
        self.enteredOTP = null;
        self.returnErrorMessage = TransferMoneyService.returnErrorMessage;
		self.otpReadonly = true;
        self.notesFlag = true;
		self.otpErrorMsgDiv = false;
		self.otpPinLenght = false;
		self.disabled = true;
		self.toolTip = TransferMoneyService.toolTip;
	    self.confirmNum = "";
        //self.ImgVisualGuide = lpCoreUtils.resolvePortalPlaceholders (lpWidget.model.getPreference('ImgVisualGuide')) || '';
        self.transMoneyObj = TransferMoneyService.transferMoneyReqObj;
		self.transMoneyObj.date = TransferMoneyService.todayDate;
        self.transMoneyObj.noteToTransfer = TransferMoneyService.Notes.noteToTransfer;
        self.transMoneyObj.preferredName = TransferMoneyService.Notes.preferredName;
        self.mobileNum = $window.sessionStorage.getItem('mobileNum');
		if(self.mobileNum){
			self.maskedMobileNum = self.mobileNum.substr(0, 3)+' '+self.mobileNum.substr(3, 3)+' xxx x'+self.mobileNum.substr(-3);
		}
        var rmNumber = $window.sessionStorage.getItem('rmNumber');
		//rmNumber = 12345678909876;
        var userName = $window.sessionStorage.getItem('userName');
		self.selAccCurrencyName = $window.sessionStorage.getItem('selAccCurrencyName');
		self.selectedDestAccType = TransferMoneyService.selectedDestAccType;
		// Function to check the Spin and Dormant accounts error code
		var keyMatch = function (array, str) {
			var AccountClosed = lpWidget.getResolvedPreference('AccountClosed');
			for (var i = 0; i < array.length; i++) {
				if (str.includes(array[i])) {
					TransferMoneyService.openModal(AccountClosed);			
					return value;				
				}
			}
			return false;
		};
		/* Function to canel the modal */
        self.closeokModal = function () {
            $modalInstance.dismiss('cancel');
        };
		self.newMobileReg = function() {
			$window.location.href = otpRegistration;
        };
		self.sendOtpBpiMob = function() {
			$window.location.href = otpRegistrationViaApp;
        };
		self.gotoMyAccPage = function() {
            $modalInstance.dismiss('cancel');
			var login_success = lpWidget.getResolvedPreference('loginsuccess');
			$window.location.href = login_success;//ACCOUNT_DETAILS;
        };
		self.clearOtpErrorMsg = function () {
            self.otpErrorMsgDiv = false;
			self.otpPinLenght = false;
        };
		/* Display OTP screens  */
        self.submitDetailsForTransferMoney = function() {	
			self.disabled = false;
			var OTPModalLinkedDevice = lpWidget.getResolvedPreference('OTPModalLinkedDevice');
			var OTPModal = lpWidget.getResolvedPreference('OTPModal');
			$modalInstance.dismiss('cancel');			
			if (self.selectedDestAccType == "OwnAccount") {
				self.makeTransferMoneyApiCall();
			} else{
				if ( $window.sessionStorage.getItem("otpStatus") == "2") {
					TransferMoneyService.openModal(OTPModalLinkedDevice);
				}
				else if( $window.sessionStorage.getItem("otpStatus") == "1"){
					TransferMoneyService.showNewMobReg = false;
					TransferMoneyService.openModal(OTPModal);
				} else{
					TransferMoneyService.openModal(OTPModal);
				}
			}
        };
		function clearEnteredOtp (){
			self.otpDig1 = "";
			self.otpDig2 = "";
			self.otpDig3 = "";
			self.otpDig4 = "";
			self.otpDig5 = "";
			self.otpDig6 = "";
		}
		/* API call for OTP authentication without LinkedDevice */
        self.submitOTPForValidation = function() {
		var enteredOtpPin = self.otpDig1+self.otpDig2+self.otpDig3+self.otpDig4+self.otpDig5+self.otpDig6;
		if(enteredOtpPin && enteredOtpPin.length == 6){
            var request = {
                "rmNumber":rmNumber,
                "smsRecipient":self.mobileNum,
                "smsOtp": enteredOtpPin,
                "username":userName
            };
            TransferMoneyService.submitOTP(request).then(function(response) {
                    if(response.data.code == "0"){
					 $modalInstance.dismiss('cancel');
                        self.makeTransferMoneyApiCall();
                    }else if(response.data.code == "22033"){
						$modalInstance.dismiss('cancel');
                        TransferMoneyService.openModal(OTPSuspendModal);
                    }
					else{
						self.otpErrorMsgDiv = true;
							clearEnteredOtp();               
                    }
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
						TransferMoneyService.returnErrorMessage = response.status;
                        TransferMoneyService.openModal(ServiceFailed);
                    }
                });
			} else {
				self.otpPinLenght = true;
				clearEnteredOtp();
			}           
        };		
		/* API call for OTP authentication with LinkedDevice */
		self.submitOTPDeviceForValidation = function() {
		var enteredOtpPin = self.otpDig1+self.otpDig2+self.otpDig3+self.otpDig4+self.otpDig5+self.otpDig6;
		if(enteredOtpPin && enteredOtpPin.length == 6){
            var request = {
				"username": userName,
                "rmNumber": rmNumber,
				"otp": enteredOtpPin
            };
            TransferMoneyService.submitOTPForDevice(request).then(function(response) {
                    if(response.data.code == 0){
						$modalInstance.dismiss('cancel');
                        self.makeTransferMoneyApiCall();
                    }else if(response.data.code == 22033){
						$modalInstance.dismiss('cancel');
                        TransferMoneyService.openModal(OTPSuspendModal);
						$window.sessionStorage.setItem("otpStatus", "3");
                    }else{
						self.otpErrorMsgDiv = true;
							clearEnteredOtp();            
                    }
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
						TransferMoneyService.returnErrorMessage = response.status;
                        TransferMoneyService.openModal(ServiceFailed);
                    }
                });
			} else {
				self.otpPinLenght = true;
				clearEnteredOtp();
			}
            
        };	
			/* API to call the sendsms */
        self.sendOTPViaSms = function() {
            self.otpReadonly=false;
			if(!$window.sessionStorage.getItem("otpStatus") || $window.sessionStorage.getItem("otpStatus") === "" || $window.sessionStorage.getItem("otpStatus") === "0"){
				var firstName = $window.sessionStorage.getItem('firstName');
				var lastName = $window.sessionStorage.getItem('lastName'); 
				var trxCfm = TransferMoneyService.getConfNum(rmNumber);
				var request = {"rmNumber":rmNumber,"username":userName,"mobileNumber":self.mobileNum,"firstName":firstName,"lastName":lastName,"confirmationNumber":trxCfm.confirmationNumber}; 
				TransferMoneyService.doForceRegistration(request).then(function(response) {   
						/* Success Response */
					},
					function(response) {
						if (conversionCodes.errorStatus(response)) {
							TransferMoneyService.returnErrorMessage = response.status;
							TransferMoneyService.openModal(ServiceFailed);
						}
					});
			} else{
				var request = {
					"rmNumber":rmNumber,
					"smsRecipient":self.mobileNum,
					"smsBody": "test",
					"username":userName
				};
				TransferMoneyService.sendSMSforOTP(request).then(function(response) {                  
						if(response.data.smsOtp && response.data.smsOtp.trim()){
						/* Success Response */
						}else{
							var ResponseError = lpWidget.getResolvedPreference('ResponseError');
							TransferMoneyService.returnErrorMessage = response.data.message;
							TransferMoneyService.openModal(ResponseError);                  
						}
					},
					function(response) {
						if (conversionCodes.errorStatus(response)) {
							TransferMoneyService.returnErrorMessage = response.status;
							TransferMoneyService.openModal(ServiceFailed);
						}
					});
			}
        };
        /* API call for Transaction Success */
        self.makeTransferMoneyApiCall = function() {
			var request = {
					"tranID": "IMPX",
                    "termID": "",
                    "sourceAcctType": TransferMoneyService.transferMoneyReqObj.sourceAcct,
                    "sourceCurrCode": TransferMoneyService.transferMoneyReqObj.sourceCurrCode,
                    "sourceAcctNum": TransferMoneyService.transferMoneyReqObj.sourceAcctNum,
					"destinationCurrCode":TransferMoneyService.transferMoneyReqObj.destinationCurrCode, 
					"destinationAcctType":TransferMoneyService.transferMoneyReqObj.destinationAcct,
                    "amount":TransferMoneyService.transferMoneyReqObj.amount,
                    "sourceRMNum":rmNumber,
                    "sourceTraceNum":"9999999",
                    "destinationTraceNum":"9999999",
					"destinationAcctNum":TransferMoneyService.transferMoneyReqObj.destinationAcctNum					
			}; 
            TransferMoneyService.makeFundTransfer(request).then(function(response) {			
			//var rmNumber = 12345678901234;
				$rootScope.$broadcast('resettags', {'defaultTags': true});
                self.dateConfirmObj = TransferMoneyService.getConfNum(rmNumber);
				self.transMoneyObj.transDate  = self.dateConfirmObj.transDate;
				self.transMoneyObj.confirmNum  = self.dateConfirmObj.confirmationNumber;
				self.confirmNum = self.dateConfirmObj.confirmationNumber;
                    if (response.data.returnCode == 0 ) {
						var transactionSuccess = lpWidget.getResolvedPreference('TransactionSuccess');
                        TransferMoneyService.openModal(transactionSuccess);
                    }else if(response.data.returnCode == 1 ) {
							var transactionFailSpinDorm = lpWidget.getResolvedPreference('TransactionFailSpinDorm');
							 self.makeTransactionLogInsert('Failed');
							 TransferMoneyService.returnErrorMessage = response.data.returnMessage;
							 if(conversionCodes.errorCode, TransferMoneyService.returnErrorMessage){
							 //succes Case
							 }else if((TransferMoneyService.returnErrorMessage).includes("ST0787")){
								
								TransferMoneyService.openModal(transactionFailSpinDorm);
							}else if((TransferMoneyService.returnErrorMessage).includes("IM7887")){
								TransferMoneyService.openModal(transactionFailSpinDorm);
							}
							else{
								TransferMoneyService.returnErrorMessage = response.data.returnMessage;
								var errorCode = lpWidget.getResolvedPreference('ErrorCode');
								TransferMoneyService.openModal(errorCode);
							} 
					} 
                    else{
						var transactionFail = lpWidget.getResolvedPreference('TransactionFail');
                        TransferMoneyService.openModal(transactionFail);
                    }
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
						TransferMoneyService.returnErrorMessage = response.status;
						TransferMoneyService.openModal(ServiceFailed);
                    }
                });
        };
		self.getOtpStatus = function() {
			if($window.sessionStorage.getItem("otpStatus") && $window.sessionStorage.getItem("otpStatus") !== "") {
				var request = {"userName":userName};
				TransferMoneyService.getOtpStatus(request).then(function(response) {
						if(response.data.result){
							self.submitDetailsForTransferMoney();
						} else {
							$modalInstance.dismiss('cancel');
							var OtpSuspendedModal = lpWidget.getResolvedPreference('OtpSuspendedModal');
							TransferMoneyService.openModal(OTPSuspendModal);
						}
					},
					function(response) {
						if (conversionCodes.errorStatus(response)) {
							$modalInstance.dismiss('cancel');
							TransferMoneyService.openModal(ServiceFailed);
						}
					});
			} else {
				self.submitDetailsForTransferMoney();
			}
        };
		/* After Transaction got successful call the Transaction Log and EmailNotification API */
		self.doTrxLogAndEmailAfterSuccess = function() {
			self.makeTransactionLogInsert('Success');
			self.sendEmailNotification('Success');
			TransferMoneyService.refreshApiValues();
			TransferMoneyService.resetToStarting ();
            $modalInstance.dismiss('cancel');
        };
		/* After Transaction got Failed call the Transaction Log API */
        self.doTrxLogAfterFailure = function() {
			self.makeTransactionLogInsert('Failed');
			 TransferMoneyService.resetToStarting ();
            $modalInstance.dismiss('cancel');
        };
		/* API call for EmailNotification */
        self.sendEmailNotification = function() {
				var emailId= $window.sessionStorage.getItem('emailId');
				var firstName = $window.sessionStorage.getItem('firstName');
				var lastName = $window.sessionStorage.getItem('lastName');     
				var datetoday = new Date();    
				var regDate = $filter('date')(datetoday, "MMMM dd, yyyy; h:mm:ss a"); 	
				var currencyFormat = $filter('currency')(TransferMoneyService.transferMoneyReqObj.amount, "PHP "); 
				var srcAccNo = TransferMoneyService.transferMoneyReqObj.sourceAcctNum.toString().slice(-5);
				var srcThreeDigits = TransferMoneyService.transferMoneyReqObj.sourceAcctNum.toString().slice(-3);
				var destAccNo = TransferMoneyService.transferMoneyReqObj.destinationAcctNum.toString().slice(-5);
				var destThreeDigits = TransferMoneyService.transferMoneyReqObj.destinationAcctNum.toString().slice(-3);
				
				var srcNo = srcAccNo.slice(1,2);
				var destNo = destAccNo.slice(1,2);
				var tranSrcAccccNo = "XXXX-XX"+srcNo+"-"+srcThreeDigits;
				var tranDestAccNo =  "XXXX-XX"+destNo+"-"+destThreeDigits;
				var transfrom = tranSrcAccccNo+" ("+TransferMoneyService.transferMoneyReqObj.sourceAcctType+")";
				var transto = tranDestAccNo+" ("+TransferMoneyService.transferMoneyReqObj.destinationAcctType+")";
				var notestransfer=(self.transMoneyObj.noteToTransfer)?self.transMoneyObj.noteToTransfer:"";
				var request = {
					"msg": {
						"from": "",
						"to": "",
						"subject": "Funds Transfer - PHP to PHP Confirmation",
						"text": "Your Transaction got Successful",
						"html":"<html><body>"+
						"<div class='row text-center'><h4>Dear "+firstName+"  "+lastName+"</h4><p>This is to confirm your Funds Transfer transaction with the following details:</p>"+ "<div class='table table-responsive'>"+ "<table style='border:2px solid #c7c7c7;border-radius:5px;width:40%;margin:0 auto;'>"+
						"<tr><td style='text-align:center;'colspan='2'></td></tr>"+
						"<tr><td style='text-align:left;padding:4px;width:24%; text-align:center;'colspan='2'><span style='font-size:25px;'>Transfer Confirmation</span></td></tr>"+ 
						"<tr><td style='text-align:left;padding-left:20px;padding-right:24px;width:24%; text-align:center;'colspan='2'><div style='border-bottom:1px solid #c7c7c7'></div></td></tr>"+ 
						"<tr><td style='text-align:left;padding-left:24px;width:24%;'>Transferred to</td><td style='text-align:left;padding-left:20px;width:24%;'>"+transto+"</td></tr>"+
						"<tr><td style='text-align:left;padding-left:24px;width:24%;'>Transferred from</td><td style='text-align:left;padding-left:20px;width:24%;'>"+transfrom+"</td></tr>"+
						"<tr><td style='text-align:left;padding-left:24px;width:24%;'>Amount</td><td style='text-align:left;padding-left:20px;width:24%;'>"+currencyFormat+"</td></tr>"+
						"<tr><td style='padding-bottom:8px;'></td></tr>"+
						"<tr><td style='text-align:left;padding-left:24px;width:24%;'>Notes</td><td style='text-align:left;padding-left:20px;width:24%;'>"+notestransfer+"</td></tr>"+						
						"<tr><td style='text-align:left;padding-left:24px;width:24%;'>Transaction Date and Time</td><td style='text-align:left;padding-left:20px;width:24%;'>"+regDate+"</td></tr>"+
						"<tr><td style='text-align:left;padding-left:24px;width:24%;'>Confirmation Number</td><td style='text-align:left;padding-left:20px;width:24%;'>"+self.transMoneyObj.confirmNum+"</td></tr>"+		
						"<tr><td style='padding-bottom:15px;'></td></tr>"+
						"</table></div><div class='row col-xs-12 col-sm-12 col-md-12 col-lg-12'><br>Reminders:<br>"+ "All transfers are done real time and credits are immediately withdrawable over the counter or via the ATM. However, credits arising from funds transfers done after the system cut-off of 10:00PM<br>(GMT +8) will be considered the next banking day's transaction<br><br>"+ "Should you have concerns please e-mail us at <a href='#'>expressonline@bpi.com.ph.</a> <br>Thank you for using BPI Express Online.</div></div></body></html>"

					}
				}; 
		 
            TransferMoneyService.sendEmailNotification(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
					//CallBackErrorStatus
                    }
                });

        };
		/* API call for Transaction Log insert*/
        self.makeTransactionLogInsert = function(status) {
			var transAmount = self.selAccCurrencyName+" "+self.transMoneyObj.amount;
            var request = {
                "userName": userName, 
                "rmNumber": rmNumber,
                "transactionType": "FT",
                "sourceAccountNumber": self.transMoneyObj.sourceAcctNum,
                "beneficiaryAccountNumber": self.transMoneyObj.destinationAcctNum,
                "merchantReferenceNumber": self.transMoneyObj.destinationAcctNum,
                "settlementAccountNumber": self.transMoneyObj.sourceAcctNum,
                "transactionAmount": transAmount,
                "serviceCharge": "",
                "confirmationNumber": self.transMoneyObj.confirmNum,
				"amountCurrency":self.selAccCurrencyName,
                "status": status
            };
            TransferMoneyService.insertToTransactionLog(request).then(function(response) {
                    //This call is getting successful
                },
                function(response) {
                    if (conversionCodes.errorStatus(response)) {
                        //This call is getting failure
                    }
                });

        };
    };
});