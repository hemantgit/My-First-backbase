define (function (require, exports) {
    'use strict';

    // @ngInject
    exports.TransferMoneyService = function ($http, $window, $modal, lpCoreUtils, lpWidget) {
        var self = this;
        self.transferMoneyReqObj = {};
        self.Notes = {};
		self.returnErrorMessage = null;
		self.resetForm = false;
		self.todayDate = new Date();
		self.sourceAccdestData = [];
		self.toolTip = null;
		self.showNewMobReg = true;
		/* API Calls */
		var protocol_Host = $window.location.protocol+'//'+$window.location.host;
		var ft_Address_Book = protocol_Host+lpWidget.getResolvedPreference('ftaddressbook');
		var funds_Transfer = protocol_Host+lpWidget.getResolvedPreference('fundstransfer');
		var request_SmsOtp = protocol_Host+lpWidget.getResolvedPreference('requestsmsotp');
		var forceRegistration = protocol_Host+lpWidget.getResolvedPreference('forceregistration');
		var auth_SmsOtp = protocol_Host+lpWidget.getResolvedPreference('authsmsotp');
		var auth_MobileOtp = protocol_Host+lpWidget.getResolvedPreference('authmobileotp');
		var transaction_Log = protocol_Host+lpWidget.getResolvedPreference('transactionlog');
		var financial_Emailnotif = protocol_Host+lpWidget.getResolvedPreference('financialemailnotif');
		var savings_Checking = protocol_Host+lpWidget.getResolvedPreference('savingAndCheckingBalance');
		
		self.rmNumber = $window.sessionStorage.getItem('rmNumber');		
		self.refreshApiValues = function(){
			// It will reset form in main controller
		};/* To open the modal */
        self.openModal = function(CurrentModal) {
            $modal.open({
            templateUrl:CurrentModal,
            controller: 'ModalInstanceController as mic',
            windowClass: 'ModalContainer',
            backdrop: 'static'
            }); 
        };
		/* Generate the Confirmation Number  */
        self.getConfNum = function(rmNumber) {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1; 
            var yyyy = today.getFullYear();
            var yy=yyyy.toString().slice(-2);
            var hh=today.getHours();
            var minits=today.getMinutes();
            var ss=today.getSeconds();
            var ran = Math.floor((Math.random() * 10));
           if(dd<10) {
				dd='0'+dd;
			}if(mm<10) {
				mm='0'+mm;
			} if(hh<10) {
				hh='0'+hh;
			}if(ss<10){
			ss='0'+ss;
			} if(minits<10) {
			minits='0'+minits;
			} 
            return {'transDate':today, 'confirmationNumber':rmNumber.toString().slice(-10)+''+dd+''+mm+''+yy+''+hh+''+minits+''+ss+''+ran};   
        };
		/* API call to get the Source Accounts */
			self.getSourceAcctDetails = function(req) {
                return $http({
					url: savings_Checking,//SAVINGS_AND_CHECKING_BALANCE,
                    method: "POST",
                    data: req, 
					headers: {'URL':'SAVING_CHECKING_BALANCE'}
                    //Static API for Offshore testing
                     // url: "https://api.myjson.com/bins/pxo7h",
                     // method: "GET"
                })
            },
			/*API call to get the Beneficiary Accounts */
            self.getDestinationAcctDetails = function(req) { 
                return $http({
				  	url: ft_Address_Book,//FT_ADDRESS_BOOK, 
					method: "POST",
                    data: req,
					headers: {'URL':'FT_ADDRESS_BOOK'}
                    // Static API for Offshore testing
					// url: "https://api.myjson.com/bins/pxo7h",
					// url: "https://api.myjson.com/bins/1fi0rz",					 
                    // method: "GET"
                })
            },
			/* API call for Transaction Successfull */
            self.makeFundTransfer = function(req) {
                return $http({
                    url: funds_Transfer,//MAKE_TRANSFER_MONEY, 
                    method: "POST",
                    data: req,
					headers: {'URL':'FUNDS_TRANSFER'}
                })
            },
			/* API call to send sms */
             self.sendSMSforOTP = function(req) {
                return $http({
					url: request_SmsOtp,//REQUEST_SMS_OTP, 
					method: "POST",
                    data: req,
					headers: {'URL':'SMS'}
                })
            },
			/* API call to submit OTP */
            self.submitOTP = function(req) {
                return $http({
					url: auth_SmsOtp,//AUTH_SMS_OTP, 
					method: "POST",
                    data: req
                })
            },
			self.doForceRegistration = function(req) {
                return $http({
                    url: forceRegistration,
                    method: "POST",
                    data: req
                })
            },
			/* API call to submit OTP for Linked Device */
			 self.submitOTPForDevice = function(req) {
                return $http({
					url: auth_MobileOtp,//AUTH_MOBILE_OTP, 
					method: "POST",
                    data: req
                })
            },
			/* API call For Transaction Log */ 
            self.insertToTransactionLog = function(req) {
                return $http({
                    url: transaction_Log,//TRANSACTION_LOG, 
					method: "POST",
					data: req,
					headers: {'URL':'TRANSACTION_LOG'}
                })
            },
			self.getOtpStatus = function(req) {
                return $http({
                    url: transaction_Log,//TRANSACTION_LOG,
                    method: "POST",
                    data: req,
					headers: {'URL':'GET_OTP_STATUS'}
                })
            },
			/* API call for Email Notification */
            self.sendEmailNotification = function(req) {
                return $http({
                    url: financial_Emailnotif,//EMAIL_NOTIFICATION, 
                    method: "POST",
                    data: req,
					headers: {'URL':'FINANCIAL_EMAIL_NOTIF'}
					
                })
            }
    }

});