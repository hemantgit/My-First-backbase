/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : investmentControllers.js
 *  Description: Investment Transaction Details - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function($http, lpCoreUtils, lpWidget, lpPortal, $window,lpCoreBus) {
        var self = this;
        var widget = lpWidget;
        self.display = false;
		var utils=lpCoreUtils;
        var investmentRequest = {};
        var investmentDetailsRequest = {};
        var transactionAcc = [];
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'investmentHistory'	
        });
		function getImage(value){
			return utils.resolvePortalPlaceholders(widget.model.getPreference(value)) || "";
		}
		//Getting protocol and host values
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var accountDetailsUrl = protocolHost+widget.getResolvedPreference('goToHome');
		//Getting image from model for logo
		self.investmentMutualFund= getImage("investmentMutualFund");
		self.unitInvestmentFund = getImage("investmentUitf");
		//getting values from investment history
		var investmentHistoryPayload = JSON.parse($window.sessionStorage.getItem("investmentHistoryPayload"));
		self.dateOpened=$window.sessionStorage.getItem("investmentDateOPened")
		self.investmentDetailsType=$window.sessionStorage.getItem("investmentDetailsType")
		self.investmentDetailsName=$window.sessionStorage.getItem("investmentDetailsName")
		self.investmentPreferredName=$window.sessionStorage.getItem("investmentPreferredName")
		self.investmentDetails=investmentHistoryPayload;
									var pattern;
                                    if (self.dateOpened.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.dateOpened = new Date(self.dateOpened.replace(pattern, "$1/$2/$3"));
                                    }
									if (self.investmentDetails.orderDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.investmentDetails.orderDate = new Date(self.investmentDetails.orderDate.replace(pattern, "$1/$2/$3"));
                                    }
									if (self.investmentDetails.settlementDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.investmentDetails.settlementDate = new Date(self.investmentDetails.settlementDate.replace(pattern, "$1/$2/$3"));
                                    }
									if (self.investmentDetails.bookingDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.investmentDetails.bookingDate = new Date(self.investmentDetails.bookingDate.replace(pattern, "$1/$2/$3"));
                                    }
									if (self.investmentDetails.bookingDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.investmentDetails.bookingDate = new Date(self.investmentDetails.bookingDate.replace(pattern, "$1/$2/$3"));
                                    }
									if (self.investmentDetails.priceDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.investmentDetails.priceDate = new Date(self.investmentDetails.priceDate.replace(pattern, "$1/$2/$3"));
                                    }
		//Date filter for formatting
		self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 15))
                    return dateString.slice(4, 15);
                else
                    return "";
            }
        };
		//Add bracket for negative values
	    self.addBracket = function(negValue) {
            if (negValue) {
                var negativeValue = negValue.toString();
                if (negativeValue.charAt(0) === "-") {
                    var removeMinus = negativeValue.slice(1);     
					if(removeMinus.indexOf('.')!== -1){					
						var afterDot = removeMinus.substr(removeMinus.indexOf('.'));
						var beforeDot=removeMinus.substring(0,removeMinus.indexOf("."));					
					    var negativeFinal = beforeDot.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDot);
						var trimNegValue = "(" + negativeFinal + ")";
						return trimNegValue;
					}else{				
					var negativeFinal = Number(removeMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					var trimWithoutNegative = "(" + negativeFinal + ")";
					return trimWithoutNegative;
					}
                }else{
				if(negativeValue.indexOf('.')!== -1){
					  var afterDotPositive = negativeValue.substr(negativeValue.indexOf('.'));
					  var beforeDotPositive=negativeValue.substring(0,negativeValue.indexOf("."));
					  var negativeFinal = beforeDotPositive.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDotPositive);
					  return negativeFinal;
                }
				else{
				var negativeFinal = Number(negativeValue).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					return negativeFinal;
				}
				}
            }
        };
		//About this page accordian 
        self.expanded = false;
        self.closed = true;
        self.expandedView = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        }
		//Navigation to my accounts page
        self.goToHomePage = function(){
		$window.location.href =accountDetailsUrl;
		};
		if(self.investmentDetailsType==='ALFM' || self.investmentDetailsType==='MF'){
			self.mutualFundLogo=true;
		}else if(self.investmentDetailsType==='UITF'){
			self.unitInvestmentLogo=true;
		}
        
    };

});