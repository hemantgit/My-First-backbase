/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : porfolioControllers.js
 *  Description: Investment Account Portfolio - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget, $window,lpCoreBus) {
        var self = this;
        var widget = lpWidget;
		var utils = lpCoreUtils;
		
        self.display = false;
		self.mutualFundLogo=false;
		self.unitInvestmentLogo=false;
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'portfolio'	
        });
		//getting logos for account ttypes
		function getImage(value){
			return utils.resolvePortalPlaceholders(widget.model.getPreference(value)) || "";
		}
		self.investmentMutualFund = getImage("investmentMutualFund");
		self.unitInvestmentFund = getImage("investmentUitf");
		//getting currency
		self.phpCurrency = getImage("php");
		self.usdCurrency = getImage("usd");
		self.euroCurrency = getImage("euro");
		//error message for no data for that currency
		self.noData = getImage("noData");
		//getting values from seesion for this page
		var portfolioPayloadRequest = JSON.parse($window.sessionStorage.getItem("portfolioPayloadRequest"));
		//setting values in session for portfolio details
		$window.sessionStorage.removeItem("portfolioAccountNumber");	
        $window.sessionStorage.setItem("portfolioAccountNumber",portfolioPayloadRequest.accountNumber);	
		$window.sessionStorage.removeItem("portfolioName");	
        $window.sessionStorage.setItem("portfolioName",portfolioPayloadRequest.accountName);			
		$window.sessionStorage.removeItem("portfolioPreferredName");	
        $window.sessionStorage.setItem("portfolioPreferredName",portfolioPayloadRequest.preferredName);	
		$window.sessionStorage.removeItem("portfolioDate");	
        $window.sessionStorage.setItem("portfolioDate",portfolioPayloadRequest.portfolioDate);	
		$window.sessionStorage.removeItem("portfolioDateOpened");	
        $window.sessionStorage.setItem("portfolioDateOpened",portfolioPayloadRequest.dateOpened);	
		$window.sessionStorage.removeItem("portfolioMarketValue");	
        $window.sessionStorage.setItem("portfolioMarketValue",portfolioPayloadRequest.totalPortfolioMarketValue);
		$window.sessionStorage.removeItem("investmentAccountType");	
        $window.sessionStorage.setItem("investmentAccountType",portfolioPayloadRequest.accountType);
		$window.sessionStorage.removeItem("investmentCurrency");	
        $window.sessionStorage.setItem("investmentCurrency",portfolioPayloadRequest.currency);			
		var investmentAccountNumber = $window.sessionStorage.getItem("investmentAccountNumber");
		//Getting protocol and host
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var loginSuccessUrl = protocolHost+widget.getResolvedPreference('goToHome');		
		var portfolioDetailsUrl = protocolHost+widget.getResolvedPreference('portfolioDetails');	
	    self.portfolio = portfolioPayloadRequest;
									var pattern;
                                    if (self.portfolio.dateOpened.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.portfolio.dateOpened = new Date(self.portfolio.dateOpened.replace(pattern, "$1/$2/$3"));
                                        //self.portfolio.dateOpened = self.portfolio.dateOpened.toString("mmm,dd,yyyy");
                                    }
									if (self.portfolio.portfolioDate.length === 8) {
                                        pattern = /(\d{2})(\d{2})(\d{4})/;
                                        self.portfolio.portfolioDate = new Date(self.portfolio.portfolioDate.replace(pattern, "$1/$2/$3"));
                                       // self.portfolio.portfolioDate = self.portfolio.portfolioDate.toString("mmm,dd,yyyy");
                                    }
                                    
		var portfolioPhp=[];                           
        var portfolioUsd=[];
        var portfolioEuro=[];
		self.portfolioPrimary={};		
		self.portfolioSecondary={};
		self.portfolioEuroContent={};
		//Extracting values from response
		angular.forEach(self.portfolio.investmentDetails,function(portfolioAccount){
		if(portfolioAccount.fundCurrency==='PHP'){
		self.displayPhp=true;
		portfolioPhp.push(portfolioAccount);
		}
		if(portfolioAccount.fundCurrency==='USD'){
		portfolioUsd.push(portfolioAccount);
		self.displayUsd=true;
		}	
		if(portfolioAccount.fundCurrency==='EURO'){
		portfolioEuro.push(portfolioAccount);
		self.displayEuro=true;
		}		
		});	
		if(portfolioUsd.length > 0){		
		self.displayUsd=true;
		}
		else{
		self.noUsd=true;
		}
		if(portfolioPhp.length > 0){
		self.displayPhp=true;
		}
		else{
		self.noPhp=true;
		}
		if(portfolioEuro.length > 0){		
		self.displayEuro=true;
		}
		else{
		self.noEuro=true;
		}
		self.portfolioPrimary=portfolioPhp;
		self.portfolioSecondary=portfolioUsd;
		self.portfolioEuroContent=portfolioEuro;
		//Date filter for formatting
		self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 16))
                    return dateString.slice(4, 16);
                else
                    return "";
            }
        };							
		//Finding the account type
		self.bpiassetmanagement="";
		self.glossary="";	
		if(self.portfolio.accountType==='ALFM' || self.portfolio.accountType==='MF'){
			self.mutualFundLogo=true;
			self.shares=true;
			self.glossary = widget.getResolvedPreference('mutualGlossary');		
	    	self.bpiassetmanagement = widget.getResolvedPreference('alfMutualFunds');
		}
		else if(self.portfolio.accountType==='UITF'){
			self.unitInvestmentLogo=true;
			self.units=true;
			self.glossary = widget.getResolvedPreference('unitGlossary');		
		    self.bpiassetmanagement = widget.getResolvedPreference('bpiAssetManagement');
		}
		self.openLink = function(url){
			$window.open(url,"_blank");
		}
		//Navigation to portfolio details
        self.doInvestmentsAccountPorfolioDetails = function(portfolioDetail) {
            $window.sessionStorage.removeItem("portfolioDetailsPayloadRequest");                               	
			$window.sessionStorage.setItem("portfolioDetailsPayloadRequest", JSON.stringify(portfolioDetail));           
            $window.location.href = portfolioDetailsUrl;
        }
		//Navigation to my accounts page			
        self.goToHomePage = function(){
		$window.location.href =loginSuccessUrl;
		};
        //About this page accordian 
        self.expanded = false;
        self.closed = true;
        self.expandedView = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        }
		/* To Reverse the Sorting order */
        self.investmentSort = 'investment';
        self.sortReverse = true;
        self.reverseSort = function(portfolio) {

            self.sortReverse = !self.sortReverse;
            self.investmentSort = portfolio;
        };
			 /*
         * Add paranthesis for negative values
         */
        self.addBracket = function(negValue) {
            if (negValue) {
                var negativeValue = negValue.toString();
                if (negativeValue.charAt(0) === "-") {
                    var removeMinus = negativeValue.slice(1);     
					if(removeMinus.indexOf('.')!== -1){					
						var afterDot = removeMinus.substr(removeMinus.indexOf('.'));
						var beforeDot=removeMinus.substring(0,removeMinus.indexOf("."));					
					    var negativeFinal = beforeDot.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDot);
						var trimNegValue = "(" + negativeFinal + ")";
						return trimNegValue;
					}else{				
					var negativeFinal = Number(removeMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					var trimWithoutNegative = "(" + negativeFinal + ")";
					return trimWithoutNegative;
					}
                }else{
				if(negativeValue.indexOf('.')!== -1){
					  var afterDotPositive = negativeValue.substr(negativeValue.indexOf('.'));
					  var beforeDotPositive=negativeValue.substring(0,negativeValue.indexOf("."));
					  var negativeFinal = beforeDotPositive.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").concat(afterDotPositive);
					  return negativeFinal;
                }
				else{
				var negativeFinal = Number(negativeValue).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
					return negativeFinal;
				}
				}
            }
        };


    };

});