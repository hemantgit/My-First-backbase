/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : prepaidService.js
 *  Description: Prepaid Card Transaction Details - services 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.PrepaidHistoryService = function($http,lpWidget,$window) {
		var widget = lpWidget;
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var CARD_TRANSACTION_DETAILS = protocolHost+widget.getResolvedPreference('prepaidHistory');
        this.getTransactions = function(prepaidRequest) {
            return $http({
                url: CARD_TRANSACTION_DETAILS,
                method: "POST",
                data: prepaidRequest,
				headers: {'URL':'CREDITCARD_TRANS_HISTORY','KEY':'SPRINT1B','VALUE':'YES'}
                // Static API for testing
                /*url: "https://api.myjson.com/bins/19ucd1",
                method: "GET",*/
            });
        };

    };

});