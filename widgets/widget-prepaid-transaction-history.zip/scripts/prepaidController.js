/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : prepaidControllers.js
 *  Description: Prepaid Card Transaction Details - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(PrepaidHistoryService, $http, lpCoreUtils, lpWidget, lpPortal, $window, conversionCodes) {
        var utils = lpCoreUtils;
        var widget = lpWidget;
        var self = this;        
        self.downloadTransaction = utils.resolvePortalPlaceholders(widget.model.getPreference("downloadTrans")) || "";
        self.downloadElectronic = utils.resolvePortalPlaceholders(widget.model.getPreference("downloadElectronic")) || "";
        self.errorMsg = null;
        self.downloadDisable = false;
		/* Currency And Institution code conversion */
        self.currencyCodeJSON = conversionCodes.currencyCode;
        self.institutionCodeJSON = conversionCodes.institutionCode;
		//Getting protocol and host values
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var ACCOUNT_DETAILS = protocolHost+widget.getResolvedPreference('goToHome');
        /* Getting data form sessionStorage */
		var prepaidRequest = JSON.parse($window.sessionStorage.getItem("prepaidTransacitonRequest"));
		var prepaidHistoryDetails = JSON.parse($window.sessionStorage.getItem("prepaidHistoryRequest"));
			self.prepaidAccountNumber=$window.sessionStorage.getItem("prepaidAccountNumber");
			self.prepaidAvailableBalance=$window.sessionStorage.getItem("prepaidAvailableBalance");
			self.prepaidPreferredName=$window.sessionStorage.getItem("prepaidPreferredName");		
        //adding spinner
        angular.element(".loader").removeClass("hidden").parents("tr").removeClass("hidden");
        /* To display data from real API */
        PrepaidHistoryService.getTransactions(prepaidHistoryDetails).then(function(response) {
				//removing loader
                angular.element(".loader").addClass("hidden").parents("tr").addClass("hidden");
                self.mydata = response.data;
                response.data.CreditCardTransactionHistory.forEach(function(obj) {
					//formatting date
                    var pattern = /(\d{2})(\d{2})(\d{4})/;
                    obj.transactionDate = new Date(obj.transactionDate.replace(pattern, "$1/$2/$3"));
                    if (obj.transactionDate != "Invalid Date") {
                        obj.transactionDate = obj.transactionDate.toString("MMM, dd,yyyy");
                    }
                });
                if (self.mydata.TransactionHistory && self.mydata.TransactionHistory.length == 0) {
                    self.errorMsg = widget.model.getPreference("noRecordsFound");
                    self.downloadDisable = true;
                }

            },
            function(response) {
               if(conversionCodes.errorStatus(response)){
					//removing spinner
                    angular.element(".loader").addClass("hidden").parents("tr").addClass("hidden");
                    self.errorMsg = widget.model.getPreference("serverError");
                    self.downloadDisable = true;
                }
            });
        /* To Convert sanded date format */
        self.dateFilter = function(obj) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(obj);

            } else {
                if (obj && obj.slice(4, 11))
                    return obj.slice(4, 11);
                else
                    return "";
            }
        };
        self.dateFilterForIE = function(obj) {
            if (obj && obj.slice(4, 11)) {
                var date = obj.slice(8, 10);
                if (Number(date) <= 9) {
                    return obj.slice(4, 7) + " 0" + obj.slice(8, 10);
                } else {
                    return obj.slice(4, 11);
                }
            } else {
                return "";
            }
        };
		//format date 
        self.transactionDate = function(obj) {
            return (new Date(obj.transactionDate));
        };
		//format transaction amount
        self.transactionAmount = function(obj) {
            return Number(obj.transactionAmount);
        };
		//search data
        self.serachHistory = function() {
            var searchData = self.transactionSearch;
            return searchData.replace(/\,/g, "").replace(/\./g, "");
        };
        /* To Reverse the Sorting order */
        self.prepaidSort = self.TransactionDate;
        self.sortDescending = true;
        self.reverseSort = function(prepaid) {
            self.sortDescending = !self.sortDescending;
            self.prepaidSort = prepaid;
        };
        /* To navigate to back to my accounts */
        self.goToHomePage = function(){
			$window.location.href =ACCOUNT_DETAILS;
			};
        
        /*
         * Trim description if has spaces
         */
        self.trimDescription = function(desc) {
            if (desc) {
                var trimedDescription = desc.substr(desc.indexOf(" ") + 1);
                return trimedDescription;
            } else {
                return "";
            }

        };
        /*
         * Convert currency code to currency value
         */
        self.getCurrency = function(val) {
            var currencyCode;
            if (val) {
                currencyCode = val.substr(1, 2);
            }
            return currencyCode;
        };
        /*
         * Add paranthesis for negative values
         */
        self.addBracket = function(negValue) {
            if (negValue) {
                var negativeValue = negValue.toString();
                if (negativeValue.charAt(0) === "-") {
                    var removeMinus = negativeValue.slice(1);
                    var trimNeg = Number(removeMinus).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    var trimNegativeValue = "(" + trimNeg + ")";
                    return trimNegativeValue;
                } else {
                    var trimNonNegative = Number(negativeValue).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
                    return trimNonNegative;
                }
            }
        };
        self.filteredCardDetails = [];

    };

});