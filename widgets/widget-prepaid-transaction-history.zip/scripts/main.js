/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : main.js
 *  Description: Prepaid Card Transaction Details - main
 *  ----------------------------------------------------------------
 */
define(function(require, exports, module) {

    "use strict";

    module.name = "widget-prepaid-transaction-history";

    var base = require("base");
    var core = require("core");
    var ui = require("ui");
	var customModule = require('module-custom-bpi');

    var deps = [
        core.name,
        ui.name,
        customModule.name
    ];

    // @ngInject
    function run() {
        // Module is Bootstrapped
    }

    module.exports = base.createModule(module.name, deps)
        .service(require("./prepaidService"))
        .controller(require("./prepaidController"))
        .filter(require("./prepaidFilters"))
        .run(run);
});