define(function(require, exports, module) {
    'use strict';

    // @ngInject
    exports.formatInputField = function() {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function(scope, element, attrs, modelCtrl) {
				//Allow only numbers
                if (attrs.format == 'number') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\d]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
				//For phone numbers format
                if (attrs.format == 'phoneNumber') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\d+]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
				//For checking alphanumeric 
                if (attrs.format == 'alphaNumeric') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
				//For notes field restrict special chars
                if (attrs.format == 'notes') {
                    modelCtrl.$parsers.push(function(inputValue) {
                        if (inputValue == undefined)
                            return ''
                        var cleanInputValue = inputValue.replace(/[^\w\s,.-]/gi, '');
                        if (cleanInputValue != inputValue) {
                            modelCtrl.$setViewValue(cleanInputValue);
                            modelCtrl.$render();
                        }
                        return cleanInputValue;
                    });
                }
            }
        };
    };
});