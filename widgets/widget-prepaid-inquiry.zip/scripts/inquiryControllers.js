/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : inquiryControllers.js
 *  Description: Prepaid Card Inquiry - controllers 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.MainCtrl = function(PrepaidCardService,lpCoreUtils, lpWidget, $window, conversionCodes) {
        var widget = lpWidget;
        var utils = lpCoreUtils;
        var self = this;
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var prepaidCardDetailsUrl = protocolHost+widget.getResolvedPreference('prepaidCardDetails');	
		//submitting card number for inquiry
				
        self.submitCard = function(cardNo) {
		var inquiryPrepaidDetails={};
		inquiryPrepaidDetails.cardNumber=cardNo;
		self.loaderCollapse=true;
		//service call for card details
        PrepaidCardService.getPrepaidDetails(inquiryPrepaidDetails).then(function(response) {
            self.prepaidDetails = response.data;
			if(self.prepaidDetails.returnCode==='00' || self.prepaidDetails.returnCode==='0')
			{
			
			$window.sessionStorage.setItem("inquiryPrepaidCardRequest",JSON.stringify(self.prepaidDetails));
			$window.location.href =prepaidCardDetailsUrl;
			}
			else{
			angular.element(".loader").addClass("hidden");	
			self.loaderCollapse=false;
			angular.element(".inquiry-input").removeClass("hidden");
			self.prepaidCardserror = widget.model.getPreference("noRecordFound");
			}
        }, function(response) {
            self.prepaidDetails = 0;
            if(conversionCodes.errorStatus(response)){
				//removing spinner
               self.loaderCollapse=false;
			   angular.element(".inquiry-input").removeClass("hidden");
				//error message
                self.serverError = widget.model.getPreference("serverError");
            }
        });           
            
        }
    };
});