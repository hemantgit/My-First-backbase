/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : investmentService.js
 *  Description: Investment Transaction Details- service
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.PrepaidCardService = function($http,lpWidget,$window) {
	    var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var PREPAID_INQUIRY_DETAILS = protocolHost+lpWidget.getResolvedPreference('prepaidInquiryService');
        this.getPrepaidDetails = function(cardNo) {
			//Adding Spinner
            angular.element(".loader").removeClass("hidden");
            angular.element(".inquiry-input").addClass("hidden");
            return $http({
                url: PREPAID_INQUIRY_DETAILS,
                method: "POST",
                data: cardNo,
				headers: {'URL':'PC_INQUIRY','KEY':'SPRINT1B','VALUE':'YES'}
                // Static API for Offshore testing
               /* url: "https://api.myjson.com/bins/j8xmj",
                method: "GET",*/
            });
        };




    };

});