
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';
    // @ngInject
    exports.OtpCtrl = function($window,lpCoreBus) {
        var self = this;
		self.maskedMobileNum = null;
		self.conformationNumber = null;
		self.transDateTime = null;
		lpCoreBus.subscribe('OtpConfNumDate', function(data) {
			$scope.$apply(function(){
				self.maskedMobileNum = data.mobileNum.substr(0, 3)+' '+data.mobileNum.substr(3, 3)+' xxx x'+data.mobileNum.substr(-3);
				self.conformationNumber = data.conformationNumber;
				self.transDateTime = data.transDateTime;
			});
		});
	};
});