/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : headerControllers.js
 *  Description: Pre Login Header controller
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget) {
        var widget = lpWidget;
        var self = this;
        var utils = lpCoreUtils;
		//getting logo image
        self.logo = utils.resolvePortalPlaceholders(widget.model.getPreference("logo")) || "";
		//For scroll content
		var bgResize = function() {
        var headerHeight = angular.element('.post-menu-navbar').height() + 40;
        var windowHeight = angular.element(window).height();
        var manageableAreaHeight = angular.element('.bp-manageableArea');
        angular.element('.simple-page-layout').css("height", windowHeight);
        angular.element('.bp-manageableArea').css("max-height", (windowHeight - headerHeight));
        }
        bgResize();
        angular.element(window).bind('resize', function() {
            bgResize();
        });
		/* START: Disable back button*/

			history.pushState(null, null, document.URL);
			window.addEventListener('popstate', function () 
			{
			   history.pushState(null, null, document.URL);
			});
		/* START: Disable right click*/	
			document.addEventListener("contextmenu", function(e){
			e.preventDefault();
			}, false);
    };
});