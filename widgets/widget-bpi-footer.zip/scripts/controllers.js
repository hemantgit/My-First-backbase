/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : controllers.js
 *  Description: bpi footer - controllers
 *  ----------------------------------------------------------------
 */

/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

        "use strict";

    // @ngInject
        exports.MainCtrl = function(lpCoreUtils, lpWidget) {
                var bpiCtrl = this;
                var utils = lpCoreUtils;
                var widget = lpWidget;
                bpiCtrl.logo = utils.resolvePortalPlaceholders(widget.model.getPreference("logo")) || "";
                bpiCtrl.bancnet = utils.resolvePortalPlaceholders(widget.model.getPreference("bancnet")) || "";
                bpiCtrl.verisign = utils.resolvePortalPlaceholders(widget.model.getPreference("verisign")) || "";


                var footerHeight=angular.element(".pageContainer [data-pid*='footer']").height();
                angular.element(".pageContainer [data-pid*=\"container-simple-page-layout\"]").css("padding-bottom",footerHeight);


        };

});