/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : depositControllers.js
 *  Description: Time Deposit Details - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function($http, lpCoreUtils, lpWidget, lpPortal, $window, conversionCodes,lpCoreBus) {
        var self = this;
        var widget = lpWidget;
        self.errorMsg = null;
        self.display = false;
        var timeDepositRequest = {};
        var timeDepositDetailsRequest = {};
        var timeDepositAccount = [];
        timeDepositRequest.accountNumber = "00009787995214";
        timeDepositRequest.accountType = "ST";
        timeDepositRequest.institutionCode = "01";
        timeDepositRequest.currencyCode = "001";
        timeDepositRequest.branchCode = "001";
        timeDepositAccount.push(timeDepositRequest);
        timeDepositDetailsRequest.rmNumber = "00000010210007";
        timeDepositDetailsRequest.TimeDeposit = timeDepositAccount;
		//Getting currency code and institution code
		self.institutionCodeJSON = conversionCodes.institutionCode;
        self.currencyCodeJSON = conversionCodes.currencyCode;
		//Links for navigation		
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var ACCOUNT_DETAILS = protocolHost+widget.getResolvedPreference('goToHome');	
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'timeDeposit'	
        });		
        //calling the service
		self.timeDeposit=JSON.parse($window.sessionStorage.getItem("depositTransacitonRequest"));
				//formatting the date fields
				//Replace date from APT with date string
				var pattern;
				if(self.timeDeposit.term!=undefined && self.timeDeposit.term.trim()!="" && self.timeDeposit.term.lastIndexOf('D')!=-1){
				self.timeDeposit.term=self.timeDeposit.term.substr(0,self.timeDeposit.term.lastIndexOf('D'));
				}
                if (self.timeDeposit.dateOpened != undefined && self.timeDeposit.dateOpened.length === 8) {
                pattern = /(\d{2})(\d{2})(\d{4})/;
                self.timeDeposit.dateOpened = new Date(self.timeDeposit.dateOpened.replace(pattern, "$1/$2/$3"));
                self.timeDeposit.dateOpened = self.timeDeposit.dateOpened.toString("mmm,dd,yyyy");
                } 
				if (self.timeDeposit.dateLastRenewal != undefined && self.timeDeposit.dateLastRenewal.length === 8) {
                pattern = /(\d{2})(\d{2})(\d{4})/;
                self.timeDeposit.dateLastRenewal = new Date(self.timeDeposit.dateLastRenewal.replace(pattern, "$1/$2/$3"));
                self.timeDeposit.dateLastRenewal = self.timeDeposit.dateLastRenewal.toString("mmm,dd,yyyy");
                }
				if (self.timeDeposit.maturityDate != undefined && self.timeDeposit.maturityDate.length === 8) {
                pattern = /(\d{2})(\d{2})(\d{4})/;
                self.timeDeposit.maturityDate = new Date(self.timeDeposit.maturityDate.replace(pattern, "$1/$2/$3"));
                self.timeDeposit.maturityDate = self.timeDeposit.maturityDate.toString("mmm,dd,yyyy");
                }
		//Date filter for formatting
		self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 15))
                    return dateString.slice(4, 15);
                else
                    return "";
            }
        };
     	//Navigation to my accounts page
        self.goToHomePage =function(){
		$window.location.href =ACCOUNT_DETAILS;
		};        
		  /*
         *      Currency code to currency value conversion
         */
		 self.getCurrency = function(value) {
            var currencyCode;
            if (value) {
                currencyCode = value.substr(1, 2);
            }
            return currencyCode;
        };
    };

});