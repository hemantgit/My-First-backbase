/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : homepageCtrl.js
 *  Description: BPI Homepage controller
 *  ----------------------------------------------------------------
 */
define(function (require, exports) {

    'use strict';

    // @ngInject
    exports.MainCtrl = function($scope,lpCoreUtils,lpWidget,lpPortal,$window) {
           var utils = lpCoreUtils;
		   var widget = lpWidget;
		   var self=this;
		self.myInterval = 5000;
		self.noWrapSlides = false;
		self.active = 0;
        // The widget needs to inform it's done loading so preloading works as expected
		self.ImgUrl = getImage('ImgUrl');
		self.carosal1 = getImage('carosal1');
		self.carosal2 = getImage('carosal2');
		self.carosal3 = getImage('carosal3');
		self.icon1 = getImage('icon1');
		self.icon2 = getImage('icon2');
		self.icon3 = getImage('icon3');
		self.icon4 = getImage('icon4');
		self.facebook = getImage('facebook');
		self.twitter = getImage('twitter');
		self.youtube = getImage('youtube');
		self.featuredArticle = getImage('featuredArticle');
		self.news = getImage('news');
		self.quickLinks = getImage('quickLinks');
		self.arrow = getImage('arrow');
		self.bpiAppDownload = getImage('bpiAppDownload');
		self.prepaidCard = getImage('prepaidCard');
		self.seperator = getImage('seperator');
		self.bankAdvisory = getImage('bankAdvisory');
		self.faq = getImage('faq');
		self.homeLogin = getImage('homeLogin');
		self.homeBetaLogin = getImage('homeBetaLogin');
		/* change carosal image */
		function getImage(imageName){
			return utils.resolvePortalPlaceholders(widget.model.getPreference(imageName)) || "";
		}
	
		self.slides =[{"id":0, "image":self.carosal1, "url":"https://bpiexpressonline.com/p/1/1458/instructional-guide"},
					{"id":1, "image":self.carosal3, "url":"https://www.bpiexpressonline.com/p/1/88/how-to-use-eps"}];
		self.goToLoginForm= function(){
		   $window.location.href= LOGIN;
		}
		$(function(){
		var heightAdd=angular.element("#addMainDiv").height();
		angular.element("#addMainDiv").siblings().height(heightAdd);	
		
		 angular.element('.right span').removeClass('glyphicon-chevron-right');
		 angular.element('.right span').addClass('glyphicon-menu-right');
		 
		 angular.element('.left span').removeClass('glyphicon-chevron-left');
		 angular.element('.left span').addClass('glyphicon-menu-left');
			var windowWidth=$(window).width();
			/*if(windowWidth > 500)
			{
			var articleHeight=$(".homeArticle").height();
			$(".ads-div").height(articleHeight);
			}*/
		});	
		var CONFIG_PROTOCOL = window.location.protocol,
			CONFIG_HOST = window.location.host,
			CONFIG_PORTALSERVER = "portalserver";
		self.prepaidCardInquiry=function(){
		$window.location.href=WEB_PROTOCOL + '//' + WEB_HOST + '/' + WEB_PORTALSERVER + "/bpi-portal/prepaidinquiry";
		}
    };
});
