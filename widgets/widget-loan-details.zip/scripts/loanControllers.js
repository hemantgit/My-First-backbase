/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : loanControllers.js
 *  Description: Loans - controllers
 *  ----------------------------------------------------------------
 */
/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {

    "use strict";

    // @ngInject
    exports.MainCtrl = function($http, lpCoreUtils, lpWidget, lpPortal, $window,lpCoreBus) {
        var self = this;
        var widget = lpWidget;
        self.display = false;
        //Request for getting value
		var loanRequest=JSON.parse($window.sessionStorage.getItem("loansTransacitonRequest"));
		self.loansPreferredName=$window.sessionStorage.getItem("loansPreferredName");		
		self.loansAccountNumber=$window.sessionStorage.getItem("loansAccountNumber");	
		self.loanDetails=loanRequest;
		//Getting protocol and host values
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var accountDetailsUrl = protocolHost+widget.getResolvedPreference('goToHome');
		self.lengthEmpty="-";
		var bus = lpCoreBus;
		bus.publish('headerMenu', {
                page: 'loansDetails'	
        });
		//Splitting loan type to display title 
		updateLoanType(){
			if(self.loanDetails.loanType=="AL"){
			self.loanTypes="Auto Loan";
			self.autoLoan=true;
			}
			if(self.loanDetails.loanType=="MC"){
			self.loanTypes="Motor Cycle Loan";
			self.motorCycleLoan=true;
			}
			if(self.loanDetails.loanType=="CG"){
			self.loanTypes="Car Group Loan";
			self.carGroupLoan=true;
			}
			if(self.loanDetails.loanType=="HL"){
			self.loanTypes="Housing Loan";
			self.housingLoan=true;
			}
			if(self.loanDetails.loanType=="HG"){
			self.loanTypes="Housing Group Plan Tie Up Loan";
			self.housingGroupLoan=true;
			}
			if(self.loanDetails.loanType=="CS"){
			self.loanTypes="CTS Loan";
			self.contractLoan=true;
			}
			if(self.loanDetails.loanType=="PL"){
			self.loanTypes="Personal Loan";
			self.personalLoan=true;
			}
			if(self.loanDetails.loanType=="KN"){
			self.loanTypes="KaNegosyo Loan";
			self.KaNegosyoLoan=true;
			}
		}
		updateLoanType();
		
		// formating the date fields
		//Replace date from APT with date string
		function ChangeLoanDateFormat(){
			var pattern;
			
			if (self.loanDetails.loanDate != undefined && self.loanDetails.loanDate.length === 8) {
				pattern = /(\d{2})(\d{2})(\d{4})/;
				self.loanDetails.loanDate = new Date(self.loanDetails.loanDate.replace(pattern, "$1/$2/$3"));
				self.loanDetails.loanDate = self.loanDetails.loanDate.toString("mmm,dd,yyyy");
			}
			if (self.loanDetails.firstDueDate != undefined && self.loanDetails.firstDueDate.length === 8) {
				pattern = /(\d{2})(\d{2})(\d{4})/;
				self.loanDetails.firstDueDate = new Date(self.loanDetails.firstDueDate.replace(pattern, "$1/$2/$3"));
				self.loanDetails.firstDueDate = self.loanDetails.firstDueDate.toString("mmm,dd,yyyy");
			}
			if (self.loanDetails.maturityDate != undefined && self.loanDetails.maturityDate.length === 8) {
				pattern = /(\d{2})(\d{2})(\d{4})/;
				self.loanDetails.maturityDate = new Date(self.loanDetails.maturityDate.replace(pattern, "$1/$2/$3"));
				self.loanDetails.maturityDate = self.loanDetails.maturityDate.toString("mmm,dd,yyyy");
			} 
			if (self.loanDetails.nextDueDate != undefined && self.loanDetails.nextDueDate.length === 8) {
				pattern = /(\d{2})(\d{2})(\d{4})/;
				self.loanDetails.nextDueDate = new Date(self.loanDetails.nextDueDate.replace(pattern, "$1/$2/$3"));
				self.loanDetails.nextDueDate = self.loanDetails.nextDueDate.toString("mmm,dd,yyyy");
			}
			if (self.loanDetails.lastPaymentDate != undefined && self.loanDetails.lastPaymentDate.length === 8) {
				pattern = /(\d{2})(\d{2})(\d{4})/;
				self.loanDetails.lastPaymentDate = new Date(self.loanDetails.lastPaymentDate.replace(pattern, "$1/$2/$3"));
				self.loanDetails.lastPaymentDate = self.loanDetails.lastPaymentDate.toString("mmm,dd,yyyy");
			}
		
		}
		ChangeLoanDateFormat();
		 angular.forEach(self.loanDetails.collaterals, function(collaterals) {
			if (collaterals.expiryDate != undefined && collaterals.expiryDate.trim() !='' && collaterals.expiryDate.length === 8) {
			pattern = /(\d{2})(\d{2})(\d{4})/;
			collaterals.expiryDate = new Date(collaterals.expiryDate.replace(pattern, "$1/$2/$3"));
			collaterals.expiryDate = collaterals.expiryDate.toString("mmm,dd,yyyy");
		}
		 });
  
		//Date filter for formatting
		self.dateFilter = function(dateString) {
            if (navigator.appVersion && (navigator.appVersion.indexOf("MSIE 9") >= 0 || navigator.appVersion.indexOf("MSIE 10") >= 0)) {
                //If IE the date format is changes for single date dd
                return dateFilterForIE(dateString);
            } else {
                if (dateString && dateString.slice(4, 16))
                    return dateString.slice(4, 16);
                else
                    return "";
            }
        };
		//Navigation to my accounts page
        self.goToHomePage =function(){
		$window.location.href = accountDetailsUrl;
		};
		//About this page accordian 
        self.expanded = false;
        self.closed = true;
        self.expandedView = function() {
            self.expanded = !self.expanded;
            self.closed = !self.closed;
        }
        
    };

});