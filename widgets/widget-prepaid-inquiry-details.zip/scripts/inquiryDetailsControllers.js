/**
 *  ----------------------------------------------------------------
 *  Copyright c BPI.
 *  ----------------------------------------------------------------
 *  Author : HCL
 *  Filename : inquiryControllers.js
 *  Description: Prepaid Card Inquiry Details - controllers 
 *  ----------------------------------------------------------------
 */
define(function(require, exports) {
    "use strict";

    // @ngInject
    exports.MainCtrl = function(lpCoreUtils, lpWidget, $window) {
        var widget = lpWidget;
        var utils = lpCoreUtils;
        var self = this;
		//Getting response from prepaid inquiry
        var inquiryPrepaidCardRequest = JSON.parse($window.sessionStorage.getItem("inquiryPrepaidCardRequest"));
		self.prepaidDetails = inquiryPrepaidCardRequest;
		var protocolHost = $window.location.protocol+'//'+$window.location.host;
		var homePage = protocolHost+widget.getResolvedPreference('homePage');
		var prepaidInquiryUrl = protocolHost+widget.getResolvedPreference('prepaidInquiry');        
		//Navigation for inquire again
        self.inquireAgain = function(){
			$window.location.href =prepaidInquiryUrl;
		};
		//Navigation to home page
		self.homePage = function(){
			$window.location.href =homePage;
		};
        
    };
});